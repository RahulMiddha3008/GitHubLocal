
namespace DotEditPanels
{
    partial class APT_Main
    {
        /// 
        /// Required designer variable.
        /// 
        private System.ComponentModel.IContainer components = null;

        /// 
        /// Clean up any resources being used.
        /// 
        /// true if managed resources should be disposed; otherwise, false.
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// 
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(APT_Main));
            this.lblVendor = new System.Windows.Forms.Label();
            this.dcimTaxDetail = new AxDCIMAGELib.AxDcimage();
            this.lblVendor_Number = new System.Windows.Forms.Label();
            this.dcimVendor_Number = new AxDCIMAGELib.AxDcimage();
            this.lblRemittance_Zip = new System.Windows.Forms.Label();
            this.dcimRemittance_Zip = new AxDCIMAGELib.AxDcimage();
            this.lblInvoice_Number = new System.Windows.Forms.Label();
            this.dcimInvoice_Number = new AxDCIMAGELib.AxDcimage();
            this.lblInvoice_Date = new System.Windows.Forms.Label();
            this.dcimInvoice_Date = new AxDCIMAGELib.AxDcimage();
            this.lblPO_Number = new System.Windows.Forms.Label();
            this.dcimPO_Number = new AxDCIMAGELib.AxDcimage();
            this.lblShipping = new System.Windows.Forms.Label();
            this.dcimShipping = new AxDCIMAGELib.AxDcimage();
            this.lblInvoice_Type = new System.Windows.Forms.Label();
            this.dcimInvoice_Type = new AxDCIMAGELib.AxDcimage();
            this.lbTax_Type = new System.Windows.Forms.Label();
            this.lbTax_Value = new System.Windows.Forms.Label();
            this.panTaxLineitem = new System.Windows.Forms.Panel();
            this.dcedTax_Type = new AxDCEDITLib.AxDcedit();
            this.dcedTax_Value = new AxDCEDITLib.AxDcedit();
            this.btnInsBeforepbTaxLineitem = new System.Windows.Forms.Button();
            this.btnInsAfterpbTaxLineitem = new System.Windows.Forms.Button();
            this.btnDelpbTaxLineitem = new System.Windows.Forms.Button();
            this.lblTax = new System.Windows.Forms.Label();
            this.dcimTax = new AxDCIMAGELib.AxDcimage();
            this.lblInvoice_Total = new System.Windows.Forms.Label();
            this.dcimInvoice_Total = new AxDCIMAGELib.AxDcimage();
            this.lblAdd_New_Fingerprint = new System.Windows.Forms.Label();
            this.dcimAdd_New_Fingerprint = new AxDCIMAGELib.AxDcimage();
            this.lblRouting_Instructions = new System.Windows.Forms.Label();
            this.dcimRouting_Instructions = new AxDCIMAGELib.AxDcimage();
            this.dcimTIFF = new AxDCIMAGELib.AxDcimage();
            this.lbItemID = new System.Windows.Forms.Label();
            this.lbItemDesc = new System.Windows.Forms.Label();
            this.lbQty = new System.Windows.Forms.Label();
            this.lbPrice = new System.Windows.Forms.Label();
            this.lbLineTotal = new System.Windows.Forms.Label();
            this.lbPOLineNum = new System.Windows.Forms.Label();
            this.panLineitem = new System.Windows.Forms.Panel();
            this.dcedItemID = new AxDCEDITLib.AxDcedit();
            this.dcedItemDesc = new AxDCEDITLib.AxDcedit();
            this.dcedQty = new AxDCEDITLib.AxDcedit();
            this.dcedPrice = new AxDCEDITLib.AxDcedit();
            this.dcedLineTotal = new AxDCEDITLib.AxDcedit();
            this.dcedPOLineNum = new AxDCEDITLib.AxDcedit();
            this.btnInsBeforepbLineitem = new System.Windows.Forms.Button();
            this.btnInsAfterpbLineitem = new System.Windows.Forms.Button();
            this.btnDelpbLineitem = new System.Windows.Forms.Button();
            this.dcimCurrentLine = new AxDCIMAGELib.AxDcimage();
            this.comboBoxInvoice_Type = new System.Windows.Forms.ComboBox();
            this.comboBoxAdd_New_Fingerprint = new System.Windows.Forms.ComboBox();
            this.comboBoxRouting_Instructions = new System.Windows.Forms.ComboBox();
            this.comboBoxLanguage = new System.Windows.Forms.ComboBox();
            this.lblLanguage = new System.Windows.Forms.Label();
            this.btnOCR = new System.Windows.Forms.Button();
            this.POLRBtn = new System.Windows.Forms.Button();
            this.StickyBtn = new System.Windows.Forms.Button();
            this.lblLineitem = new System.Windows.Forms.Label();
            this.dcedVendor = new AxDCEDITLib.AxDcedit();
            this.dcedVendor_Number = new AxDCEDITLib.AxDcedit();
            this.dcedRemittance_Zip = new AxDCEDITLib.AxDcedit();
            this.dcedInvoice_Number = new AxDCEDITLib.AxDcedit();
            this.dcedInvoice_Date = new AxDCEDITLib.AxDcedit();
            this.dcedPO_Number = new AxDCEDITLib.AxDcedit();
            this.dcedShipping = new AxDCEDITLib.AxDcedit();
            this.dcedInvoice_Type = new AxDCEDITLib.AxDcedit();
            this.dcedTax = new AxDCEDITLib.AxDcedit();
            this.dcedInvoice_Total = new AxDCEDITLib.AxDcedit();
            this.dcedAdd_New_Fingerprint = new AxDCEDITLib.AxDcedit();
            this.dcedRouting_Instructions = new AxDCEDITLib.AxDcedit();
            this.dcedTIFF = new AxDCEDITLib.AxDcedit();
            this.scrLineitem = new System.Windows.Forms.VScrollBar();
            ((System.ComponentModel.ISupportInitialize)(this.dcimTaxDetail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimVendor_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimRemittance_Zip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Date)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimPO_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimShipping)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Type)).BeginInit();
            this.panTaxLineitem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTax_Type)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTax_Value)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimTax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Total)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimAdd_New_Fingerprint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimRouting_Instructions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimTIFF)).BeginInit();
            this.panLineitem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dcedItemID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedItemDesc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedQty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedLineTotal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPOLineNum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCurrentLine)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedVendor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedVendor_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedRemittance_Zip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Date)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPO_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedShipping)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Type)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Total)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedAdd_New_Fingerprint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedRouting_Instructions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTIFF)).BeginInit();
            this.SuspendLayout();
            // 
            // lblVendor
            // 
            this.lblVendor.AutoSize = true;
            this.lblVendor.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendor.Location = new System.Drawing.Point(0, 60);
            this.lblVendor.Name = "lblVendor";
            this.lblVendor.Size = new System.Drawing.Size(52, 14);
            this.lblVendor.TabIndex = 2;
            this.lblVendor.Tag = "Vendor";
            this.lblVendor.Text = "Vendor";
            // 
            // dcimTaxDetail
            // 
            this.dcimTaxDetail.Location = new System.Drawing.Point(3, 205);
            this.dcimTaxDetail.Name = "dcimTaxDetail";
            this.dcimTaxDetail.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimTaxDetail.OcxState")));
            this.dcimTaxDetail.Size = new System.Drawing.Size(593, 29);
            this.dcimTaxDetail.TabIndex = 27;
            this.dcimTaxDetail.TabStop = false;
            this.dcimTaxDetail.Tag = "Vendor";
            // 
            // lblVendor_Number
            // 
            this.lblVendor_Number.AutoSize = true;
            this.lblVendor_Number.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendor_Number.Location = new System.Drawing.Point(348, 60);
            this.lblVendor_Number.Name = "lblVendor_Number";
            this.lblVendor_Number.Size = new System.Drawing.Size(109, 14);
            this.lblVendor_Number.TabIndex = 4;
            this.lblVendor_Number.Tag = "Vendor_Number";
            this.lblVendor_Number.Text = "Vendor_Number";
            // 
            // dcimVendor_Number
            // 
            this.dcimVendor_Number.Location = new System.Drawing.Point(820, 28);
            this.dcimVendor_Number.Name = "dcimVendor_Number";
            this.dcimVendor_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimVendor_Number.OcxState")));
            this.dcimVendor_Number.Size = new System.Drawing.Size(117, 29);
            this.dcimVendor_Number.TabIndex = 55;
            this.dcimVendor_Number.TabStop = false;
            this.dcimVendor_Number.Tag = "Vendor_Number";
            this.dcimVendor_Number.Visible = false;
            // 
            // lblRemittance_Zip
            // 
            this.lblRemittance_Zip.AutoSize = true;
            this.lblRemittance_Zip.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRemittance_Zip.Location = new System.Drawing.Point(471, 28);
            this.lblRemittance_Zip.Name = "lblRemittance_Zip";
            this.lblRemittance_Zip.Size = new System.Drawing.Size(83, 14);
            this.lblRemittance_Zip.TabIndex = 6;
            this.lblRemittance_Zip.Tag = "Postal Code";
            this.lblRemittance_Zip.Text = "Postal Code";
            // 
            // dcimRemittance_Zip
            // 
            this.dcimRemittance_Zip.Location = new System.Drawing.Point(474, 45);
            this.dcimRemittance_Zip.Name = "dcimRemittance_Zip";
            this.dcimRemittance_Zip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimRemittance_Zip.OcxState")));
            this.dcimRemittance_Zip.Size = new System.Drawing.Size(122, 29);
            this.dcimRemittance_Zip.TabIndex = 7;
            this.dcimRemittance_Zip.TabStop = false;
            this.dcimRemittance_Zip.Tag = "Remittance_Zip";
            // 
            // lblInvoice_Number
            // 
            this.lblInvoice_Number.AutoSize = true;
            this.lblInvoice_Number.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoice_Number.Location = new System.Drawing.Point(599, 28);
            this.lblInvoice_Number.Name = "lblInvoice_Number";
            this.lblInvoice_Number.Size = new System.Drawing.Size(109, 14);
            this.lblInvoice_Number.TabIndex = 9;
            this.lblInvoice_Number.Tag = "Invoice_Number";
            this.lblInvoice_Number.Text = "Invoice_Number";
            // 
            // dcimInvoice_Number
            // 
            this.dcimInvoice_Number.Location = new System.Drawing.Point(602, 45);
            this.dcimInvoice_Number.Name = "dcimInvoice_Number";
            this.dcimInvoice_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimInvoice_Number.OcxState")));
            this.dcimInvoice_Number.Size = new System.Drawing.Size(144, 29);
            this.dcimInvoice_Number.TabIndex = 10;
            this.dcimInvoice_Number.TabStop = false;
            this.dcimInvoice_Number.Tag = "Invoice_Number";
            // 
            // lblInvoice_Date
            // 
            this.lblInvoice_Date.AutoSize = true;
            this.lblInvoice_Date.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoice_Date.Location = new System.Drawing.Point(0, 117);
            this.lblInvoice_Date.Name = "lblInvoice_Date";
            this.lblInvoice_Date.Size = new System.Drawing.Size(90, 14);
            this.lblInvoice_Date.TabIndex = 12;
            this.lblInvoice_Date.Tag = "Invoice_Date";
            this.lblInvoice_Date.Text = "Invoice_Date";
            // 
            // dcimInvoice_Date
            // 
            this.dcimInvoice_Date.Location = new System.Drawing.Point(3, 134);
            this.dcimInvoice_Date.Name = "dcimInvoice_Date";
            this.dcimInvoice_Date.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimInvoice_Date.OcxState")));
            this.dcimInvoice_Date.Size = new System.Drawing.Size(136, 29);
            this.dcimInvoice_Date.TabIndex = 13;
            this.dcimInvoice_Date.TabStop = false;
            this.dcimInvoice_Date.Tag = "Invoice_Date";
            // 
            // lblPO_Number
            // 
            this.lblPO_Number.AutoSize = true;
            this.lblPO_Number.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPO_Number.Location = new System.Drawing.Point(142, 117);
            this.lblPO_Number.Name = "lblPO_Number";
            this.lblPO_Number.Size = new System.Drawing.Size(82, 14);
            this.lblPO_Number.TabIndex = 15;
            this.lblPO_Number.Tag = "PO_Number";
            this.lblPO_Number.Text = "PO_Number";
            // 
            // dcimPO_Number
            // 
            this.dcimPO_Number.Location = new System.Drawing.Point(145, 134);
            this.dcimPO_Number.Name = "dcimPO_Number";
            this.dcimPO_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimPO_Number.OcxState")));
            this.dcimPO_Number.Size = new System.Drawing.Size(200, 29);
            this.dcimPO_Number.TabIndex = 16;
            this.dcimPO_Number.TabStop = false;
            this.dcimPO_Number.Tag = "PO_Number";
            // 
            // lblShipping
            // 
            this.lblShipping.AutoSize = true;
            this.lblShipping.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShipping.Location = new System.Drawing.Point(348, 117);
            this.lblShipping.Name = "lblShipping";
            this.lblShipping.Size = new System.Drawing.Size(61, 14);
            this.lblShipping.TabIndex = 18;
            this.lblShipping.Tag = "Shipping";
            this.lblShipping.Text = "Shipping";
            // 
            // dcimShipping
            // 
            this.dcimShipping.Location = new System.Drawing.Point(351, 134);
            this.dcimShipping.Name = "dcimShipping";
            this.dcimShipping.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimShipping.OcxState")));
            this.dcimShipping.Size = new System.Drawing.Size(117, 29);
            this.dcimShipping.TabIndex = 19;
            this.dcimShipping.TabStop = false;
            this.dcimShipping.Tag = "Shipping";
            // 
            // lblInvoice_Type
            // 
            this.lblInvoice_Type.AutoSize = true;
            this.lblInvoice_Type.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoice_Type.Location = new System.Drawing.Point(603, 202);
            this.lblInvoice_Type.Name = "lblInvoice_Type";
            this.lblInvoice_Type.Size = new System.Drawing.Size(90, 14);
            this.lblInvoice_Type.TabIndex = 34;
            this.lblInvoice_Type.Tag = "Invoice_Type";
            this.lblInvoice_Type.Text = "Invoice_Type";
            // 
            // dcimInvoice_Type
            // 
            this.dcimInvoice_Type.Location = new System.Drawing.Point(820, 69);
            this.dcimInvoice_Type.Name = "dcimInvoice_Type";
            this.dcimInvoice_Type.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimInvoice_Type.OcxState")));
            this.dcimInvoice_Type.Size = new System.Drawing.Size(200, 29);
            this.dcimInvoice_Type.TabIndex = 56;
            this.dcimInvoice_Type.TabStop = false;
            this.dcimInvoice_Type.Tag = "Invoice_Type";
            this.dcimInvoice_Type.Visible = false;
            // 
            // lbTax_Type
            // 
            this.lbTax_Type.AutoSize = true;
            this.lbTax_Type.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTax_Type.Location = new System.Drawing.Point(349, 240);
            this.lbTax_Type.Name = "lbTax_Type";
            this.lbTax_Type.Size = new System.Drawing.Size(67, 14);
            this.lbTax_Type.TabIndex = 28;
            this.lbTax_Type.Tag = "Tax_Type";
            this.lbTax_Type.Text = "Tax_Type";
            // 
            // lbTax_Value
            // 
            this.lbTax_Value.AutoSize = true;
            this.lbTax_Value.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTax_Value.Location = new System.Drawing.Point(470, 240);
            this.lbTax_Value.Name = "lbTax_Value";
            this.lbTax_Value.Size = new System.Drawing.Size(72, 14);
            this.lbTax_Value.TabIndex = 29;
            this.lbTax_Value.Tag = "Tax_Value";
            this.lbTax_Value.Text = "Tax_Value";
            // 
            // panTaxLineitem
            // 
            this.panTaxLineitem.AutoScroll = true;
            this.panTaxLineitem.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panTaxLineitem.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panTaxLineitem.Controls.Add(this.dcedTax_Type);
            this.panTaxLineitem.Controls.Add(this.dcedTax_Value);
            this.panTaxLineitem.Location = new System.Drawing.Point(346, 257);
            this.panTaxLineitem.Name = "panTaxLineitem";
            this.panTaxLineitem.Size = new System.Drawing.Size(248, 102);
            this.panTaxLineitem.TabIndex = 30;
            this.panTaxLineitem.Tag = "TaxLineitem";
            // 
            // dcedTax_Type
            // 
            this.dcedTax_Type.Location = new System.Drawing.Point(1, 2);
            this.dcedTax_Type.Name = "dcedTax_Type";
            this.dcedTax_Type.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedTax_Type.OcxState")));
            this.dcedTax_Type.Size = new System.Drawing.Size(119, 27);
            this.dcedTax_Type.TabIndex = 0;
            this.dcedTax_Type.Tag = "Tax_Type";
            // 
            // dcedTax_Value
            // 
            this.dcedTax_Value.Location = new System.Drawing.Point(122, 2);
            this.dcedTax_Value.Name = "dcedTax_Value";
            this.dcedTax_Value.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedTax_Value.OcxState")));
            this.dcedTax_Value.Size = new System.Drawing.Size(119, 27);
            this.dcedTax_Value.TabIndex = 1;
            this.dcedTax_Value.Tag = "Tax_Value";
            this.dcedTax_Value.Change += new System.EventHandler(this.dcedTax_Value_Change);
            this.dcedTax_Value.Enter += new System.EventHandler(this.dcedTax_Value_Enter);
            // 
            // btnInsBeforepbTaxLineitem
            // 
            this.btnInsBeforepbTaxLineitem.Image = ((System.Drawing.Image)(resources.GetObject("btnInsBeforepbTaxLineitem.Image")));
            this.btnInsBeforepbTaxLineitem.Location = new System.Drawing.Point(346, 361);
            this.btnInsBeforepbTaxLineitem.Name = "btnInsBeforepbTaxLineitem";
            this.btnInsBeforepbTaxLineitem.Size = new System.Drawing.Size(32, 27);
            this.btnInsBeforepbTaxLineitem.TabIndex = 31;
            this.btnInsBeforepbTaxLineitem.Tag = "TaxLineitem";
            this.btnInsBeforepbTaxLineitem.UseVisualStyleBackColor = true;
            // 
            // btnInsAfterpbTaxLineitem
            // 
            this.btnInsAfterpbTaxLineitem.Image = ((System.Drawing.Image)(resources.GetObject("btnInsAfterpbTaxLineitem.Image")));
            this.btnInsAfterpbTaxLineitem.Location = new System.Drawing.Point(383, 361);
            this.btnInsAfterpbTaxLineitem.Name = "btnInsAfterpbTaxLineitem";
            this.btnInsAfterpbTaxLineitem.Size = new System.Drawing.Size(32, 27);
            this.btnInsAfterpbTaxLineitem.TabIndex = 32;
            this.btnInsAfterpbTaxLineitem.Tag = "TaxLineitem";
            this.btnInsAfterpbTaxLineitem.UseVisualStyleBackColor = true;
            // 
            // btnDelpbTaxLineitem
            // 
            this.btnDelpbTaxLineitem.Image = ((System.Drawing.Image)(resources.GetObject("btnDelpbTaxLineitem.Image")));
            this.btnDelpbTaxLineitem.Location = new System.Drawing.Point(421, 361);
            this.btnDelpbTaxLineitem.Name = "btnDelpbTaxLineitem";
            this.btnDelpbTaxLineitem.Size = new System.Drawing.Size(32, 27);
            this.btnDelpbTaxLineitem.TabIndex = 33;
            this.btnDelpbTaxLineitem.Tag = "TaxLineitem";
            this.btnDelpbTaxLineitem.UseVisualStyleBackColor = true;
            // 
            // lblTax
            // 
            this.lblTax.AutoSize = true;
            this.lblTax.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTax.Location = new System.Drawing.Point(471, 117);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(64, 14);
            this.lblTax.TabIndex = 21;
            this.lblTax.Tag = "Tax Total";
            this.lblTax.Text = "Tax Total";
            // 
            // dcimTax
            // 
            this.dcimTax.Location = new System.Drawing.Point(474, 134);
            this.dcimTax.Name = "dcimTax";
            this.dcimTax.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimTax.OcxState")));
            this.dcimTax.Size = new System.Drawing.Size(122, 29);
            this.dcimTax.TabIndex = 22;
            this.dcimTax.TabStop = false;
            this.dcimTax.Tag = "Tax";
            this.dcimTax.Visible = false;
            // 
            // lblInvoice_Total
            // 
            this.lblInvoice_Total.AutoSize = true;
            this.lblInvoice_Total.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoice_Total.Location = new System.Drawing.Point(600, 117);
            this.lblInvoice_Total.Name = "lblInvoice_Total";
            this.lblInvoice_Total.Size = new System.Drawing.Size(91, 14);
            this.lblInvoice_Total.TabIndex = 24;
            this.lblInvoice_Total.Tag = "Invoice_Total";
            this.lblInvoice_Total.Text = "Invoice_Total";
            // 
            // dcimInvoice_Total
            // 
            this.dcimInvoice_Total.Location = new System.Drawing.Point(602, 134);
            this.dcimInvoice_Total.Name = "dcimInvoice_Total";
            this.dcimInvoice_Total.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimInvoice_Total.OcxState")));
            this.dcimInvoice_Total.Size = new System.Drawing.Size(141, 29);
            this.dcimInvoice_Total.TabIndex = 25;
            this.dcimInvoice_Total.TabStop = false;
            this.dcimInvoice_Total.Tag = "Invoice_Total";
            // 
            // lblAdd_New_Fingerprint
            // 
            this.lblAdd_New_Fingerprint.AutoSize = true;
            this.lblAdd_New_Fingerprint.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdd_New_Fingerprint.Location = new System.Drawing.Point(603, 241);
            this.lblAdd_New_Fingerprint.Name = "lblAdd_New_Fingerprint";
            this.lblAdd_New_Fingerprint.Size = new System.Drawing.Size(143, 14);
            this.lblAdd_New_Fingerprint.TabIndex = 36;
            this.lblAdd_New_Fingerprint.Tag = "Add_New_Fingerprint";
            this.lblAdd_New_Fingerprint.Text = "Add_New_Fingerprint";
            // 
            // dcimAdd_New_Fingerprint
            // 
            this.dcimAdd_New_Fingerprint.Location = new System.Drawing.Point(820, 117);
            this.dcimAdd_New_Fingerprint.Name = "dcimAdd_New_Fingerprint";
            this.dcimAdd_New_Fingerprint.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimAdd_New_Fingerprint.OcxState")));
            this.dcimAdd_New_Fingerprint.Size = new System.Drawing.Size(200, 29);
            this.dcimAdd_New_Fingerprint.TabIndex = 57;
            this.dcimAdd_New_Fingerprint.TabStop = false;
            this.dcimAdd_New_Fingerprint.Tag = "Add_New_Fingerprint";
            this.dcimAdd_New_Fingerprint.Visible = false;
            // 
            // lblRouting_Instructions
            // 
            this.lblRouting_Instructions.AutoSize = true;
            this.lblRouting_Instructions.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRouting_Instructions.Location = new System.Drawing.Point(602, 280);
            this.lblRouting_Instructions.Name = "lblRouting_Instructions";
            this.lblRouting_Instructions.Size = new System.Drawing.Size(138, 14);
            this.lblRouting_Instructions.TabIndex = 38;
            this.lblRouting_Instructions.Tag = "Routing_Instructions";
            this.lblRouting_Instructions.Text = "Routing_Instructions";
            // 
            // dcimRouting_Instructions
            // 
            this.dcimRouting_Instructions.Location = new System.Drawing.Point(820, 170);
            this.dcimRouting_Instructions.Name = "dcimRouting_Instructions";
            this.dcimRouting_Instructions.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimRouting_Instructions.OcxState")));
            this.dcimRouting_Instructions.Size = new System.Drawing.Size(200, 29);
            this.dcimRouting_Instructions.TabIndex = 58;
            this.dcimRouting_Instructions.TabStop = false;
            this.dcimRouting_Instructions.Tag = "Routing_Instructions";
            this.dcimRouting_Instructions.Visible = false;
            // 
            // dcimTIFF
            // 
            this.dcimTIFF.Location = new System.Drawing.Point(820, 205);
            this.dcimTIFF.Name = "dcimTIFF";
            this.dcimTIFF.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimTIFF.OcxState")));
            this.dcimTIFF.Size = new System.Drawing.Size(200, 29);
            this.dcimTIFF.TabIndex = 59;
            this.dcimTIFF.TabStop = false;
            this.dcimTIFF.Tag = "TIFF";
            this.dcimTIFF.Visible = false;
            // 
            // lbItemID
            // 
            this.lbItemID.AutoSize = true;
            this.lbItemID.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbItemID.Location = new System.Drawing.Point(6, 449);
            this.lbItemID.Name = "lbItemID";
            this.lbItemID.Size = new System.Drawing.Size(50, 14);
            this.lbItemID.TabIndex = 44;
            this.lbItemID.Tag = "ItemID";
            this.lbItemID.Text = "ItemID";
            // 
            // lbItemDesc
            // 
            this.lbItemDesc.AutoSize = true;
            this.lbItemDesc.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbItemDesc.Location = new System.Drawing.Point(110, 449);
            this.lbItemDesc.Name = "lbItemDesc";
            this.lbItemDesc.Size = new System.Drawing.Size(66, 14);
            this.lbItemDesc.TabIndex = 45;
            this.lbItemDesc.Tag = "ItemDesc";
            this.lbItemDesc.Text = "ItemDesc";
            // 
            // lbQty
            // 
            this.lbQty.AutoSize = true;
            this.lbQty.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbQty.Location = new System.Drawing.Point(377, 449);
            this.lbQty.Name = "lbQty";
            this.lbQty.Size = new System.Drawing.Size(29, 14);
            this.lbQty.TabIndex = 46;
            this.lbQty.Tag = "Qty";
            this.lbQty.Text = "Qty";
            // 
            // lbPrice
            // 
            this.lbPrice.AutoSize = true;
            this.lbPrice.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPrice.Location = new System.Drawing.Point(447, 449);
            this.lbPrice.Name = "lbPrice";
            this.lbPrice.Size = new System.Drawing.Size(37, 14);
            this.lbPrice.TabIndex = 47;
            this.lbPrice.Tag = "Price";
            this.lbPrice.Text = "Price";
            // 
            // lbLineTotal
            // 
            this.lbLineTotal.AutoSize = true;
            this.lbLineTotal.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLineTotal.Location = new System.Drawing.Point(545, 449);
            this.lbLineTotal.Name = "lbLineTotal";
            this.lbLineTotal.Size = new System.Drawing.Size(64, 14);
            this.lbLineTotal.TabIndex = 48;
            this.lbLineTotal.Tag = "LineTotal";
            this.lbLineTotal.Text = "LineTotal";
            // 
            // lbPOLineNum
            // 
            this.lbPOLineNum.AutoSize = true;
            this.lbPOLineNum.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPOLineNum.Location = new System.Drawing.Point(647, 449);
            this.lbPOLineNum.Name = "lbPOLineNum";
            this.lbPOLineNum.Size = new System.Drawing.Size(79, 14);
            this.lbPOLineNum.TabIndex = 49;
            this.lbPOLineNum.Tag = "POLineNum";
            this.lbPOLineNum.Text = "POLineNum";
            // 
            // panLineitem
            // 
            this.panLineitem.AutoScroll = true;
            this.panLineitem.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panLineitem.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panLineitem.Controls.Add(this.scrLineitem);
            this.panLineitem.Controls.Add(this.dcedItemID);
            this.panLineitem.Controls.Add(this.dcedItemDesc);
            this.panLineitem.Controls.Add(this.dcedQty);
            this.panLineitem.Controls.Add(this.dcedPrice);
            this.panLineitem.Controls.Add(this.dcedLineTotal);
            this.panLineitem.Controls.Add(this.dcedPOLineNum);
            this.panLineitem.Location = new System.Drawing.Point(3, 466);
            this.panLineitem.Name = "panLineitem";
            this.panLineitem.Size = new System.Drawing.Size(743, 214);
            this.panLineitem.TabIndex = 50;
            this.panLineitem.Tag = "Lineitem";
            // 
            // dcedItemID
            // 
            this.dcedItemID.Location = new System.Drawing.Point(1, 2);
            this.dcedItemID.Name = "dcedItemID";
            this.dcedItemID.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedItemID.OcxState")));
            this.dcedItemID.Size = new System.Drawing.Size(102, 27);
            this.dcedItemID.TabIndex = 0;
            this.dcedItemID.Tag = "ItemID";
            this.dcedItemID.Change += new System.EventHandler(this.dcedItemID_Change);
            this.dcedItemID.Enter += new System.EventHandler(this.dcedItemID_Enter);
            // 
            // dcedItemDesc
            // 
            this.dcedItemDesc.Location = new System.Drawing.Point(105, 2);
            this.dcedItemDesc.Name = "dcedItemDesc";
            this.dcedItemDesc.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedItemDesc.OcxState")));
            this.dcedItemDesc.Size = new System.Drawing.Size(266, 27);
            this.dcedItemDesc.TabIndex = 1;
            this.dcedItemDesc.Tag = "ItemDesc";
            this.dcedItemDesc.Enter += new System.EventHandler(this.dcedItemDesc_Enter);
            // 
            // dcedQty
            // 
            this.dcedQty.Location = new System.Drawing.Point(373, 2);
            this.dcedQty.Name = "dcedQty";
            this.dcedQty.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedQty.OcxState")));
            this.dcedQty.Size = new System.Drawing.Size(68, 27);
            this.dcedQty.TabIndex = 2;
            this.dcedQty.Tag = "Qty";
            this.dcedQty.Change += new System.EventHandler(this.dcedQty_Change);
            this.dcedQty.Enter += new System.EventHandler(this.dcedQty_Enter);
            // 
            // dcedPrice
            // 
            this.dcedPrice.Location = new System.Drawing.Point(443, 2);
            this.dcedPrice.Name = "dcedPrice";
            this.dcedPrice.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedPrice.OcxState")));
            this.dcedPrice.Size = new System.Drawing.Size(95, 27);
            this.dcedPrice.TabIndex = 3;
            this.dcedPrice.Tag = "Price";
            this.dcedPrice.Change += new System.EventHandler(this.dcedPrice_Change);
            this.dcedPrice.Enter += new System.EventHandler(this.dcedPrice_Enter);
            // 
            // dcedLineTotal
            // 
            this.dcedLineTotal.Location = new System.Drawing.Point(540, 2);
            this.dcedLineTotal.Name = "dcedLineTotal";
            this.dcedLineTotal.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedLineTotal.OcxState")));
            this.dcedLineTotal.Size = new System.Drawing.Size(100, 27);
            this.dcedLineTotal.TabIndex = 4;
            this.dcedLineTotal.Tag = "LineTotal";
            this.dcedLineTotal.Change += new System.EventHandler(this.dcedLineTotal_Change);
            this.dcedLineTotal.Enter += new System.EventHandler(this.dcedLineTotal_Enter);
            // 
            // dcedPOLineNum
            // 
            this.dcedPOLineNum.Location = new System.Drawing.Point(642, 2);
            this.dcedPOLineNum.Name = "dcedPOLineNum";
            this.dcedPOLineNum.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedPOLineNum.OcxState")));
            this.dcedPOLineNum.Size = new System.Drawing.Size(76, 27);
            this.dcedPOLineNum.TabIndex = 5;
            this.dcedPOLineNum.Tag = "POLineNum";
            this.dcedPOLineNum.Change += new System.EventHandler(this.dcedPOLineNum_Change);
            this.dcedPOLineNum.Enter += new System.EventHandler(this.dcedPOLineNum_Enter);
            // 
            // btnInsBeforepbLineitem
            // 
            this.btnInsBeforepbLineitem.Image = ((System.Drawing.Image)(resources.GetObject("btnInsBeforepbLineitem.Image")));
            this.btnInsBeforepbLineitem.Location = new System.Drawing.Point(0, 686);
            this.btnInsBeforepbLineitem.Name = "btnInsBeforepbLineitem";
            this.btnInsBeforepbLineitem.Size = new System.Drawing.Size(32, 27);
            this.btnInsBeforepbLineitem.TabIndex = 51;
            this.btnInsBeforepbLineitem.Tag = "Lineitem";
            this.btnInsBeforepbLineitem.UseVisualStyleBackColor = true;
            // 
            // btnInsAfterpbLineitem
            // 
            this.btnInsAfterpbLineitem.Image = ((System.Drawing.Image)(resources.GetObject("btnInsAfterpbLineitem.Image")));
            this.btnInsAfterpbLineitem.Location = new System.Drawing.Point(38, 686);
            this.btnInsAfterpbLineitem.Name = "btnInsAfterpbLineitem";
            this.btnInsAfterpbLineitem.Size = new System.Drawing.Size(32, 27);
            this.btnInsAfterpbLineitem.TabIndex = 52;
            this.btnInsAfterpbLineitem.Tag = "Lineitem";
            this.btnInsAfterpbLineitem.UseVisualStyleBackColor = true;
            // 
            // btnDelpbLineitem
            // 
            this.btnDelpbLineitem.Image = ((System.Drawing.Image)(resources.GetObject("btnDelpbLineitem.Image")));
            this.btnDelpbLineitem.Location = new System.Drawing.Point(76, 686);
            this.btnDelpbLineitem.Name = "btnDelpbLineitem";
            this.btnDelpbLineitem.Size = new System.Drawing.Size(32, 27);
            this.btnDelpbLineitem.TabIndex = 53;
            this.btnDelpbLineitem.Tag = "Lineitem";
            this.btnDelpbLineitem.UseVisualStyleBackColor = true;
            // 
            // dcimCurrentLine
            // 
            this.dcimCurrentLine.Location = new System.Drawing.Point(3, 393);
            this.dcimCurrentLine.Name = "dcimCurrentLine";
            this.dcimCurrentLine.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimCurrentLine.OcxState")));
            this.dcimCurrentLine.Size = new System.Drawing.Size(743, 53);
            this.dcimCurrentLine.TabIndex = 43;
            this.dcimCurrentLine.TabStop = false;
            this.dcimCurrentLine.Tag = "Vendor";
            // 
            // comboBoxInvoice_Type
            // 
            this.comboBoxInvoice_Type.BackColor = System.Drawing.Color.PowderBlue;
            this.comboBoxInvoice_Type.FormattingEnabled = true;
            this.comboBoxInvoice_Type.Location = new System.Drawing.Point(606, 217);
            this.comboBoxInvoice_Type.Name = "comboBoxInvoice_Type";
            this.comboBoxInvoice_Type.Size = new System.Drawing.Size(140, 21);
            this.comboBoxInvoice_Type.TabIndex = 35;
            this.comboBoxInvoice_Type.Tag = "Invoice_Type";
            // 
            // comboBoxAdd_New_Fingerprint
            // 
            this.comboBoxAdd_New_Fingerprint.BackColor = System.Drawing.Color.PowderBlue;
            this.comboBoxAdd_New_Fingerprint.FormattingEnabled = true;
            this.comboBoxAdd_New_Fingerprint.Location = new System.Drawing.Point(605, 256);
            this.comboBoxAdd_New_Fingerprint.Name = "comboBoxAdd_New_Fingerprint";
            this.comboBoxAdd_New_Fingerprint.Size = new System.Drawing.Size(141, 21);
            this.comboBoxAdd_New_Fingerprint.TabIndex = 37;
            this.comboBoxAdd_New_Fingerprint.Tag = "Add_New_Fingerprint";
            // 
            // comboBoxRouting_Instructions
            // 
            this.comboBoxRouting_Instructions.BackColor = System.Drawing.Color.PowderBlue;
            this.comboBoxRouting_Instructions.FormattingEnabled = true;
            this.comboBoxRouting_Instructions.Location = new System.Drawing.Point(606, 296);
            this.comboBoxRouting_Instructions.Name = "comboBoxRouting_Instructions";
            this.comboBoxRouting_Instructions.Size = new System.Drawing.Size(140, 21);
            this.comboBoxRouting_Instructions.TabIndex = 39;
            this.comboBoxRouting_Instructions.Tag = "Routing_Instructions";
            // 
            // comboBoxLanguage
            // 
            this.comboBoxLanguage.BackColor = System.Drawing.Color.PowderBlue;
            this.comboBoxLanguage.FormattingEnabled = true;
            this.comboBoxLanguage.Location = new System.Drawing.Point(606, 337);
            this.comboBoxLanguage.Name = "comboBoxLanguage";
            this.comboBoxLanguage.Size = new System.Drawing.Size(140, 21);
            this.comboBoxLanguage.TabIndex = 41;
            this.comboBoxLanguage.SelectedIndexChanged += new System.EventHandler(this.comboBoxLanguage_SelectedIndexChanged);
            // 
            // lblLanguage
            // 
            this.lblLanguage.AutoSize = true;
            this.lblLanguage.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLanguage.Location = new System.Drawing.Point(603, 322);
            this.lblLanguage.Name = "lblLanguage";
            this.lblLanguage.Size = new System.Drawing.Size(70, 14);
            this.lblLanguage.TabIndex = 40;
            this.lblLanguage.Text = "Language";
            // 
            // btnOCR
            // 
            this.btnOCR.Font = new System.Drawing.Font("Impact", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOCR.Location = new System.Drawing.Point(605, 361);
            this.btnOCR.Name = "btnOCR";
            this.btnOCR.Size = new System.Drawing.Size(49, 27);
            this.btnOCR.TabIndex = 42;
            this.btnOCR.Text = "OCR";
            this.btnOCR.UseVisualStyleBackColor = true;
            this.btnOCR.Click += new System.EventHandler(this.btnOCR_Click);
            // 
            // POLRBtn
            // 
            this.POLRBtn.Location = new System.Drawing.Point(5, 34);
            this.POLRBtn.Name = "POLRBtn";
            this.POLRBtn.Size = new System.Drawing.Size(105, 23);
            this.POLRBtn.TabIndex = 0;
            this.POLRBtn.Text = "POLR";
            this.POLRBtn.UseVisualStyleBackColor = true;
            this.POLRBtn.Click += new System.EventHandler(this.POLRBtn_Click);
            // 
            // StickyBtn
            // 
            this.StickyBtn.Location = new System.Drawing.Point(118, 34);
            this.StickyBtn.Name = "StickyBtn";
            this.StickyBtn.Size = new System.Drawing.Size(105, 23);
            this.StickyBtn.TabIndex = 1;
            this.StickyBtn.Text = "Sticky";
            this.StickyBtn.UseVisualStyleBackColor = true;
            this.StickyBtn.Click += new System.EventHandler(this.StickyBtn_Click);
            // 
            // lblLineitem
            // 
            this.lblLineitem.AutoSize = true;
            this.lblLineitem.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblLineitem.Location = new System.Drawing.Point(115, 693);
            this.lblLineitem.Name = "lblLineitem";
            this.lblLineitem.Size = new System.Drawing.Size(60, 14);
            this.lblLineitem.TabIndex = 54;
            this.lblLineitem.Text = "Lineitem";
            // 
            // dcedVendor
            // 
            this.dcedVendor.Location = new System.Drawing.Point(3, 78);
            this.dcedVendor.Name = "dcedVendor";
            this.dcedVendor.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedVendor.OcxState")));
            this.dcedVendor.Size = new System.Drawing.Size(342, 27);
            this.dcedVendor.TabIndex = 3;
            this.dcedVendor.Tag = "Vendor";
            // 
            // dcedVendor_Number
            // 
            this.dcedVendor_Number.Location = new System.Drawing.Point(351, 78);
            this.dcedVendor_Number.Name = "dcedVendor_Number";
            this.dcedVendor_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedVendor_Number.OcxState")));
            this.dcedVendor_Number.Size = new System.Drawing.Size(117, 27);
            this.dcedVendor_Number.TabIndex = 5;
            this.dcedVendor_Number.Tag = "Vendor_Number";
            // 
            // dcedRemittance_Zip
            // 
            this.dcedRemittance_Zip.Location = new System.Drawing.Point(474, 78);
            this.dcedRemittance_Zip.Name = "dcedRemittance_Zip";
            this.dcedRemittance_Zip.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedRemittance_Zip.OcxState")));
            this.dcedRemittance_Zip.Size = new System.Drawing.Size(122, 27);
            this.dcedRemittance_Zip.TabIndex = 8;
            this.dcedRemittance_Zip.Tag = "Remittance_Zip";
            // 
            // dcedInvoice_Number
            // 
            this.dcedInvoice_Number.Location = new System.Drawing.Point(602, 78);
            this.dcedInvoice_Number.Name = "dcedInvoice_Number";
            this.dcedInvoice_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedInvoice_Number.OcxState")));
            this.dcedInvoice_Number.Size = new System.Drawing.Size(144, 27);
            this.dcedInvoice_Number.TabIndex = 11;
            this.dcedInvoice_Number.Tag = "Invoice_Number";
            // 
            // dcedInvoice_Date
            // 
            this.dcedInvoice_Date.Location = new System.Drawing.Point(3, 167);
            this.dcedInvoice_Date.Name = "dcedInvoice_Date";
            this.dcedInvoice_Date.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedInvoice_Date.OcxState")));
            this.dcedInvoice_Date.Size = new System.Drawing.Size(136, 27);
            this.dcedInvoice_Date.TabIndex = 14;
            this.dcedInvoice_Date.Tag = "Invoice_Date";
            // 
            // dcedPO_Number
            // 
            this.dcedPO_Number.Location = new System.Drawing.Point(145, 167);
            this.dcedPO_Number.Name = "dcedPO_Number";
            this.dcedPO_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedPO_Number.OcxState")));
            this.dcedPO_Number.Size = new System.Drawing.Size(200, 27);
            this.dcedPO_Number.TabIndex = 17;
            this.dcedPO_Number.Tag = "PO_Number";
            // 
            // dcedShipping
            // 
            this.dcedShipping.Location = new System.Drawing.Point(351, 167);
            this.dcedShipping.Name = "dcedShipping";
            this.dcedShipping.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedShipping.OcxState")));
            this.dcedShipping.Size = new System.Drawing.Size(117, 27);
            this.dcedShipping.TabIndex = 20;
            this.dcedShipping.Tag = "Shipping";
            // 
            // dcedInvoice_Type
            // 
            this.dcedInvoice_Type.Location = new System.Drawing.Point(946, 308);
            this.dcedInvoice_Type.Name = "dcedInvoice_Type";
            this.dcedInvoice_Type.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedInvoice_Type.OcxState")));
            this.dcedInvoice_Type.Size = new System.Drawing.Size(158, 27);
            this.dcedInvoice_Type.TabIndex = 61;
            this.dcedInvoice_Type.Tag = "Invoice_Type";
            this.dcedInvoice_Type.Visible = false;
            // 
            // dcedTax
            // 
            this.dcedTax.Location = new System.Drawing.Point(474, 167);
            this.dcedTax.Name = "dcedTax";
            this.dcedTax.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedTax.OcxState")));
            this.dcedTax.Size = new System.Drawing.Size(122, 27);
            this.dcedTax.TabIndex = 23;
            this.dcedTax.Tag = "Tax";
            // 
            // dcedInvoice_Total
            // 
            this.dcedInvoice_Total.Location = new System.Drawing.Point(602, 167);
            this.dcedInvoice_Total.Name = "dcedInvoice_Total";
            this.dcedInvoice_Total.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedInvoice_Total.OcxState")));
            this.dcedInvoice_Total.Size = new System.Drawing.Size(141, 27);
            this.dcedInvoice_Total.TabIndex = 26;
            this.dcedInvoice_Total.Tag = "Invoice_Total";
            // 
            // dcedAdd_New_Fingerprint
            // 
            this.dcedAdd_New_Fingerprint.Location = new System.Drawing.Point(945, 360);
            this.dcedAdd_New_Fingerprint.Name = "dcedAdd_New_Fingerprint";
            this.dcedAdd_New_Fingerprint.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedAdd_New_Fingerprint.OcxState")));
            this.dcedAdd_New_Fingerprint.Size = new System.Drawing.Size(159, 27);
            this.dcedAdd_New_Fingerprint.TabIndex = 62;
            this.dcedAdd_New_Fingerprint.Tag = "Add_New_Fingerprint";
            this.dcedAdd_New_Fingerprint.Visible = false;
            // 
            // dcedRouting_Instructions
            // 
            this.dcedRouting_Instructions.Location = new System.Drawing.Point(946, 419);
            this.dcedRouting_Instructions.Name = "dcedRouting_Instructions";
            this.dcedRouting_Instructions.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedRouting_Instructions.OcxState")));
            this.dcedRouting_Instructions.Size = new System.Drawing.Size(158, 27);
            this.dcedRouting_Instructions.TabIndex = 63;
            this.dcedRouting_Instructions.Tag = "Routing_Instructions";
            this.dcedRouting_Instructions.Visible = false;
            // 
            // dcedTIFF
            // 
            this.dcedTIFF.Location = new System.Drawing.Point(820, 240);
            this.dcedTIFF.Name = "dcedTIFF";
            this.dcedTIFF.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedTIFF.OcxState")));
            this.dcedTIFF.Size = new System.Drawing.Size(200, 27);
            this.dcedTIFF.TabIndex = 60;
            this.dcedTIFF.Tag = "TIFF";
            this.dcedTIFF.Visible = false;
            // 
            // scrLineitem
            // 
            this.scrLineitem.Dock = System.Windows.Forms.DockStyle.Right;
            this.scrLineitem.Location = new System.Drawing.Point(722, 0);
            this.scrLineitem.Name = "scrLineitem";
            this.scrLineitem.Size = new System.Drawing.Size(17, 210);
            this.scrLineitem.TabIndex = 6;
            this.scrLineitem.Tag = "Lineitem";
            // 
            // APT_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.ClientSize = new System.Drawing.Size(1297, 874);
            this.Controls.Add(this.lblLineitem);
            this.Controls.Add(this.StickyBtn);
            this.Controls.Add(this.POLRBtn);
            this.Controls.Add(this.btnOCR);
            this.Controls.Add(this.lblLanguage);
            this.Controls.Add(this.comboBoxLanguage);
            this.Controls.Add(this.comboBoxRouting_Instructions);
            this.Controls.Add(this.comboBoxAdd_New_Fingerprint);
            this.Controls.Add(this.comboBoxInvoice_Type);
            this.Controls.Add(this.dcimCurrentLine);
            this.Controls.Add(this.lblVendor);
            this.Controls.Add(this.dcimTaxDetail);
            this.Controls.Add(this.dcedVendor);
            this.Controls.Add(this.lblVendor_Number);
            this.Controls.Add(this.dcimVendor_Number);
            this.Controls.Add(this.dcedVendor_Number);
            this.Controls.Add(this.lblRemittance_Zip);
            this.Controls.Add(this.dcimRemittance_Zip);
            this.Controls.Add(this.dcedRemittance_Zip);
            this.Controls.Add(this.lblInvoice_Number);
            this.Controls.Add(this.dcimInvoice_Number);
            this.Controls.Add(this.dcedInvoice_Number);
            this.Controls.Add(this.lblInvoice_Date);
            this.Controls.Add(this.dcimInvoice_Date);
            this.Controls.Add(this.dcedInvoice_Date);
            this.Controls.Add(this.lblPO_Number);
            this.Controls.Add(this.dcimPO_Number);
            this.Controls.Add(this.dcedPO_Number);
            this.Controls.Add(this.lblShipping);
            this.Controls.Add(this.dcimShipping);
            this.Controls.Add(this.dcedShipping);
            this.Controls.Add(this.lblInvoice_Type);
            this.Controls.Add(this.dcimInvoice_Type);
            this.Controls.Add(this.dcedInvoice_Type);
            this.Controls.Add(this.lbTax_Type);
            this.Controls.Add(this.lbTax_Value);
            this.Controls.Add(this.panTaxLineitem);
            this.Controls.Add(this.btnDelpbTaxLineitem);
            this.Controls.Add(this.btnInsAfterpbTaxLineitem);
            this.Controls.Add(this.btnInsBeforepbTaxLineitem);
            this.Controls.Add(this.lblTax);
            this.Controls.Add(this.dcimTax);
            this.Controls.Add(this.dcedTax);
            this.Controls.Add(this.lblInvoice_Total);
            this.Controls.Add(this.dcimInvoice_Total);
            this.Controls.Add(this.dcedInvoice_Total);
            this.Controls.Add(this.lblAdd_New_Fingerprint);
            this.Controls.Add(this.dcimAdd_New_Fingerprint);
            this.Controls.Add(this.dcedAdd_New_Fingerprint);
            this.Controls.Add(this.lblRouting_Instructions);
            this.Controls.Add(this.dcimRouting_Instructions);
            this.Controls.Add(this.dcedRouting_Instructions);
            this.Controls.Add(this.dcimTIFF);
            this.Controls.Add(this.dcedTIFF);
            this.Controls.Add(this.lbItemID);
            this.Controls.Add(this.lbItemDesc);
            this.Controls.Add(this.lbQty);
            this.Controls.Add(this.lbPrice);
            this.Controls.Add(this.lbLineTotal);
            this.Controls.Add(this.lbPOLineNum);
            this.Controls.Add(this.panLineitem);
            this.Controls.Add(this.btnDelpbLineitem);
            this.Controls.Add(this.btnInsAfterpbLineitem);
            this.Controls.Add(this.btnInsBeforepbLineitem);
            this.Name = "APT_Main";
            this.Load += new System.EventHandler(this.APT_Main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dcimTaxDetail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimVendor_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimRemittance_Zip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Date)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimPO_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimShipping)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Type)).EndInit();
            this.panTaxLineitem.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dcedTax_Type)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTax_Value)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimTax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimInvoice_Total)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimAdd_New_Fingerprint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimRouting_Instructions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimTIFF)).EndInit();
            this.panLineitem.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dcedItemID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedItemDesc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedQty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedLineTotal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPOLineNum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCurrentLine)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedVendor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedVendor_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedRemittance_Zip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Date)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPO_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedShipping)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Type)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Total)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedAdd_New_Fingerprint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedRouting_Instructions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTIFF)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
                        private System.Windows.Forms.Label lblVendor;
                                private AxDCIMAGELib.AxDcimage dcimTaxDetail;
                                private AxDCEDITLib.AxDcedit dcedVendor;
                                private System.Windows.Forms.Label lblVendor_Number;
                                private AxDCIMAGELib.AxDcimage dcimVendor_Number;
                                private AxDCEDITLib.AxDcedit dcedVendor_Number;
                                private System.Windows.Forms.Label lblRemittance_Zip;
                                private AxDCIMAGELib.AxDcimage dcimRemittance_Zip;
                                private AxDCEDITLib.AxDcedit dcedRemittance_Zip;
                                private System.Windows.Forms.Label lblInvoice_Number;
                                private AxDCIMAGELib.AxDcimage dcimInvoice_Number;
                                private AxDCEDITLib.AxDcedit dcedInvoice_Number;
                                private System.Windows.Forms.Label lblInvoice_Date;
                                private AxDCIMAGELib.AxDcimage dcimInvoice_Date;
                                private AxDCEDITLib.AxDcedit dcedInvoice_Date;
                                private System.Windows.Forms.Label lblPO_Number;
                                private AxDCIMAGELib.AxDcimage dcimPO_Number;
                                private AxDCEDITLib.AxDcedit dcedPO_Number;
                                private System.Windows.Forms.Label lblShipping;
                                private AxDCIMAGELib.AxDcimage dcimShipping;
                                private AxDCEDITLib.AxDcedit dcedShipping;
                                private System.Windows.Forms.Label lblInvoice_Type;
                                private AxDCIMAGELib.AxDcimage dcimInvoice_Type;
                                private AxDCEDITLib.AxDcedit dcedInvoice_Type;
                                private System.Windows.Forms.Label lbTax_Type;
                                private System.Windows.Forms.Label lbTax_Value;
                              private System.Windows.Forms.Panel panTaxLineitem;
                                private System.Windows.Forms.Button btnInsBeforepbTaxLineitem;
        private System.Windows.Forms.Button btnInsAfterpbTaxLineitem;
        private System.Windows.Forms.Button btnDelpbTaxLineitem;
        private AxDCEDITLib.AxDcedit dcedTax_Type;
                                private AxDCEDITLib.AxDcedit dcedTax_Value;
                                private System.Windows.Forms.Label lblTax;
                                private AxDCIMAGELib.AxDcimage dcimTax;
                                private AxDCEDITLib.AxDcedit dcedTax;
                                private System.Windows.Forms.Label lblInvoice_Total;
                                private AxDCIMAGELib.AxDcimage dcimInvoice_Total;
                                private AxDCEDITLib.AxDcedit dcedInvoice_Total;
                                private System.Windows.Forms.Label lblAdd_New_Fingerprint;
                                private AxDCIMAGELib.AxDcimage dcimAdd_New_Fingerprint;
                                private AxDCEDITLib.AxDcedit dcedAdd_New_Fingerprint;
                                private System.Windows.Forms.Label lblRouting_Instructions;
                                private AxDCIMAGELib.AxDcimage dcimRouting_Instructions;
                                private AxDCEDITLib.AxDcedit dcedRouting_Instructions;
                                private AxDCIMAGELib.AxDcimage dcimTIFF;
                                private AxDCEDITLib.AxDcedit dcedTIFF;
                                private System.Windows.Forms.Label lbItemID;
                                private System.Windows.Forms.Label lbItemDesc;
                                private System.Windows.Forms.Label lbQty;
                                private System.Windows.Forms.Label lbPrice;
                                private System.Windows.Forms.Label lbLineTotal;
                                private System.Windows.Forms.Label lbPOLineNum;
                              private System.Windows.Forms.Panel panLineitem;
                                private System.Windows.Forms.Button btnInsBeforepbLineitem;
        private System.Windows.Forms.Button btnInsAfterpbLineitem;
        private System.Windows.Forms.Button btnDelpbLineitem;
        private AxDCEDITLib.AxDcedit dcedItemID;
        private AxDCEDITLib.AxDcedit dcedItemDesc;
        private AxDCEDITLib.AxDcedit dcedQty;
        private AxDCEDITLib.AxDcedit dcedPrice;
        private AxDCEDITLib.AxDcedit dcedLineTotal;
        private AxDCEDITLib.AxDcedit dcedPOLineNum;
                                private AxDCIMAGELib.AxDcimage dcimCurrentLine;
                                private System.Windows.Forms.ComboBox comboBoxInvoice_Type;
                                private System.Windows.Forms.ComboBox comboBoxAdd_New_Fingerprint;
                                private System.Windows.Forms.ComboBox comboBoxRouting_Instructions;
                                private System.Windows.Forms.ComboBox comboBoxLanguage;
                                private System.Windows.Forms.Label lblLanguage;
                                private System.Windows.Forms.Button btnOCR;
                                private System.Windows.Forms.Button POLRBtn;
                                private System.Windows.Forms.Button StickyBtn;
                                private System.Windows.Forms.Label lblLineitem;
                                private System.Windows.Forms.VScrollBar scrLineitem;
                        
    }
}
                