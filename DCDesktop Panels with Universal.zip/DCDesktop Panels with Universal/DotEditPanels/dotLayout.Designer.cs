namespace DotEditPanels
{
    partial class dotLayout
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            AxDCIMAGELib.AxDcimage dcimage;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dotLayout));
            AxDCIMAGELib.AxDcimage dcimresize;
            this.dclistbox = new System.Windows.Forms.ListBox();
            this.dccombobox = new System.Windows.Forms.ComboBox();
            this.dclabel = new System.Windows.Forms.Label();
            this.dcedit = new AxDCEDITLib.AxDcedit();
            this.dcedresize = new AxDCEDITLib.AxDcedit();
            dcimage = new AxDCIMAGELib.AxDcimage();
            dcimresize = new AxDCIMAGELib.AxDcimage();
            ((System.ComponentModel.ISupportInitialize)(dcimage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(dcimresize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedresize)).BeginInit();
            this.SuspendLayout();
            // 
            // dcimage
            // 
            dcimage.Location = new System.Drawing.Point(20, 33);
            dcimage.Name = "dcimage";
            dcimage.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
            dcimage.Size = new System.Drawing.Size(200, 29);
            dcimage.TabIndex = 16;
            dcimage.TabStop = false;
            // 
            // dclistbox
            // 
            this.dclistbox.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dclistbox.FormattingEnabled = true;
            this.dclistbox.ItemHeight = 18;
            this.dclistbox.Location = new System.Drawing.Point(20, 150);
            this.dclistbox.Name = "dclistbox";
            this.dclistbox.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.dclistbox.Size = new System.Drawing.Size(200, 58);
            this.dclistbox.TabIndex = 19;
            // 
            // dccombobox
            // 
            this.dccombobox.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dccombobox.FormattingEnabled = true;
            this.dccombobox.Location = new System.Drawing.Point(20, 118);
            this.dccombobox.Name = "dccombobox";
            this.dccombobox.Size = new System.Drawing.Size(200, 26);
            this.dccombobox.TabIndex = 18;
            // 
            // dclabel
            // 
            this.dclabel.AutoSize = true;
            this.dclabel.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dclabel.Location = new System.Drawing.Point(17, 16);
            this.dclabel.Name = "dclabel";
            this.dclabel.Size = new System.Drawing.Size(45, 14);
            this.dclabel.TabIndex = 17;
            this.dclabel.Text = "label1";
            // 
            // dcedit
            // 
            this.dcedit.Location = new System.Drawing.Point(20, 66);
            this.dcedit.Name = "dcedit";
            this.dcedit.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedit.OcxState")));
            this.dcedit.Size = new System.Drawing.Size(200, 27);
            this.dcedit.TabIndex = 15;
            // 
            // dcimresize
            // 
            dcimresize.Location = new System.Drawing.Point(20, 214);
            dcimresize.Name = "dcimresize";
            dcimresize.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimresize.OcxState")));
            dcimresize.Size = new System.Drawing.Size(1, 1);
            dcimresize.TabIndex = 21;
            dcimresize.TabStop = false;
            // 
            // dcedresize
            // 
            this.dcedresize.Location = new System.Drawing.Point(20, 247);
            this.dcedresize.Name = "dcedresize";
            this.dcedresize.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedresize.OcxState")));
            this.dcedresize.Size = new System.Drawing.Size(1, 1);
            this.dcedresize.TabIndex = 20;
            // 
            // dotLayout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(dcimresize);
            this.Controls.Add(this.dcedresize);
            this.Controls.Add(this.dclistbox);
            this.Controls.Add(this.dccombobox);
            this.Controls.Add(this.dclabel);
            this.Controls.Add(dcimage);
            this.Controls.Add(this.dcedit);
            this.Name = "dotLayout";
            this.Size = new System.Drawing.Size(246, 299);
            ((System.ComponentModel.ISupportInitialize)(dcimage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(dcimresize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedresize)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox dclistbox;
        private System.Windows.Forms.ComboBox dccombobox;
        private System.Windows.Forms.Label dclabel;
        private AxDCEDITLib.AxDcedit dcedit;
        private AxDCEDITLib.AxDcedit dcedresize;


    }
}
