
namespace DotEditPanels
{
    partial class N_MainPage
    {
        /// 
        /// Required designer variable.
        /// 
        private System.ComponentModel.IContainer components = null;

        /// 
        /// Clean up any resources being used.
        /// 
        /// true if managed resources should be disposed; otherwise, false.
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// 
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(N_MainPage));
            this.lblEntity = new System.Windows.Forms.Label();
            this.lblPrimaryUser = new System.Windows.Forms.Label();
            this.lblFunction = new System.Windows.Forms.Label();
            this.lblRegion = new System.Windows.Forms.Label();
            this.lblState = new System.Windows.Forms.Label();
            this.lblCity = new System.Windows.Forms.Label();
            this.lblDocumentType = new System.Windows.Forms.Label();
            this.lblIssueDate = new System.Windows.Forms.Label();
            this.lblTenure = new System.Windows.Forms.Label();
            this.lblLicensors = new System.Windows.Forms.Label();
            this.lblPropertyAddress = new System.Windows.Forms.Label();
            this.lblUniqueCode = new System.Windows.Forms.Label();
            this.lblVendorName = new System.Windows.Forms.Label();
            this.cmb_UniqueCode = new System.Windows.Forms.ComboBox();
            this.cmb_Function = new System.Windows.Forms.ComboBox();
            this.cmb_DocumentType = new System.Windows.Forms.ComboBox();
            this.dtp_IssueDate = new System.Windows.Forms.DateTimePicker();
            this.cmb_VendorName = new System.Windows.Forms.ComboBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.LstUniqueCode = new System.Windows.Forms.ListBox();
            this.LstDocumentType = new System.Windows.Forms.ListBox();
            this.dcedEntity = new AxDCEDITLib.AxDcedit();
            this.dcedPrimaryUser = new AxDCEDITLib.AxDcedit();
            this.dcedFunction = new AxDCEDITLib.AxDcedit();
            this.dcedRegion = new AxDCEDITLib.AxDcedit();
            this.dcedState = new AxDCEDITLib.AxDcedit();
            this.dcedCity = new AxDCEDITLib.AxDcedit();
            this.dcedDocumentType = new AxDCEDITLib.AxDcedit();
            this.dcedIssueDate = new AxDCEDITLib.AxDcedit();
            this.dcedTenure = new AxDCEDITLib.AxDcedit();
            this.dcedLicensors = new AxDCEDITLib.AxDcedit();
            this.dcedPropertyAddress = new AxDCEDITLib.AxDcedit();
            this.dcedUniqueCode = new AxDCEDITLib.AxDcedit();
            this.dcedVendorName = new AxDCEDITLib.AxDcedit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedEntity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPrimaryUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedFunction)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedRegion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedState)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDocumentType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedIssueDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTenure)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedLicensors)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPropertyAddress)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedUniqueCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedVendorName)).BeginInit();
            this.SuspendLayout();
            // 
            // lblEntity
            // 
            this.lblEntity.AutoSize = true;
            this.lblEntity.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEntity.Location = new System.Drawing.Point(117, 30);
            this.lblEntity.Name = "lblEntity";
            this.lblEntity.Size = new System.Drawing.Size(55, 14);
            this.lblEntity.TabIndex = 0;
            this.lblEntity.Tag = "Entity";
            this.lblEntity.Text = "Entity *";
            // 
            // lblPrimaryUser
            // 
            this.lblPrimaryUser.AutoSize = true;
            this.lblPrimaryUser.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrimaryUser.Location = new System.Drawing.Point(438, 73);
            this.lblPrimaryUser.Name = "lblPrimaryUser";
            this.lblPrimaryUser.Size = new System.Drawing.Size(99, 14);
            this.lblPrimaryUser.TabIndex = 3;
            this.lblPrimaryUser.Tag = "PrimaryUser";
            this.lblPrimaryUser.Text = "Primary User *";
            // 
            // lblFunction
            // 
            this.lblFunction.AutoSize = true;
            this.lblFunction.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFunction.Location = new System.Drawing.Point(100, 75);
            this.lblFunction.Name = "lblFunction";
            this.lblFunction.Size = new System.Drawing.Size(72, 14);
            this.lblFunction.TabIndex = 6;
            this.lblFunction.Tag = "Function";
            this.lblFunction.Text = "Function *";
            // 
            // lblRegion
            // 
            this.lblRegion.AutoSize = true;
            this.lblRegion.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegion.Location = new System.Drawing.Point(475, 120);
            this.lblRegion.Name = "lblRegion";
            this.lblRegion.Size = new System.Drawing.Size(62, 14);
            this.lblRegion.TabIndex = 9;
            this.lblRegion.Tag = "Region";
            this.lblRegion.Text = "Region *";
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblState.Location = new System.Drawing.Point(119, 169);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(53, 14);
            this.lblState.TabIndex = 12;
            this.lblState.Tag = "State";
            this.lblState.Text = "State *";
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCity.Location = new System.Drawing.Point(494, 168);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(43, 14);
            this.lblCity.TabIndex = 15;
            this.lblCity.Tag = "City";
            this.lblCity.Text = "City *";
            // 
            // lblDocumentType
            // 
            this.lblDocumentType.AutoSize = true;
            this.lblDocumentType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDocumentType.Location = new System.Drawing.Point(57, 117);
            this.lblDocumentType.Name = "lblDocumentType";
            this.lblDocumentType.Size = new System.Drawing.Size(115, 14);
            this.lblDocumentType.TabIndex = 18;
            this.lblDocumentType.Tag = "DocumentType";
            this.lblDocumentType.Text = "Document Type *";
            // 
            // lblIssueDate
            // 
            this.lblIssueDate.AutoSize = true;
            this.lblIssueDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIssueDate.Location = new System.Drawing.Point(84, 212);
            this.lblIssueDate.Name = "lblIssueDate";
            this.lblIssueDate.Size = new System.Drawing.Size(88, 14);
            this.lblIssueDate.TabIndex = 21;
            this.lblIssueDate.Tag = "IssueDate";
            this.lblIssueDate.Text = "Issue Date *";
            // 
            // lblTenure
            // 
            this.lblTenure.AutoSize = true;
            this.lblTenure.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenure.Location = new System.Drawing.Point(476, 260);
            this.lblTenure.Name = "lblTenure";
            this.lblTenure.Size = new System.Drawing.Size(62, 14);
            this.lblTenure.TabIndex = 24;
            this.lblTenure.Tag = "Tenure";
            this.lblTenure.Text = "Tenure *";
            // 
            // lblLicensors
            // 
            this.lblLicensors.AutoSize = true;
            this.lblLicensors.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLicensors.Location = new System.Drawing.Point(460, 214);
            this.lblLicensors.Name = "lblLicensors";
            this.lblLicensors.Size = new System.Drawing.Size(78, 14);
            this.lblLicensors.TabIndex = 27;
            this.lblLicensors.Tag = "Licensors";
            this.lblLicensors.Text = "Licensors *";
            // 
            // lblPropertyAddress
            // 
            this.lblPropertyAddress.AutoSize = true;
            this.lblPropertyAddress.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPropertyAddress.Location = new System.Drawing.Point(44, 260);
            this.lblPropertyAddress.Name = "lblPropertyAddress";
            this.lblPropertyAddress.Size = new System.Drawing.Size(128, 14);
            this.lblPropertyAddress.TabIndex = 30;
            this.lblPropertyAddress.Tag = "PropertyAddress";
            this.lblPropertyAddress.Text = "Property Address *";
            // 
            // lblUniqueCode
            // 
            this.lblUniqueCode.AutoSize = true;
            this.lblUniqueCode.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUniqueCode.Location = new System.Drawing.Point(437, 30);
            this.lblUniqueCode.Name = "lblUniqueCode";
            this.lblUniqueCode.Size = new System.Drawing.Size(100, 14);
            this.lblUniqueCode.TabIndex = 33;
            this.lblUniqueCode.Tag = "UniqueCode";
            this.lblUniqueCode.Text = "Unique Code *";
            // 
            // lblVendorName
            // 
            this.lblVendorName.AutoSize = true;
            this.lblVendorName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendorName.Location = new System.Drawing.Point(69, 214);
            this.lblVendorName.Name = "lblVendorName";
            this.lblVendorName.Size = new System.Drawing.Size(103, 14);
            this.lblVendorName.TabIndex = 36;
            this.lblVendorName.Tag = "VendorName";
            this.lblVendorName.Text = "Vendor Name *";
            // 
            // cmb_UniqueCode
            // 
            this.cmb_UniqueCode.FormattingEnabled = true;
            this.cmb_UniqueCode.Location = new System.Drawing.Point(545, 30);
            this.cmb_UniqueCode.Name = "cmb_UniqueCode";
            this.cmb_UniqueCode.Size = new System.Drawing.Size(200, 21);
            this.cmb_UniqueCode.TabIndex = 39;
            this.cmb_UniqueCode.SelectedIndexChanged += new System.EventHandler(this.cmb_UniqueCode_SelectedIndexChanged);
            this.cmb_UniqueCode.TextUpdate += new System.EventHandler(this.cmb_UniqueCode_TextUpdate);
            // 
            // cmb_Function
            // 
            this.cmb_Function.FormattingEnabled = true;
            this.cmb_Function.Location = new System.Drawing.Point(181, 71);
            this.cmb_Function.Name = "cmb_Function";
            this.cmb_Function.Size = new System.Drawing.Size(200, 21);
            this.cmb_Function.TabIndex = 40;
            this.cmb_Function.SelectedIndexChanged += new System.EventHandler(this.cmb_Function_SelectedIndexChanged);
            // 
            // cmb_DocumentType
            // 
            this.cmb_DocumentType.FormattingEnabled = true;
            this.cmb_DocumentType.Location = new System.Drawing.Point(181, 114);
            this.cmb_DocumentType.Name = "cmb_DocumentType";
            this.cmb_DocumentType.Size = new System.Drawing.Size(200, 21);
            this.cmb_DocumentType.TabIndex = 41;
            this.cmb_DocumentType.SelectedIndexChanged += new System.EventHandler(this.cmb_DocumentType_SelectedIndexChanged);
            this.cmb_DocumentType.TextUpdate += new System.EventHandler(this.cmb_DocumentType_TextUpdate);
            // 
            // dtp_IssueDate
            // 
            this.dtp_IssueDate.CustomFormat = "MM/dd/yyyy";
            this.dtp_IssueDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_IssueDate.Location = new System.Drawing.Point(387, 209);
            this.dtp_IssueDate.Name = "dtp_IssueDate";
            this.dtp_IssueDate.Size = new System.Drawing.Size(14, 20);
            this.dtp_IssueDate.TabIndex = 42;
            this.dtp_IssueDate.Value = new System.DateTime(2018, 9, 5, 0, 0, 0, 0);
            this.dtp_IssueDate.ValueChanged += new System.EventHandler(this.dtp_IssueDate_ValueChanged);
            // 
            // cmb_VendorName
            // 
            this.cmb_VendorName.FormattingEnabled = true;
            this.cmb_VendorName.Location = new System.Drawing.Point(181, 209);
            this.cmb_VendorName.Name = "cmb_VendorName";
            this.cmb_VendorName.Size = new System.Drawing.Size(200, 21);
            this.cmb_VendorName.TabIndex = 43;
            this.cmb_VendorName.SelectedIndexChanged += new System.EventHandler(this.cmb_VendorName_SelectedIndexChanged);
            // 
            // LstUniqueCode
            // 
            this.LstUniqueCode.FormattingEnabled = true;
            this.LstUniqueCode.Location = new System.Drawing.Point(545, 53);
            this.LstUniqueCode.Name = "LstUniqueCode";
            this.LstUniqueCode.Size = new System.Drawing.Size(200, 43);
            this.LstUniqueCode.TabIndex = 44;
            this.LstUniqueCode.Visible = false;
            this.LstUniqueCode.SelectedIndexChanged += new System.EventHandler(this.LstUniqueCode_SelectedIndexChanged);
            // 
            // LstDocumentType
            // 
            this.LstDocumentType.FormattingEnabled = true;
            this.LstDocumentType.Location = new System.Drawing.Point(181, 133);
            this.LstDocumentType.Name = "LstDocumentType";
            this.LstDocumentType.Size = new System.Drawing.Size(200, 56);
            this.LstDocumentType.TabIndex = 45;
            this.LstDocumentType.Visible = false;
            this.LstDocumentType.SelectedIndexChanged += new System.EventHandler(this.LstDocumentType_SelectedIndexChanged);
            // 
            // dcedEntity
            // 
            this.dcedEntity.Location = new System.Drawing.Point(181, 24);
            this.dcedEntity.Name = "dcedEntity";
            this.dcedEntity.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedEntity.OcxState")));
            this.dcedEntity.Size = new System.Drawing.Size(200, 27);
            this.dcedEntity.TabIndex = 2;
            this.dcedEntity.Tag = "Entity";
            // 
            // dcedPrimaryUser
            // 
            this.dcedPrimaryUser.Location = new System.Drawing.Point(545, 65);
            this.dcedPrimaryUser.Name = "dcedPrimaryUser";
            this.dcedPrimaryUser.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedPrimaryUser.OcxState")));
            this.dcedPrimaryUser.Size = new System.Drawing.Size(200, 27);
            this.dcedPrimaryUser.TabIndex = 5;
            this.dcedPrimaryUser.Tag = "PrimaryUser";
            // 
            // dcedFunction
            // 
            this.dcedFunction.Location = new System.Drawing.Point(181, 72);
            this.dcedFunction.Name = "dcedFunction";
            this.dcedFunction.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedFunction.OcxState")));
            this.dcedFunction.Size = new System.Drawing.Size(200, 20);
            this.dcedFunction.TabIndex = 8;
            this.dcedFunction.Tag = "Function";
            this.dcedFunction.Visible = false;
            // 
            // dcedRegion
            // 
            this.dcedRegion.Location = new System.Drawing.Point(545, 114);
            this.dcedRegion.Name = "dcedRegion";
            this.dcedRegion.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedRegion.OcxState")));
            this.dcedRegion.Size = new System.Drawing.Size(200, 27);
            this.dcedRegion.TabIndex = 11;
            this.dcedRegion.Tag = "Region";
            // 
            // dcedState
            // 
            this.dcedState.Location = new System.Drawing.Point(181, 162);
            this.dcedState.Name = "dcedState";
            this.dcedState.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedState.OcxState")));
            this.dcedState.Size = new System.Drawing.Size(200, 27);
            this.dcedState.TabIndex = 14;
            this.dcedState.Tag = "State";
            // 
            // dcedCity
            // 
            this.dcedCity.Location = new System.Drawing.Point(545, 161);
            this.dcedCity.Name = "dcedCity";
            this.dcedCity.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedCity.OcxState")));
            this.dcedCity.Size = new System.Drawing.Size(200, 27);
            this.dcedCity.TabIndex = 17;
            this.dcedCity.Tag = "City";
            // 
            // dcedDocumentType
            // 
            this.dcedDocumentType.Location = new System.Drawing.Point(181, 115);
            this.dcedDocumentType.Name = "dcedDocumentType";
            this.dcedDocumentType.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedDocumentType.OcxState")));
            this.dcedDocumentType.Size = new System.Drawing.Size(200, 21);
            this.dcedDocumentType.TabIndex = 20;
            this.dcedDocumentType.Tag = "DocumentType";
            this.dcedDocumentType.Visible = false;
            // 
            // dcedIssueDate
            // 
            this.dcedIssueDate.Location = new System.Drawing.Point(181, 207);
            this.dcedIssueDate.Name = "dcedIssueDate";
            this.dcedIssueDate.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedIssueDate.OcxState")));
            this.dcedIssueDate.Size = new System.Drawing.Size(200, 27);
            this.dcedIssueDate.TabIndex = 23;
            this.dcedIssueDate.Tag = "IssueDate";
            // 
            // dcedTenure
            // 
            this.dcedTenure.Location = new System.Drawing.Point(545, 255);
            this.dcedTenure.Name = "dcedTenure";
            this.dcedTenure.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedTenure.OcxState")));
            this.dcedTenure.Size = new System.Drawing.Size(200, 27);
            this.dcedTenure.TabIndex = 26;
            this.dcedTenure.Tag = "Tenure";
            // 
            // dcedLicensors
            // 
            this.dcedLicensors.Location = new System.Drawing.Point(545, 207);
            this.dcedLicensors.Name = "dcedLicensors";
            this.dcedLicensors.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedLicensors.OcxState")));
            this.dcedLicensors.Size = new System.Drawing.Size(200, 27);
            this.dcedLicensors.TabIndex = 29;
            this.dcedLicensors.Tag = "Licensors";
            // 
            // dcedPropertyAddress
            // 
            this.dcedPropertyAddress.Location = new System.Drawing.Point(181, 255);
            this.dcedPropertyAddress.Name = "dcedPropertyAddress";
            this.dcedPropertyAddress.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedPropertyAddress.OcxState")));
            this.dcedPropertyAddress.Size = new System.Drawing.Size(200, 27);
            this.dcedPropertyAddress.TabIndex = 32;
            this.dcedPropertyAddress.Tag = "PropertyAddress";
            // 
            // dcedUniqueCode
            // 
            this.dcedUniqueCode.Location = new System.Drawing.Point(545, 30);
            this.dcedUniqueCode.Name = "dcedUniqueCode";
            this.dcedUniqueCode.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedUniqueCode.OcxState")));
            this.dcedUniqueCode.Size = new System.Drawing.Size(200, 17);
            this.dcedUniqueCode.TabIndex = 35;
            this.dcedUniqueCode.Tag = "UniqueCode";
            this.dcedUniqueCode.Visible = false;
            // 
            // dcedVendorName
            // 
            this.dcedVendorName.Location = new System.Drawing.Point(181, 209);
            this.dcedVendorName.Name = "dcedVendorName";
            this.dcedVendorName.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedVendorName.OcxState")));
            this.dcedVendorName.Size = new System.Drawing.Size(200, 21);
            this.dcedVendorName.TabIndex = 38;
            this.dcedVendorName.Tag = "VendorName";
            this.dcedVendorName.Visible = false;
            // 
            // N_MainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1013, 741);
            this.Controls.Add(this.cmb_VendorName);
            this.Controls.Add(this.dtp_IssueDate);
            this.Controls.Add(this.cmb_DocumentType);
            this.Controls.Add(this.cmb_Function);
            this.Controls.Add(this.cmb_UniqueCode);
            this.Controls.Add(this.lblEntity);
            this.Controls.Add(this.dcedEntity);
            this.Controls.Add(this.lblPrimaryUser);
            this.Controls.Add(this.lblFunction);
            this.Controls.Add(this.dcedFunction);
            this.Controls.Add(this.lblRegion);
            this.Controls.Add(this.dcedRegion);
            this.Controls.Add(this.lblState);
            this.Controls.Add(this.lblCity);
            this.Controls.Add(this.dcedCity);
            this.Controls.Add(this.lblDocumentType);
            this.Controls.Add(this.dcedDocumentType);
            this.Controls.Add(this.lblIssueDate);
            this.Controls.Add(this.dcedIssueDate);
            this.Controls.Add(this.lblTenure);
            this.Controls.Add(this.dcedTenure);
            this.Controls.Add(this.lblLicensors);
            this.Controls.Add(this.dcedLicensors);
            this.Controls.Add(this.lblPropertyAddress);
            this.Controls.Add(this.dcedPropertyAddress);
            this.Controls.Add(this.lblUniqueCode);
            this.Controls.Add(this.dcedUniqueCode);
            this.Controls.Add(this.lblVendorName);
            this.Controls.Add(this.dcedVendorName);
            this.Controls.Add(this.LstDocumentType);
            this.Controls.Add(this.LstUniqueCode);
            this.Controls.Add(this.dcedPrimaryUser);
            this.Controls.Add(this.dcedState);
            this.Name = "N_MainPage";
            this.Load += new System.EventHandler(this.N_MainPage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dcedEntity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPrimaryUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedFunction)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedRegion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedState)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDocumentType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedIssueDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTenure)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedLicensors)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPropertyAddress)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedUniqueCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedVendorName)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblEntity;
                                private AxDCEDITLib.AxDcedit dcedEntity;
                                private System.Windows.Forms.Label lblPrimaryUser;
                                private AxDCEDITLib.AxDcedit dcedPrimaryUser;
                                private System.Windows.Forms.Label lblFunction;
                                private AxDCEDITLib.AxDcedit dcedFunction;
                                private System.Windows.Forms.Label lblRegion;
                                private AxDCEDITLib.AxDcedit dcedRegion;
                                private System.Windows.Forms.Label lblState;
                                private AxDCEDITLib.AxDcedit dcedState;
                                private System.Windows.Forms.Label lblCity;
                                private AxDCEDITLib.AxDcedit dcedCity;
                                private System.Windows.Forms.Label lblDocumentType;
                                private AxDCEDITLib.AxDcedit dcedDocumentType;
                                private System.Windows.Forms.Label lblIssueDate;
                                private AxDCEDITLib.AxDcedit dcedIssueDate;
                                private System.Windows.Forms.Label lblTenure;
                                private AxDCEDITLib.AxDcedit dcedTenure;
                                private System.Windows.Forms.Label lblLicensors;
                                private AxDCEDITLib.AxDcedit dcedLicensors;
                                private System.Windows.Forms.Label lblPropertyAddress;
                                private AxDCEDITLib.AxDcedit dcedPropertyAddress;
                                private System.Windows.Forms.Label lblUniqueCode;
                                private AxDCEDITLib.AxDcedit dcedUniqueCode;
                                private System.Windows.Forms.Label lblVendorName;
                                private AxDCEDITLib.AxDcedit dcedVendorName;
                                private System.Windows.Forms.ComboBox cmb_UniqueCode;
                                private System.Windows.Forms.ComboBox cmb_Function;
                                private System.Windows.Forms.ComboBox cmb_DocumentType;
                                private System.Windows.Forms.DateTimePicker dtp_IssueDate;
                                private System.Windows.Forms.ComboBox cmb_VendorName;
                                private System.Windows.Forms.ToolTip toolTip1;
                                private System.Windows.Forms.ListBox LstUniqueCode;
                                private System.Windows.Forms.ListBox LstDocumentType;
                        
    }
}
                