namespace DotEditPanels
{
    partial class Universal
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Universal));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblLabel = new System.Windows.Forms.Label();
            this.dcimDcim = new AxDCIMAGELib.AxDcimage();
            this.dcedDced = new AxDCEDITLib.AxDcedit();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.dclistbox = new System.Windows.Forms.ListBox();
            this.dccombobox = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.dg1 = new System.Windows.Forms.DataGridView();
            this.Pass = new System.Windows.Forms.DataGridViewImageColumn();
            this.FieldName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FieldValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDcim)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDced)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLabel
            // 
            resources.ApplyResources(this.lblLabel, "lblLabel");
            this.lblLabel.Name = "lblLabel";
            this.lblLabel.Tag = "";
            // 
            // dcimDcim
            // 
            this.dcimDcim.CausesValidation = false;
            resources.ApplyResources(this.dcimDcim, "dcimDcim");
            this.dcimDcim.Name = "dcimDcim";
            this.dcimDcim.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimDcim.OcxState")));
            this.dcimDcim.TabStop = false;
            this.dcimDcim.Tag = "";
            // 
            // dcedDced
            // 
            resources.ApplyResources(this.dcedDced, "dcedDced");
            this.dcedDced.Name = "dcedDced";
            this.dcedDced.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedDced.OcxState")));
            this.dcedDced.Tag = "";
            this.dcedDced.KeyDownEvent += new AxDCEDITLib._DDceditEvents_KeyDownEventHandler(this.dcedDced_KeyDownEvent);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "pass.gif");
            this.imageList1.Images.SetKeyName(1, "fail.gif");
            // 
            // dclistbox
            // 
            this.dclistbox.BackColor = System.Drawing.SystemColors.Control;
            this.dclistbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.dclistbox, "dclistbox");
            this.dclistbox.FormattingEnabled = true;
            this.dclistbox.Name = "dclistbox";
            this.dclistbox.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.dclistbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dclistbox_KeyDown);
            // 
            // dccombobox
            // 
            resources.ApplyResources(this.dccombobox, "dccombobox");
            this.dccombobox.FormattingEnabled = true;
            this.dccombobox.Name = "dccombobox";
            this.dccombobox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dccombobox_KeyDown);
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dg1
            // 
            this.dg1.AllowUserToAddRows = false;
            this.dg1.AllowUserToDeleteRows = false;
            this.dg1.AllowUserToResizeRows = false;
            this.dg1.BackgroundColor = System.Drawing.SystemColors.Desktop;
            this.dg1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 9F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(28)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dg1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dg1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Pass,
            this.FieldName,
            this.FieldValue});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Arial", 9F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(28)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dg1.DefaultCellStyle = dataGridViewCellStyle4;
            this.dg1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(141)))));
            resources.ApplyResources(this.dg1, "dg1");
            this.dg1.MultiSelect = false;
            this.dg1.Name = "dg1";
            this.dg1.ReadOnly = true;
            this.dg1.RowHeadersVisible = false;
            this.dg1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg1.ShowEditingIcon = false;
            this.dg1.TabStop = false;
            this.dg1.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg1_CellValueChanged);
            this.dg1.SelectionChanged += new System.EventHandler(this.dg1_SelectionChanged);
            // 
            // Pass
            // 
            resources.ApplyResources(this.Pass, "Pass");
            this.Pass.Name = "Pass";
            this.Pass.ReadOnly = true;
            // 
            // FieldName
            // 
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FieldName.DefaultCellStyle = dataGridViewCellStyle2;
            resources.ApplyResources(this.FieldName, "FieldName");
            this.FieldName.Name = "FieldName";
            this.FieldName.ReadOnly = true;
            // 
            // FieldValue
            // 
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FieldValue.DefaultCellStyle = dataGridViewCellStyle3;
            resources.ApplyResources(this.FieldValue, "FieldValue");
            this.FieldValue.Name = "FieldValue";
            this.FieldValue.ReadOnly = true;
            // 
            // Universal
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.Controls.Add(this.dg1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dclistbox);
            this.Controls.Add(this.dccombobox);
            this.Controls.Add(this.lblLabel);
            this.Controls.Add(this.dcimDcim);
            this.Controls.Add(this.dcedDced);
            this.Name = "Universal";
            ((System.ComponentModel.ISupportInitialize)(this.dcimDcim)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDced)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLabel;
        private AxDCIMAGELib.AxDcimage dcimDcim;
        private AxDCEDITLib.AxDcedit dcedDced;
        private System.Windows.Forms.ListBox dclistbox;
        private System.Windows.Forms.ComboBox dccombobox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.DataGridView dg1;
        private System.Windows.Forms.DataGridViewImageColumn Pass;
        private System.Windows.Forms.DataGridViewTextBoxColumn FieldName;
        private System.Windows.Forms.DataGridViewTextBoxColumn FieldValue;
    }
}
