//
// Licensed Materials - Property of IBM
// 5725-C15
// � Copyright IBM Corp. 1994, 2012 All Rights Reserved
// 
// US Government Users Restricted Rights - Use, duplication or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Xml;
using System.Text;
using System.Windows.Forms;
using dcDTlib;

namespace DotEditPanels
{
    public partial class Universal : dotPanelBase
    {
        public Universal()
        {
            InitializeComponent();
            RightToLeft = (System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.IsRightToLeft) ? RightToLeft.Yes : RightToLeft.No;
            RightToLeftLayout = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.IsRightToLeft;  // Set BiDi the same as we set language.

            nEdHight = dcedDced.Height;

        }

        public override bool LoadData(XmlDocument xPage)
        {
            bool bRes = base.LoadData(xPage);

            dcTask.SetSnippetFlags(true, true, 1.5);

            LoadDG();
            pCtrl = null;
            onNextLC();

            return bRes;
        }

        bool bLoadDG = false;

        protected bool LoadDG()
        {
            if (xDataPage == null)
                return false;
            bLoadDG = true;

            string xid = xDataPage.DocumentElement.Attributes["id"].Value; // Get the name of the current page.
            XmlNode xNode = dcTask.BatchXML.SelectSingleNode(".//P[@id='" + xid + "']");// Get the node for the current page            
            bool bRTL = Ishr_bidiRTL(xNode);                             // Set the panel direction based on the hr_bidi value for the page.        
            RightToLeft = bRTL ? RightToLeft.Yes : RightToLeft.No;
            RightToLeftLayout = bRTL;

            dg1.Rows.Clear();
            XmlNodeList pFields = xDataPage.SelectNodes(".//F");
            int nIdx = 0;
            foreach (XmlNode pField in pFields)
            {
                if (pField.SelectSingleNode(".//V[@n='STATUS']").InnerText == "-1")
                    continue;
                nIdx++;

                string sText = dcDesk.dco_GetAltText(pField, 0);
                string sType = "";
                sType += pField.SelectSingleNode(".//V[@n='TYPE']").InnerText;
                // Add ability for superfields distingtion.

                string sConf = dcDesk.dco_GetAltConf(pField, 0);
                bool bLC = (dcTask.IsFieldLC(sConf, pField, null) || Convert.ToInt32(pField.SelectSingleNode(".//V[@n='STATUS']").InnerText) > 0);


                DataGridViewRow pRow = new DataGridViewRow();
                DataGridViewImageCell pImage = new DataGridViewImageCell();
                pImage.Value = imageList1.Images[bLC ? 1 : 0];
                DataGridViewTextBoxCell pName = new DataGridViewTextBoxCell();
                if (pField.SelectSingleNode("V[@n='label']") != null)
                    pName.Value = pField.SelectSingleNode("V[@n='label']").InnerText;
                else
                {
                    XmlNode xSet = dcTask.SetupXML.SelectSingleNode("/S/F[@type='" + sType + "']");
                    if (xSet != null && xSet.SelectSingleNode("V[@n='label']") != null)
                        pName.Value = xSet.SelectSingleNode("V[@n='label']").InnerText;
                    else
                        pName.Value = pField.Attributes["id"].Value;
                }
                DataGridViewTextBoxCell pValue = new DataGridViewTextBoxCell();

                sText = WrapBasedOnhr_bidi(pField, sText);  // Set the text direction for display based on hr_bidi variable.

                pValue.Value = sText;  // Store the field value into the grid control.
                pRow.Cells.Add(pImage);
                pRow.Cells.Add(pName);
                pRow.Cells.Add(pValue);
                pRow.Tag = pField;
                dg1.Rows.Add(pRow);
            }
            bLoadDG = false;
            nActiveRow = -1;
            return true;
        }

        int nEdHight = 0;

        protected Control GetDataControl(XmlNode xField)
        {
            string sType = xField.SelectSingleNode("V[@n='TYPE']").InnerText;

            bool bRTL = Ishr_bidiRTL(xField);  // Set the edit box direction based on the hr_bidi value.

            XmlNode xSet = dcTask.SetupXML.SelectSingleNode("/S/F[@type='" + sType + "']");
            if (xSet != null)
            {
                XmlNode pRec = xField.SelectSingleNode("V[@n='RecogType']");
                if (pRec == null)
                    pRec = xSet.SelectSingleNode("V[@n='RecogType']");
                if (pRec != null)
                {
                    int nRecog = Convert.ToInt32(pRec.InnerText);
                    if (nRecog == 4 || nRecog == 18)
                    {
                        if (xField.SelectSingleNode("V[@n='MultiPunch']") != null || xSet.SelectSingleNode("V[@n='MultiPunch']") != null)
                        {
                            dcedDced.Visible = false;
                            dcedDced.Hide();
                            dccombobox.Visible = false;
                            dclistbox.Location = dcedDced.Location;
                            dclistbox.Visible = true;
                            dclistbox.Tag = sType;
                            dclistbox.Items.Clear();
                            return dclistbox;
                        }
                        else
                        {
                            dclistbox.Visible = false;
                            dcedDced.Hide();
                            dcedDced.Visible = false;
                            dccombobox.Location = dcedDced.Location;
                            dccombobox.Visible = true;
                            dccombobox.Tag = sType;
                            dccombobox.Items.Clear();
                            return dccombobox;
                        }
                    }
                }
                pRec = xField.SelectSingleNode("V[@n='DICT']");
                if (pRec == null)
                    pRec = xSet.SelectSingleNode("V[@n='DICT']");
                if (pRec != null)
                {
                    dclistbox.Visible = false;
                    dcedDced.Visible = false;
                    dcedDced.Hide();
                    dccombobox.Location = dcedDced.Location;
                    dccombobox.Visible = true;
                    dccombobox.Tag = sType;
                    dccombobox.Items.Clear();
                    return dccombobox;
                }
                pRec = xField.SelectSingleNode("V[@n='SELECT']");
                if (pRec == null)
                    pRec = xSet.SelectSingleNode("V[@n='SELECT']");
                if (pRec != null)
                {
                    dclistbox.Visible = false;
                    dcedDced.Visible = false;
                    dcedDced.Hide();
                    dccombobox.Location = dcedDced.Location;
                    dccombobox.Visible = true;
                    dccombobox.Tag = sType;
                    dccombobox.Items.Clear();
                    return dccombobox;
                }
                pRec = xField.SelectSingleNode("V[@n='MultiLine']");
                if (pRec == null)
                    pRec = xSet.SelectSingleNode("V[@n='MultiLine']");
                if (pRec != null && pRec.InnerText == "1")
                {
                    dcedDced.BiDiText = bRTL;
                    dcedDced.Number = false;    // For some reason, BiDiText = true also sets Numeber to true.  Since we do not use this property in this panel, turn it back off.
                    dcedDced.Visible = true;
                    dcedDced.Multiline = true;
                    dcedDced.Height = Convert.ToInt32(nEdHight * 2.5);
                    dcedDced.AutoHScroll = false;
                    dcedDced.AutoVScroll = true;
                    dcedDced.WantReturn = true;
                    dcedDced.VScroll = true;
                }
                else
                {
                    if (dcedDced.Multiline)
                    {
                        dcedDced.BiDiText = bRTL;
                        dcedDced.Number = false;    // For some reason, BiDiText = true also sets Numeber to true.  Since we do not use this property in this panel, turn it back off.
                        dcedDced.Visible = true;
                        dcedDced.Multiline = false;
                        dcedDced.Height = nEdHight;
                        dcedDced.AutoHScroll = true;
                        dcedDced.AutoVScroll = false;
                        dcedDced.WantReturn = false;
                        dcedDced.VScroll = false;
                    }
                }
                pRec = xField.SelectSingleNode("V[@n='MaxLength']");
                if (pRec == null)
                    pRec = xSet.SelectSingleNode("V[@n='MaxLength']");
                if (pRec != null && pRec.InnerText != "0")
                    dcedDced.MaxLength = Convert.ToInt32(pRec.InnerText);
                else
                    dcedDced.MaxLength = 255;
                pRec = xField.SelectSingleNode("V[@n='PictureString']");
                if (pRec == null)
                    pRec = xSet.SelectSingleNode("V[@n='PictureString']");
                if (pRec != null && pRec.InnerText != "")
                    dcedDced.PictureString = pRec.InnerText;
                else
                    dcedDced.PictureString = "";
                pRec = xField.SelectSingleNode("V[@n='DataType']");
                if (pRec == null)
                    pRec = xSet.SelectSingleNode("V[@n='DataType']");
                if (pRec != null && pRec.InnerText != "")
                    dcedDced.DataType = (DCEDITLib.DataTypes)Convert.ToInt16(pRec.InnerText);
                else
                    dcedDced.DataType = DCEDITLib.DataTypes.DataAlpha;
                pRec = xField.SelectSingleNode("V[@n='ReadOnly']");
                if (pRec == null)
                    pRec = xSet.SelectSingleNode("V[@n='ReadOnly']");
                if (pRec != null && pRec.InnerText == "1")
                    dcedDced.ReadOnly = true;
                else
                    dcedDced.ReadOnly = false;
            }
            dcedDced.BiDiText = bRTL;
            dcedDced.Number = false;    // For some reason, BiDiText = true also sets Numeber to true.  Since we do not use this property in this panel, turn it back off.
            dccombobox.Visible = false;
            dclistbox.Visible = false;
            dcedDced.Visible = true;
            dcedDced.Tag = sType;
            return dcedDced;
        }

        Control pCtrl = null;

        int nActiveRow = -1;

        protected void LoadField(XmlNode xField)
        {
            if (xField != null)
            {
                dcimDcim.Focus();

                if (nActiveRow > -1)
                    dg1.Rows[nActiveRow].Cells[2].Value = dcDesk.dco_GetAltText(pCtrl.Tag as XmlNode, 0);

                string sVal = dcDesk.dco_GetAltText(xField, 0);
                string sConf = dcDesk.dco_GetAltConf(xField, 0);
                dcimDcim.EraseRect(-1);
                lblLabel.Text = xField.Attributes["id"].Value;
                if (dcTask.LoadField(lblLabel, xField))
                    lblLabel.Tag = xField;
                if (dcTask.LoadField(dcimDcim, xField))
                    dcimDcim.Tag = xField;
                pCtrl = GetDataControl(xField);


                if (dcTask.LoadField(pCtrl, xField))
                {
                    pCtrl.Tag = xField;
                    pCtrl.Focus();
                    dcTask.NewControlFocus(pCtrl);
                    foreach (DataGridViewRow pRow in dg1.Rows)
                    {
                        if (xField == (XmlNode)pRow.Tag)
                        {
                            bLoadDG = true;
                            dg1.CurrentCell = pRow.Cells[1];
                            pRow.Selected = true;
                            bLoadDG = false;
                            break;
                        }
                    }
                }
                int nFur = dg1.FirstDisplayedScrollingRowIndex;
                int nCnt = 1;
                int i = nFur;
                while (dg1.Rows.Count > (i + 1) && dg1.Rows[++i].Displayed)
                    nCnt++;
                if (dg1.SelectedRows[0].Index - nFur > 6 || dg1.SelectedRows[0].Index - nFur < 2)
                {
                    if (nActiveRow < dg1.SelectedRows[0].Index)
                    {
                        int nIdx = (dg1.SelectedRows[0].Index - (nCnt - 3) > 0 ? dg1.SelectedRows[0].Index - (nCnt - 3) : 0);
                        if (dg1.Rows.Count > nIdx)
                            dg1.FirstDisplayedScrollingRowIndex = nIdx;
                    }
                    else
                    {
                        int nIdx = (dg1.SelectedRows[0].Index - 2 > 0 ? dg1.SelectedRows[0].Index - 2 : 0);
                        if (dg1.Rows.Count > nIdx)
                            dg1.FirstDisplayedScrollingRowIndex = nIdx;
                    }
                }
                nActiveRow = dg1.SelectedRows[0].Index;
            }
        }

        public override bool onNextLC()
        {
            if (xDataPage == null)
                return false;
            XmlNode xField = null;
            if (pCtrl != null)
                xField = (pCtrl.Tag as XmlNode);

            if (xField == null)
                xField = xDataPage.SelectSingleNode(".//F[V[@n='STATUS']!='-1']");
            else
                xField = xField.NextSibling;

            string sConf = "9";
            if (xField != null)
                sConf = dcDesk.dco_GetAltConf(xField, 0);

            while (xField != null && dcTask.IsFieldLC(dcDesk.dco_GetAltConf(xField, 0), xField, null) == false && Convert.ToInt32(xField.SelectSingleNode("V[@n='STATUS']").InnerText) < 1)
                xField = xField.NextSibling;

            bool bFirst = false;

            if (xField == null)
            {
                bFirst = true;
                xField = xDataPage.SelectSingleNode(".//F[V[@n='STATUS']!='-1']");
            }

            LoadField(xField);

            if (bFirst)
                return false;

            return true;
        }

        protected void HandleKeyDown(short kCode, short kShift)
        {
            if (xDataPage == null)
                return;
            XmlNode xField = null;
            if (kCode == (short)Keys.Down && kShift == 2)
            {
                if (pCtrl != null)
                    xField = (pCtrl.Tag as XmlNode);
                if (xField == null)
                    xField = xDataPage.SelectSingleNode(".//F");
                else
                    xField = xField.NextSibling;
                string sConf = "9";
                if (xField != null)
                    sConf = dcDesk.dco_GetAltConf(xField, 0);

                while (xField != null && Convert.ToInt32(xField.SelectSingleNode("V[@n='STATUS']").InnerText) < 0)
                    xField = xField.NextSibling;
            }
            if (kCode == (short)Keys.Up && kShift == 2)
            {
                if (pCtrl != null)
                    xField = (pCtrl.Tag as XmlNode);
                if (xField == null)
                    xField = xDataPage.SelectSingleNode(".//F");
                else
                    xField = xField.PreviousSibling;
                string sConf = "9";
                if (xField != null && xField.Name == "F")
                    sConf = dcDesk.dco_GetAltConf(xField, 0);

                while (xField != null && xField.Name == "F" && Convert.ToInt32(xField.SelectSingleNode("V[@n='STATUS']").InnerText) < 0)
                    xField = xField.PreviousSibling;
            }
            LoadField(xField);
        }

        private void dcedDced_KeyDownEvent(object sender, AxDCEDITLib._DDceditEvents_KeyDownEvent e)
        {
            HandleKeyDown(e.keyCode, e.shift);
        }

        private void dclistbox_KeyDown(object sender, KeyEventArgs e)
        {
            HandleKeyDown((short)e.KeyCode, (short)(e.Control ? 2 : 0));
        }

        private void dccombobox_KeyDown(object sender, KeyEventArgs e)
        {
            HandleKeyDown((short)e.KeyCode, (short)(e.Control ? 2 : 0));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OnSubmit(this, EventArgs.Empty);
        }

        private void dg1_SelectionChanged(object sender, EventArgs e)
        {
            if (dg1.SelectedRows.Count == 0 || bLoadDG)
                return;
            XmlNode xField = (XmlNode)dg1.SelectedRows[0].Tag;

            LoadField(xField);
        }

        public override bool SaveData(XmlDocument xPage)
        {
            dcTask.SetSnippetFlags(false, false, 1.0);

            return base.SaveData(xPage);
        }

        // DCEdit updates the grid control.  This method allows us to massage the data after it gets updated in the cell.
        private void dg1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            int col = e.ColumnIndex;
            int row = e.RowIndex;
            if ((row < 0) || (col < 1)) return;

            // Note: Might need to check for type of field here.
            XmlNode pField = (XmlNode)dg1.Rows[row].Tag;                  // Get the field XML back out of the grid.
            DataGridViewTextBoxCell cell = (DataGridViewTextBoxCell)dg1.Rows[row].Cells[col];
            cell.Value = WrapBasedOnhr_bidi(pField, (string)cell.Value);  // Set the text direction for display based on hr_bidi variable.   
            return;
        }
    }
}
