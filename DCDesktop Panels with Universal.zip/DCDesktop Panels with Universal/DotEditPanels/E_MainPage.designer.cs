
namespace DotEditPanels
{
    partial class E_MainPage
    {
        /// 
        /// Required designer variable.
        /// 
        private System.ComponentModel.IContainer components = null;

        /// 
        /// Clean up any resources being used.
        /// 
        /// true if managed resources should be disposed; otherwise, false.
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// 
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(E_MainPage));
            this.lblEntity = new System.Windows.Forms.Label();
            this.lblFunction = new System.Windows.Forms.Label();
            this.lblEntity_GST_Number = new System.Windows.Forms.Label();
            this.lblReferenceNumber_Name = new System.Windows.Forms.Label();
            this.lblDate_Of_Booking = new System.Windows.Forms.Label();
            this.lblVendor_Name = new System.Windows.Forms.Label();
            this.lblPAN_Number = new System.Windows.Forms.Label();
            this.lblInvoice_Amount = new System.Windows.Forms.Label();
            this.lblTDS_Amount = new System.Windows.Forms.Label();
            this.lblInvoice_Number = new System.Windows.Forms.Label();
            this.lblInvoice_Date = new System.Windows.Forms.Label();
            this.lblParty_GST_Number = new System.Windows.Forms.Label();
            this.lblRCM_Flag = new System.Windows.Forms.Label();
            this.lblState = new System.Windows.Forms.Label();
            this.lblGL_Date = new System.Windows.Forms.Label();
            this.lblSubFunction = new System.Windows.Forms.Label();
            this.lblAccounting_NonAccounting = new System.Windows.Forms.Label();
            this.lblAccounting_Doc_type = new System.Windows.Forms.Label();
            this.lblMonth = new System.Windows.Forms.Label();
            this.lblFin_Year = new System.Windows.Forms.Label();
            this.lblNo_Of_Pages = new System.Windows.Forms.Label();
            this.lblDocument_Title = new System.Windows.Forms.Label();
            this.lblSerial_Number = new System.Windows.Forms.Label();
            this.lblVoucher_Number = new System.Windows.Forms.Label();
            this.lblBill_To_Fields = new System.Windows.Forms.Label();
            this.cbEntity = new System.Windows.Forms.ComboBox();
            this.cbSubfunction = new System.Windows.Forms.ComboBox();
            this.cbFunction = new System.Windows.Forms.ComboBox();
            this.dtp_date = new System.Windows.Forms.DateTimePicker();
            this.dtp_InvoiceDate = new System.Windows.Forms.DateTimePicker();
            this.lblDOB = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dcedEntity = new AxDCEDITLib.AxDcedit();
            this.dcedFunction = new AxDCEDITLib.AxDcedit();
            this.dcedEntity_GST_Number = new AxDCEDITLib.AxDcedit();
            this.dcedDate_Of_Booking = new AxDCEDITLib.AxDcedit();
            this.dcedVendor_Name = new AxDCEDITLib.AxDcedit();
            this.dcedPAN_Number = new AxDCEDITLib.AxDcedit();
            this.dcedInvoice_Amount = new AxDCEDITLib.AxDcedit();
            this.dcedTDS_Amount = new AxDCEDITLib.AxDcedit();
            this.dcedInvoice_Number = new AxDCEDITLib.AxDcedit();
            this.dcedParty_GST_Number = new AxDCEDITLib.AxDcedit();
            this.dcedRCM_Flag = new AxDCEDITLib.AxDcedit();
            this.dcedState = new AxDCEDITLib.AxDcedit();
            this.dcedGL_Date = new AxDCEDITLib.AxDcedit();
            this.dcedSubFunction = new AxDCEDITLib.AxDcedit();
            this.dcedAccounting_NonAccounting = new AxDCEDITLib.AxDcedit();
            this.dcedAccounting_Doc_type = new AxDCEDITLib.AxDcedit();
            this.dcedMonth = new AxDCEDITLib.AxDcedit();
            this.dcedFin_Year = new AxDCEDITLib.AxDcedit();
            this.dcedNo_Of_Pages = new AxDCEDITLib.AxDcedit();
            this.dcedDocument_Title = new AxDCEDITLib.AxDcedit();
            this.dcedVoucher_Number = new AxDCEDITLib.AxDcedit();
            this.dcedReferenceNumber_Name = new AxDCEDITLib.AxDcedit();
            this.dcedSerial_Number = new AxDCEDITLib.AxDcedit();
            this.dcedInvoice_Date = new AxDCEDITLib.AxDcedit();
            this.dcedBill_To_Fields = new AxDCEDITLib.AxDcedit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedEntity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedFunction)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedEntity_GST_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDate_Of_Booking)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedVendor_Name)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPAN_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Amount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTDS_Amount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedParty_GST_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedRCM_Flag)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedState)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedGL_Date)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedSubFunction)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedAccounting_NonAccounting)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedAccounting_Doc_type)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedMonth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedFin_Year)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNo_Of_Pages)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDocument_Title)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedVoucher_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedReferenceNumber_Name)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedSerial_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Date)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedBill_To_Fields)).BeginInit();
            this.SuspendLayout();
            // 
            // lblEntity
            // 
            this.lblEntity.AutoSize = true;
            this.lblEntity.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEntity.Location = new System.Drawing.Point(40, 27);
            this.lblEntity.Name = "lblEntity";
            this.lblEntity.Size = new System.Drawing.Size(55, 14);
            this.lblEntity.TabIndex = 0;
            this.lblEntity.Tag = "Entity";
            this.lblEntity.Text = "Entity *";
            // 
            // lblFunction
            // 
            this.lblFunction.AutoSize = true;
            this.lblFunction.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFunction.Location = new System.Drawing.Point(40, 64);
            this.lblFunction.Name = "lblFunction";
            this.lblFunction.Size = new System.Drawing.Size(72, 14);
            this.lblFunction.TabIndex = 3;
            this.lblFunction.Tag = "Function";
            this.lblFunction.Text = "Function *";
            // 
            // lblEntity_GST_Number
            // 
            this.lblEntity_GST_Number.AutoSize = true;
            this.lblEntity_GST_Number.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEntity_GST_Number.Location = new System.Drawing.Point(466, 29);
            this.lblEntity_GST_Number.Name = "lblEntity_GST_Number";
            this.lblEntity_GST_Number.Size = new System.Drawing.Size(136, 14);
            this.lblEntity_GST_Number.TabIndex = 6;
            this.lblEntity_GST_Number.Tag = "Entity_GST_Number";
            this.lblEntity_GST_Number.Text = "Entity GST Number *";
            // 
            // lblReferenceNumber_Name
            // 
            this.lblReferenceNumber_Name.AutoSize = true;
            this.lblReferenceNumber_Name.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReferenceNumber_Name.Location = new System.Drawing.Point(40, 187);
            this.lblReferenceNumber_Name.Name = "lblReferenceNumber_Name";
            this.lblReferenceNumber_Name.Size = new System.Drawing.Size(171, 14);
            this.lblReferenceNumber_Name.TabIndex = 9;
            this.lblReferenceNumber_Name.Tag = "ReferenceNumber_Name";
            this.lblReferenceNumber_Name.Text = "ReferenceNumber Name *";
            // 
            // lblDate_Of_Booking
            // 
            this.lblDate_Of_Booking.AutoSize = true;
            this.lblDate_Of_Booking.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate_Of_Booking.Location = new System.Drawing.Point(40, 145);
            this.lblDate_Of_Booking.Name = "lblDate_Of_Booking";
            this.lblDate_Of_Booking.Size = new System.Drawing.Size(121, 14);
            this.lblDate_Of_Booking.TabIndex = 12;
            this.lblDate_Of_Booking.Tag = "Date_Of_Booking";
            this.lblDate_Of_Booking.Text = "Date Of Booking *";
            // 
            // lblVendor_Name
            // 
            this.lblVendor_Name.AutoSize = true;
            this.lblVendor_Name.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendor_Name.Location = new System.Drawing.Point(466, 110);
            this.lblVendor_Name.Name = "lblVendor_Name";
            this.lblVendor_Name.Size = new System.Drawing.Size(103, 14);
            this.lblVendor_Name.TabIndex = 15;
            this.lblVendor_Name.Tag = "Vendor_Name";
            this.lblVendor_Name.Text = "Vendor Name *";
            // 
            // lblPAN_Number
            // 
            this.lblPAN_Number.AutoSize = true;
            this.lblPAN_Number.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPAN_Number.Location = new System.Drawing.Point(466, 68);
            this.lblPAN_Number.Name = "lblPAN_Number";
            this.lblPAN_Number.Size = new System.Drawing.Size(85, 14);
            this.lblPAN_Number.TabIndex = 18;
            this.lblPAN_Number.Tag = "PAN_Number";
            this.lblPAN_Number.Text = "PAN Number";
            // 
            // lblInvoice_Amount
            // 
            this.lblInvoice_Amount.AutoSize = true;
            this.lblInvoice_Amount.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoice_Amount.Location = new System.Drawing.Point(466, 191);
            this.lblInvoice_Amount.Name = "lblInvoice_Amount";
            this.lblInvoice_Amount.Size = new System.Drawing.Size(116, 14);
            this.lblInvoice_Amount.TabIndex = 21;
            this.lblInvoice_Amount.Tag = "Invoice_Amount";
            this.lblInvoice_Amount.Text = "Invoice Amount *";
            // 
            // lblTDS_Amount
            // 
            this.lblTDS_Amount.AutoSize = true;
            this.lblTDS_Amount.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTDS_Amount.Location = new System.Drawing.Point(467, 325);
            this.lblTDS_Amount.Name = "lblTDS_Amount";
            this.lblTDS_Amount.Size = new System.Drawing.Size(83, 14);
            this.lblTDS_Amount.TabIndex = 24;
            this.lblTDS_Amount.Tag = "TDS_Amount";
            this.lblTDS_Amount.Text = "TDS Amount";
            // 
            // lblInvoice_Number
            // 
            this.lblInvoice_Number.AutoSize = true;
            this.lblInvoice_Number.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoice_Number.Location = new System.Drawing.Point(466, 147);
            this.lblInvoice_Number.Name = "lblInvoice_Number";
            this.lblInvoice_Number.Size = new System.Drawing.Size(117, 14);
            this.lblInvoice_Number.TabIndex = 27;
            this.lblInvoice_Number.Tag = "Invoice_Number";
            this.lblInvoice_Number.Text = "Invoice Number *";
            // 
            // lblInvoice_Date
            // 
            this.lblInvoice_Date.AutoSize = true;
            this.lblInvoice_Date.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoice_Date.Location = new System.Drawing.Point(466, 232);
            this.lblInvoice_Date.Name = "lblInvoice_Date";
            this.lblInvoice_Date.Size = new System.Drawing.Size(98, 14);
            this.lblInvoice_Date.TabIndex = 30;
            this.lblInvoice_Date.Tag = "Invoice_Date";
            this.lblInvoice_Date.Text = "Invoice Date *";
            // 
            // lblParty_GST_Number
            // 
            this.lblParty_GST_Number.AutoSize = true;
            this.lblParty_GST_Number.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParty_GST_Number.Location = new System.Drawing.Point(40, 325);
            this.lblParty_GST_Number.Name = "lblParty_GST_Number";
            this.lblParty_GST_Number.Size = new System.Drawing.Size(121, 14);
            this.lblParty_GST_Number.TabIndex = 33;
            this.lblParty_GST_Number.Tag = "Party_GST_Number";
            this.lblParty_GST_Number.Text = "Party GST Number";
            // 
            // lblRCM_Flag
            // 
            this.lblRCM_Flag.AutoSize = true;
            this.lblRCM_Flag.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRCM_Flag.Location = new System.Drawing.Point(40, 368);
            this.lblRCM_Flag.Name = "lblRCM_Flag";
            this.lblRCM_Flag.Size = new System.Drawing.Size(64, 14);
            this.lblRCM_Flag.TabIndex = 36;
            this.lblRCM_Flag.Tag = "RCM_Flag";
            this.lblRCM_Flag.Text = "RCM Flag";
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblState.Location = new System.Drawing.Point(608, 461);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(41, 14);
            this.lblState.TabIndex = 39;
            this.lblState.Tag = "State";
            this.lblState.Text = "State";
            this.lblState.Visible = false;
            // 
            // lblGL_Date
            // 
            this.lblGL_Date.AutoSize = true;
            this.lblGL_Date.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGL_Date.Location = new System.Drawing.Point(503, 461);
            this.lblGL_Date.Name = "lblGL_Date";
            this.lblGL_Date.Size = new System.Drawing.Size(61, 14);
            this.lblGL_Date.TabIndex = 42;
            this.lblGL_Date.Tag = "GL_Date";
            this.lblGL_Date.Text = "GL_Date";
            this.lblGL_Date.Visible = false;
            // 
            // lblSubFunction
            // 
            this.lblSubFunction.AutoSize = true;
            this.lblSubFunction.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubFunction.Location = new System.Drawing.Point(40, 104);
            this.lblSubFunction.Name = "lblSubFunction";
            this.lblSubFunction.Size = new System.Drawing.Size(84, 14);
            this.lblSubFunction.TabIndex = 45;
            this.lblSubFunction.Tag = "SubFunction";
            this.lblSubFunction.Text = "SubFunction";
            // 
            // lblAccounting_NonAccounting
            // 
            this.lblAccounting_NonAccounting.AutoSize = true;
            this.lblAccounting_NonAccounting.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccounting_NonAccounting.Location = new System.Drawing.Point(486, 461);
            this.lblAccounting_NonAccounting.Name = "lblAccounting_NonAccounting";
            this.lblAccounting_NonAccounting.Size = new System.Drawing.Size(176, 14);
            this.lblAccounting_NonAccounting.TabIndex = 48;
            this.lblAccounting_NonAccounting.Tag = "Accounting_NonAccounting";
            this.lblAccounting_NonAccounting.Text = "Accounting_NonAccounting";
            this.lblAccounting_NonAccounting.Visible = false;
            // 
            // lblAccounting_Doc_type
            // 
            this.lblAccounting_Doc_type.AutoSize = true;
            this.lblAccounting_Doc_type.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccounting_Doc_type.Location = new System.Drawing.Point(486, 461);
            this.lblAccounting_Doc_type.Name = "lblAccounting_Doc_type";
            this.lblAccounting_Doc_type.Size = new System.Drawing.Size(142, 14);
            this.lblAccounting_Doc_type.TabIndex = 51;
            this.lblAccounting_Doc_type.Tag = "Accounting_Doc_type";
            this.lblAccounting_Doc_type.Text = "Accounting_Doc_type";
            this.lblAccounting_Doc_type.Visible = false;
            // 
            // lblMonth
            // 
            this.lblMonth.AutoSize = true;
            this.lblMonth.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMonth.Location = new System.Drawing.Point(525, 461);
            this.lblMonth.Name = "lblMonth";
            this.lblMonth.Size = new System.Drawing.Size(58, 14);
            this.lblMonth.TabIndex = 54;
            this.lblMonth.Tag = "Month";
            this.lblMonth.Text = "Month *";
            this.lblMonth.Visible = false;
            // 
            // lblFin_Year
            // 
            this.lblFin_Year.AutoSize = true;
            this.lblFin_Year.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFin_Year.Location = new System.Drawing.Point(40, 230);
            this.lblFin_Year.Name = "lblFin_Year";
            this.lblFin_Year.Size = new System.Drawing.Size(68, 14);
            this.lblFin_Year.TabIndex = 57;
            this.lblFin_Year.Tag = "Fin_Year";
            this.lblFin_Year.Text = "Fin Year *";
            // 
            // lblNo_Of_Pages
            // 
            this.lblNo_Of_Pages.AutoSize = true;
            this.lblNo_Of_Pages.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNo_Of_Pages.Location = new System.Drawing.Point(509, 461);
            this.lblNo_Of_Pages.Name = "lblNo_Of_Pages";
            this.lblNo_Of_Pages.Size = new System.Drawing.Size(93, 14);
            this.lblNo_Of_Pages.TabIndex = 60;
            this.lblNo_Of_Pages.Tag = "No_Of_Pages";
            this.lblNo_Of_Pages.Text = "No_Of_Pages";
            this.lblNo_Of_Pages.Visible = false;
            // 
            // lblDocument_Title
            // 
            this.lblDocument_Title.AutoSize = true;
            this.lblDocument_Title.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDocument_Title.Location = new System.Drawing.Point(40, 279);
            this.lblDocument_Title.Name = "lblDocument_Title";
            this.lblDocument_Title.Size = new System.Drawing.Size(112, 14);
            this.lblDocument_Title.TabIndex = 63;
            this.lblDocument_Title.Tag = "Document_Title";
            this.lblDocument_Title.Text = "Document Title *";
            // 
            // lblSerial_Number
            // 
            this.lblSerial_Number.AutoSize = true;
            this.lblSerial_Number.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSerial_Number.Location = new System.Drawing.Point(40, 187);
            this.lblSerial_Number.Name = "lblSerial_Number";
            this.lblSerial_Number.Size = new System.Drawing.Size(107, 14);
            this.lblSerial_Number.TabIndex = 66;
            this.lblSerial_Number.Tag = "Serial_Number";
            this.lblSerial_Number.Text = "Serial Number *";
            // 
            // lblVoucher_Number
            // 
            this.lblVoucher_Number.AutoSize = true;
            this.lblVoucher_Number.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVoucher_Number.Location = new System.Drawing.Point(509, 461);
            this.lblVoucher_Number.Name = "lblVoucher_Number";
            this.lblVoucher_Number.Size = new System.Drawing.Size(114, 14);
            this.lblVoucher_Number.TabIndex = 69;
            this.lblVoucher_Number.Tag = "Voucher_Number";
            this.lblVoucher_Number.Text = "Voucher_Number";
            this.lblVoucher_Number.Visible = false;
            // 
            // lblBill_To_Fields
            // 
            this.lblBill_To_Fields.AutoSize = true;
            this.lblBill_To_Fields.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBill_To_Fields.Location = new System.Drawing.Point(467, 325);
            this.lblBill_To_Fields.Name = "lblBill_To_Fields";
            this.lblBill_To_Fields.Size = new System.Drawing.Size(82, 14);
            this.lblBill_To_Fields.TabIndex = 72;
            this.lblBill_To_Fields.Tag = "Bill_To_Fields";
            this.lblBill_To_Fields.Text = "Bill To Fields";
            // 
            // cbEntity
            // 
            this.cbEntity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbEntity.FormattingEnabled = true;
            this.cbEntity.ItemHeight = 13;
            this.cbEntity.Location = new System.Drawing.Point(213, 27);
            this.cbEntity.Name = "cbEntity";
            this.cbEntity.Size = new System.Drawing.Size(200, 21);
            this.cbEntity.TabIndex = 75;
            this.cbEntity.SelectedIndexChanged += new System.EventHandler(this.cbEntity_SelectedIndexChanged);
            // 
            // cbSubfunction
            // 
            this.cbSubfunction.FormattingEnabled = true;
            this.cbSubfunction.Location = new System.Drawing.Point(213, 110);
            this.cbSubfunction.Name = "cbSubfunction";
            this.cbSubfunction.Size = new System.Drawing.Size(200, 21);
            this.cbSubfunction.TabIndex = 76;
            this.cbSubfunction.SelectedIndexChanged += new System.EventHandler(this.cbSubfunction_SelectedIndexChanged);
            // 
            // cbFunction
            // 
            this.cbFunction.FormattingEnabled = true;
            this.cbFunction.Location = new System.Drawing.Point(213, 66);
            this.cbFunction.Name = "cbFunction";
            this.cbFunction.Size = new System.Drawing.Size(200, 21);
            this.cbFunction.TabIndex = 77;
            this.cbFunction.SelectedIndexChanged += new System.EventHandler(this.cbFunction_SelectedIndexChanged);
            // 
            // dtp_date
            // 
            this.dtp_date.CustomFormat = "MM/dd/yyyy";
            this.dtp_date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_date.Location = new System.Drawing.Point(419, 147);
            this.dtp_date.Name = "dtp_date";
            this.dtp_date.Size = new System.Drawing.Size(21, 20);
            this.dtp_date.TabIndex = 78;
            this.dtp_date.ValueChanged += new System.EventHandler(this.dtp_date_ValueChanged);
            // 
            // dtp_InvoiceDate
            // 
            this.dtp_InvoiceDate.CustomFormat = "MM/dd/yyyy";
            this.dtp_InvoiceDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_InvoiceDate.Location = new System.Drawing.Point(837, 232);
            this.dtp_InvoiceDate.Name = "dtp_InvoiceDate";
            this.dtp_InvoiceDate.Size = new System.Drawing.Size(21, 20);
            this.dtp_InvoiceDate.TabIndex = 80;
            this.dtp_InvoiceDate.ValueChanged += new System.EventHandler(this.dtp_InvoiceDate_ValueChanged);
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDOB.ForeColor = System.Drawing.Color.Maroon;
            this.lblDOB.Location = new System.Drawing.Point(40, 159);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(85, 13);
            this.lblDOB.TabIndex = 82;
            this.lblDOB.Text = "(MM/DD/YYYY)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(465, 246);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 83;
            this.label1.Text = "(MM/DD/YYYY)";
            // 
            // dcedEntity
            // 
            this.dcedEntity.Location = new System.Drawing.Point(213, 27);
            this.dcedEntity.Name = "dcedEntity";
            this.dcedEntity.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedEntity.OcxState")));
            this.dcedEntity.Size = new System.Drawing.Size(200, 21);
            this.dcedEntity.TabIndex = 2;
            this.dcedEntity.Tag = "Entity";
            this.dcedEntity.Visible = false;
            // 
            // dcedFunction
            // 
            this.dcedFunction.Location = new System.Drawing.Point(213, 66);
            this.dcedFunction.Name = "dcedFunction";
            this.dcedFunction.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedFunction.OcxState")));
            this.dcedFunction.Size = new System.Drawing.Size(200, 21);
            this.dcedFunction.TabIndex = 5;
            this.dcedFunction.Tag = "Function";
            this.dcedFunction.Visible = false;
            // 
            // dcedEntity_GST_Number
            // 
            this.dcedEntity_GST_Number.Location = new System.Drawing.Point(631, 21);
            this.dcedEntity_GST_Number.Name = "dcedEntity_GST_Number";
            this.dcedEntity_GST_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedEntity_GST_Number.OcxState")));
            this.dcedEntity_GST_Number.Size = new System.Drawing.Size(200, 21);
            this.dcedEntity_GST_Number.TabIndex = 8;
            this.dcedEntity_GST_Number.Tag = "Entity_GST_Number";
            this.dcedEntity_GST_Number.Change += new System.EventHandler(this.dcedEntity_GST_Number_Change);
            // 
            // dcedDate_Of_Booking
            // 
            this.dcedDate_Of_Booking.Location = new System.Drawing.Point(213, 145);
            this.dcedDate_Of_Booking.Name = "dcedDate_Of_Booking";
            this.dcedDate_Of_Booking.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedDate_Of_Booking.OcxState")));
            this.dcedDate_Of_Booking.Size = new System.Drawing.Size(200, 21);
            this.dcedDate_Of_Booking.TabIndex = 14;
            this.dcedDate_Of_Booking.Tag = "Date_Of_Booking";
            this.dcedDate_Of_Booking.Change += new System.EventHandler(this.dcedDate_Of_Booking_Change);
            // 
            // dcedVendor_Name
            // 
            this.dcedVendor_Name.Location = new System.Drawing.Point(631, 103);
            this.dcedVendor_Name.Name = "dcedVendor_Name";
            this.dcedVendor_Name.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedVendor_Name.OcxState")));
            this.dcedVendor_Name.Size = new System.Drawing.Size(200, 21);
            this.dcedVendor_Name.TabIndex = 17;
            this.dcedVendor_Name.Tag = "Vendor_Name";
            // 
            // dcedPAN_Number
            // 
            this.dcedPAN_Number.Location = new System.Drawing.Point(631, 60);
            this.dcedPAN_Number.Name = "dcedPAN_Number";
            this.dcedPAN_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedPAN_Number.OcxState")));
            this.dcedPAN_Number.Size = new System.Drawing.Size(200, 21);
            this.dcedPAN_Number.TabIndex = 20;
            this.dcedPAN_Number.Tag = "PAN_Number";
            // 
            // dcedInvoice_Amount
            // 
            this.dcedInvoice_Amount.Location = new System.Drawing.Point(631, 191);
            this.dcedInvoice_Amount.Name = "dcedInvoice_Amount";
            this.dcedInvoice_Amount.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedInvoice_Amount.OcxState")));
            this.dcedInvoice_Amount.Size = new System.Drawing.Size(200, 21);
            this.dcedInvoice_Amount.TabIndex = 23;
            this.dcedInvoice_Amount.Tag = "Invoice_Amount";
            // 
            // dcedTDS_Amount
            // 
            this.dcedTDS_Amount.Location = new System.Drawing.Point(631, 325);
            this.dcedTDS_Amount.Name = "dcedTDS_Amount";
            this.dcedTDS_Amount.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedTDS_Amount.OcxState")));
            this.dcedTDS_Amount.Size = new System.Drawing.Size(200, 21);
            this.dcedTDS_Amount.TabIndex = 26;
            this.dcedTDS_Amount.Tag = "TDS_Amount";
            // 
            // dcedInvoice_Number
            // 
            this.dcedInvoice_Number.Location = new System.Drawing.Point(631, 146);
            this.dcedInvoice_Number.Name = "dcedInvoice_Number";
            this.dcedInvoice_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedInvoice_Number.OcxState")));
            this.dcedInvoice_Number.Size = new System.Drawing.Size(200, 21);
            this.dcedInvoice_Number.TabIndex = 29;
            this.dcedInvoice_Number.Tag = "Invoice_Number";
            // 
            // dcedParty_GST_Number
            // 
            this.dcedParty_GST_Number.Location = new System.Drawing.Point(213, 325);
            this.dcedParty_GST_Number.Name = "dcedParty_GST_Number";
            this.dcedParty_GST_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedParty_GST_Number.OcxState")));
            this.dcedParty_GST_Number.Size = new System.Drawing.Size(200, 21);
            this.dcedParty_GST_Number.TabIndex = 35;
            this.dcedParty_GST_Number.Tag = "Party_GST_Number";
            // 
            // dcedRCM_Flag
            // 
            this.dcedRCM_Flag.Location = new System.Drawing.Point(213, 368);
            this.dcedRCM_Flag.Name = "dcedRCM_Flag";
            this.dcedRCM_Flag.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedRCM_Flag.OcxState")));
            this.dcedRCM_Flag.Size = new System.Drawing.Size(200, 21);
            this.dcedRCM_Flag.TabIndex = 38;
            this.dcedRCM_Flag.Tag = "RCM_Flag";
            // 
            // dcedState
            // 
            this.dcedState.Location = new System.Drawing.Point(162, 448);
            this.dcedState.Name = "dcedState";
            this.dcedState.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedState.OcxState")));
            this.dcedState.Size = new System.Drawing.Size(45, 27);
            this.dcedState.TabIndex = 41;
            this.dcedState.Tag = "State";
            this.dcedState.Visible = false;
            // 
            // dcedGL_Date
            // 
            this.dcedGL_Date.Location = new System.Drawing.Point(254, 448);
            this.dcedGL_Date.Name = "dcedGL_Date";
            this.dcedGL_Date.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedGL_Date.OcxState")));
            this.dcedGL_Date.Size = new System.Drawing.Size(49, 27);
            this.dcedGL_Date.TabIndex = 44;
            this.dcedGL_Date.Tag = "GL_Date";
            this.dcedGL_Date.Visible = false;
            // 
            // dcedSubFunction
            // 
            this.dcedSubFunction.Location = new System.Drawing.Point(213, 110);
            this.dcedSubFunction.Name = "dcedSubFunction";
            this.dcedSubFunction.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedSubFunction.OcxState")));
            this.dcedSubFunction.Size = new System.Drawing.Size(200, 21);
            this.dcedSubFunction.TabIndex = 47;
            this.dcedSubFunction.Tag = "SubFunction";
            this.dcedSubFunction.Visible = false;
            // 
            // dcedAccounting_NonAccounting
            // 
            this.dcedAccounting_NonAccounting.Location = new System.Drawing.Point(389, 448);
            this.dcedAccounting_NonAccounting.Name = "dcedAccounting_NonAccounting";
            this.dcedAccounting_NonAccounting.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedAccounting_NonAccounting.OcxState")));
            this.dcedAccounting_NonAccounting.Size = new System.Drawing.Size(38, 27);
            this.dcedAccounting_NonAccounting.TabIndex = 50;
            this.dcedAccounting_NonAccounting.Tag = "Accounting_NonAccounting";
            this.dcedAccounting_NonAccounting.Visible = false;
            // 
            // dcedAccounting_Doc_type
            // 
            this.dcedAccounting_Doc_type.Location = new System.Drawing.Point(295, 448);
            this.dcedAccounting_Doc_type.Name = "dcedAccounting_Doc_type";
            this.dcedAccounting_Doc_type.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedAccounting_Doc_type.OcxState")));
            this.dcedAccounting_Doc_type.Size = new System.Drawing.Size(44, 27);
            this.dcedAccounting_Doc_type.TabIndex = 53;
            this.dcedAccounting_Doc_type.Tag = "Accounting_Doc_type";
            this.dcedAccounting_Doc_type.Visible = false;
            // 
            // dcedMonth
            // 
            this.dcedMonth.Location = new System.Drawing.Point(213, 448);
            this.dcedMonth.Name = "dcedMonth";
            this.dcedMonth.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedMonth.OcxState")));
            this.dcedMonth.Size = new System.Drawing.Size(35, 27);
            this.dcedMonth.TabIndex = 56;
            this.dcedMonth.Tag = "Month";
            this.dcedMonth.Visible = false;
            // 
            // dcedFin_Year
            // 
            this.dcedFin_Year.Location = new System.Drawing.Point(213, 230);
            this.dcedFin_Year.Name = "dcedFin_Year";
            this.dcedFin_Year.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedFin_Year.OcxState")));
            this.dcedFin_Year.Size = new System.Drawing.Size(200, 21);
            this.dcedFin_Year.TabIndex = 59;
            this.dcedFin_Year.Tag = "Fin_Year";
            // 
            // dcedNo_Of_Pages
            // 
            this.dcedNo_Of_Pages.Location = new System.Drawing.Point(433, 448);
            this.dcedNo_Of_Pages.Name = "dcedNo_Of_Pages";
            this.dcedNo_Of_Pages.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedNo_Of_Pages.OcxState")));
            this.dcedNo_Of_Pages.Size = new System.Drawing.Size(47, 27);
            this.dcedNo_Of_Pages.TabIndex = 62;
            this.dcedNo_Of_Pages.Tag = "No_Of_Pages";
            this.dcedNo_Of_Pages.Visible = false;
            // 
            // dcedDocument_Title
            // 
            this.dcedDocument_Title.Location = new System.Drawing.Point(213, 279);
            this.dcedDocument_Title.Name = "dcedDocument_Title";
            this.dcedDocument_Title.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedDocument_Title.OcxState")));
            this.dcedDocument_Title.Size = new System.Drawing.Size(618, 21);
            this.dcedDocument_Title.TabIndex = 65;
            this.dcedDocument_Title.Tag = "Document_Title";
            this.dcedDocument_Title.Change += new System.EventHandler(this.dcedDocument_Title_Change);
            // 
            // dcedVoucher_Number
            // 
            this.dcedVoucher_Number.Location = new System.Drawing.Point(345, 448);
            this.dcedVoucher_Number.Name = "dcedVoucher_Number";
            this.dcedVoucher_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedVoucher_Number.OcxState")));
            this.dcedVoucher_Number.Size = new System.Drawing.Size(38, 27);
            this.dcedVoucher_Number.TabIndex = 71;
            this.dcedVoucher_Number.Tag = "Voucher_Number";
            this.dcedVoucher_Number.Visible = false;
            // 
            // dcedReferenceNumber_Name
            // 
            this.dcedReferenceNumber_Name.Location = new System.Drawing.Point(213, 188);
            this.dcedReferenceNumber_Name.Name = "dcedReferenceNumber_Name";
            this.dcedReferenceNumber_Name.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedReferenceNumber_Name.OcxState")));
            this.dcedReferenceNumber_Name.Size = new System.Drawing.Size(200, 21);
            this.dcedReferenceNumber_Name.TabIndex = 11;
            this.dcedReferenceNumber_Name.Tag = "ReferenceNumber_Name";
            this.dcedReferenceNumber_Name.Change += new System.EventHandler(this.dcedReferenceNumber_Name_Change);
            // 
            // dcedSerial_Number
            // 
            this.dcedSerial_Number.Location = new System.Drawing.Point(213, 188);
            this.dcedSerial_Number.Name = "dcedSerial_Number";
            this.dcedSerial_Number.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedSerial_Number.OcxState")));
            this.dcedSerial_Number.Size = new System.Drawing.Size(200, 21);
            this.dcedSerial_Number.TabIndex = 68;
            this.dcedSerial_Number.Tag = "Serial_Number";
            this.dcedSerial_Number.Change += new System.EventHandler(this.dcedSerial_Number_Change);
            // 
            // dcedInvoice_Date
            // 
            this.dcedInvoice_Date.Location = new System.Drawing.Point(631, 232);
            this.dcedInvoice_Date.Name = "dcedInvoice_Date";
            this.dcedInvoice_Date.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedInvoice_Date.OcxState")));
            this.dcedInvoice_Date.Size = new System.Drawing.Size(200, 21);
            this.dcedInvoice_Date.TabIndex = 32;
            this.dcedInvoice_Date.Tag = "Invoice_Date";
            // 
            // dcedBill_To_Fields
            // 
            this.dcedBill_To_Fields.Location = new System.Drawing.Point(631, 325);
            this.dcedBill_To_Fields.Name = "dcedBill_To_Fields";
            this.dcedBill_To_Fields.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedBill_To_Fields.OcxState")));
            this.dcedBill_To_Fields.Size = new System.Drawing.Size(200, 21);
            this.dcedBill_To_Fields.TabIndex = 74;
            this.dcedBill_To_Fields.Tag = "Bill_To_Fields";
            // 
            // E_MainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1208, 741);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblDOB);
            this.Controls.Add(this.dtp_InvoiceDate);
            this.Controls.Add(this.dtp_date);
            this.Controls.Add(this.cbFunction);
            this.Controls.Add(this.cbSubfunction);
            this.Controls.Add(this.cbEntity);
            this.Controls.Add(this.lblEntity);
            this.Controls.Add(this.dcedEntity);
            this.Controls.Add(this.lblFunction);
            this.Controls.Add(this.dcedFunction);
            this.Controls.Add(this.lblEntity_GST_Number);
            this.Controls.Add(this.dcedEntity_GST_Number);
            this.Controls.Add(this.lblReferenceNumber_Name);
            this.Controls.Add(this.lblDate_Of_Booking);
            this.Controls.Add(this.dcedDate_Of_Booking);
            this.Controls.Add(this.lblVendor_Name);
            this.Controls.Add(this.dcedVendor_Name);
            this.Controls.Add(this.lblPAN_Number);
            this.Controls.Add(this.dcedPAN_Number);
            this.Controls.Add(this.lblInvoice_Amount);
            this.Controls.Add(this.dcedInvoice_Amount);
            this.Controls.Add(this.lblTDS_Amount);
            this.Controls.Add(this.dcedTDS_Amount);
            this.Controls.Add(this.lblInvoice_Number);
            this.Controls.Add(this.dcedInvoice_Number);
            this.Controls.Add(this.lblInvoice_Date);
            this.Controls.Add(this.lblParty_GST_Number);
            this.Controls.Add(this.dcedParty_GST_Number);
            this.Controls.Add(this.lblRCM_Flag);
            this.Controls.Add(this.dcedRCM_Flag);
            this.Controls.Add(this.lblState);
            this.Controls.Add(this.dcedState);
            this.Controls.Add(this.lblGL_Date);
            this.Controls.Add(this.dcedGL_Date);
            this.Controls.Add(this.lblSubFunction);
            this.Controls.Add(this.dcedSubFunction);
            this.Controls.Add(this.lblAccounting_NonAccounting);
            this.Controls.Add(this.dcedAccounting_NonAccounting);
            this.Controls.Add(this.lblAccounting_Doc_type);
            this.Controls.Add(this.dcedAccounting_Doc_type);
            this.Controls.Add(this.lblMonth);
            this.Controls.Add(this.dcedMonth);
            this.Controls.Add(this.lblFin_Year);
            this.Controls.Add(this.dcedFin_Year);
            this.Controls.Add(this.lblNo_Of_Pages);
            this.Controls.Add(this.dcedNo_Of_Pages);
            this.Controls.Add(this.lblDocument_Title);
            this.Controls.Add(this.dcedDocument_Title);
            this.Controls.Add(this.lblSerial_Number);
            this.Controls.Add(this.lblVoucher_Number);
            this.Controls.Add(this.dcedVoucher_Number);
            this.Controls.Add(this.lblBill_To_Fields);
            this.Controls.Add(this.dcedReferenceNumber_Name);
            this.Controls.Add(this.dcedSerial_Number);
            this.Controls.Add(this.dcedInvoice_Date);
            this.Controls.Add(this.dcedBill_To_Fields);
            this.Name = "E_MainPage";
            this.Load += new System.EventHandler(this.E_MainPage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dcedEntity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedFunction)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedEntity_GST_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDate_Of_Booking)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedVendor_Name)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPAN_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Amount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTDS_Amount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedParty_GST_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedRCM_Flag)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedState)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedGL_Date)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedSubFunction)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedAccounting_NonAccounting)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedAccounting_Doc_type)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedMonth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedFin_Year)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedNo_Of_Pages)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDocument_Title)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedVoucher_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedReferenceNumber_Name)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedSerial_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedInvoice_Date)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedBill_To_Fields)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblEntity;
                                private AxDCEDITLib.AxDcedit dcedEntity;
                                private System.Windows.Forms.Label lblFunction;
                                private AxDCEDITLib.AxDcedit dcedFunction;
                                private System.Windows.Forms.Label lblEntity_GST_Number;
                                private AxDCEDITLib.AxDcedit dcedEntity_GST_Number;
                                private System.Windows.Forms.Label lblReferenceNumber_Name;
                                private AxDCEDITLib.AxDcedit dcedReferenceNumber_Name;
                                private System.Windows.Forms.Label lblDate_Of_Booking;
                                private AxDCEDITLib.AxDcedit dcedDate_Of_Booking;
                                private System.Windows.Forms.Label lblVendor_Name;
                                private AxDCEDITLib.AxDcedit dcedVendor_Name;
                                private System.Windows.Forms.Label lblPAN_Number;
                                private AxDCEDITLib.AxDcedit dcedPAN_Number;
                                private System.Windows.Forms.Label lblInvoice_Amount;
                                private AxDCEDITLib.AxDcedit dcedInvoice_Amount;
                                private System.Windows.Forms.Label lblTDS_Amount;
                                private AxDCEDITLib.AxDcedit dcedTDS_Amount;
                                private System.Windows.Forms.Label lblInvoice_Number;
                                private AxDCEDITLib.AxDcedit dcedInvoice_Number;
                                private System.Windows.Forms.Label lblInvoice_Date;
                                private AxDCEDITLib.AxDcedit dcedInvoice_Date;
                                private System.Windows.Forms.Label lblParty_GST_Number;
                                private AxDCEDITLib.AxDcedit dcedParty_GST_Number;
                                private System.Windows.Forms.Label lblRCM_Flag;
                                private AxDCEDITLib.AxDcedit dcedRCM_Flag;
                                private System.Windows.Forms.Label lblState;
                                private AxDCEDITLib.AxDcedit dcedState;
                                private System.Windows.Forms.Label lblGL_Date;
                                private AxDCEDITLib.AxDcedit dcedGL_Date;
                                private System.Windows.Forms.Label lblSubFunction;
                                private AxDCEDITLib.AxDcedit dcedSubFunction;
                                private System.Windows.Forms.Label lblAccounting_NonAccounting;
                                private AxDCEDITLib.AxDcedit dcedAccounting_NonAccounting;
                                private System.Windows.Forms.Label lblAccounting_Doc_type;
                                private AxDCEDITLib.AxDcedit dcedAccounting_Doc_type;
                                private System.Windows.Forms.Label lblMonth;
                                private AxDCEDITLib.AxDcedit dcedMonth;
                                private System.Windows.Forms.Label lblFin_Year;
                                private AxDCEDITLib.AxDcedit dcedFin_Year;
                                private System.Windows.Forms.Label lblNo_Of_Pages;
                                private AxDCEDITLib.AxDcedit dcedNo_Of_Pages;
                                private System.Windows.Forms.Label lblDocument_Title;
                                private AxDCEDITLib.AxDcedit dcedDocument_Title;
                                private System.Windows.Forms.Label lblSerial_Number;
                                private AxDCEDITLib.AxDcedit dcedSerial_Number;
                                private System.Windows.Forms.Label lblVoucher_Number;
                                private AxDCEDITLib.AxDcedit dcedVoucher_Number;
                                private System.Windows.Forms.Label lblBill_To_Fields;
                                private AxDCEDITLib.AxDcedit dcedBill_To_Fields;
                                private System.Windows.Forms.ComboBox cbEntity;
                                private System.Windows.Forms.ComboBox cbSubfunction;
                                private System.Windows.Forms.ComboBox cbFunction;
                                private System.Windows.Forms.DateTimePicker dtp_date;
                                private System.Windows.Forms.DateTimePicker dtp_InvoiceDate;
                                private System.Windows.Forms.Label lblDOB;
                                private System.Windows.Forms.Label label1;
                        
    }
}
                