//
// Licensed Materials - Property of IBM
// 5725-C15
// � Copyright IBM Corp. 1994, 2013 All Rights Reserved
// 
// US Government Users Restricted Rights - Use, duplication or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
//
//  v8.1.12 - Added graphics to Add, Append, and Delete buttons.  lblStickyFinger's text value comes from a page level variable called StickyDisplay for internationalization. - Tom Stuart
//  v8.1.13 - POLR, Sticy and Re-recog Taskprofiles now hidden and replaced with buttons.
//  v9.0.00 - Fixed the shared line item snippet to update properly when the page changes - Tom Stuart


using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Drawing;
using System.Data;
using System.Text;
using System.Xml;
using System.Windows.Forms;
using dcDTlib;
using Ini;

namespace DotEditPanels
{
    public partial class APT_Main : dotPanelBase
    {
        System.Collections.Generic.List<string> langChoices = null;
        string sPOLRBtnText = "";     // The text for the POLR button.
        bool enableLocalDate = false; // false = do not display Invoice_Date using locale.  true = display using locale.

        public APT_Main()
        {
            InitializeComponent();

        }

        public override bool StartBatch()
        {
 	        bool bRes = base.StartBatch();

            var dcapp = new DCAppleLib.DirectAppList();
            DCAppleLib.IDCAppInfo appInf = null;
            string sINIFilePath = "";

            try
            {
                dcapp.OpenApplication("APT", out appInf);
                appInf.GetKeyValue("values/gen/SettingsFile", DCAppleLib.EStorageMode.storeAsFSPath, false, out sINIFilePath);
                if (sINIFilePath == null) // Backwards compatability, look in the old hidden location for the ini path.
                {
                    appInf.GetKeyValue("dco_APT\\settingsfile", DCAppleLib.EStorageMode.storeAsFSPath, false, out sINIFilePath);                 
                }

                if (sINIFilePath == null)
                {                    
                    throw new Exception("SETTINGS.INI Path Is Empty: values/gen/SettingsFile");
                }

                // appInf.GetKeyValue("dco_APT" + "\\setupdco", DCAppleLib.EStorageMode.storeAsFSPath, false, out sSetupXML);            
                //Read from settings.ini                
                int NumChoices;
                String Result = "";
                String[] sLangSplit = null;
                IniFile ini = new IniFile(sINIFilePath);

                Result = ini.IniReadValue("Settings", "AllowRecognition");
                if (Result.ToUpper() == "FALSE")
                {
                    btnOCR.Visible = false;
                    comboBoxLanguage.Visible = false;
                    lblLanguage.Visible = false;
                }
                else
                {
                    // Only bother to read the language selections if it is enabled.
                    Result = ini.IniReadValue("Language Choice", "NumOfLanguages");
                    if (!Int32.TryParse(Result, out NumChoices))
                    {
                        NumChoices = 0;
                        langChoices = null;
                    }
                    else
                    {
                        langChoices = new List<string>();
                    }

                    comboBoxLanguage.Items.Clear();
                    for (int i = 1; i <= NumChoices; i++)
                    {
                        Result = ini.IniReadValue("Language Choice", "Language" + i.ToString());

                        // Save the entire string in a separate list.  This string is of the form "<lang>,<EngineValue>" such as "English,0".
                        // Remove the engine value so we can present a nice list to the user.
                        langChoices.Add(Result);
                        sLangSplit = Result.Split(',');                        
                        comboBoxLanguage.Items.Add(sLangSplit[0]);
                    }
                    lblLanguage.Text = ini.IniReadValue("Language Choice", "LabelValue");

                    Result = ini.IniReadValue("Language Choice", "DefaultLanguage");
                    sLangSplit = Result.Split(',');                    
                    comboBoxLanguage.Text = sLangSplit[0]; // Set the default value.

                    //other text translations
                    //lblStickyFinger.Text = ini.IniReadValue("DotEditStrings", "Sticky");
                    StickyBtn.Text = ini.IniReadValue("DotEditStrings", "Sticky");
                    // lblStickyFinger.Visible = true;
                    sPOLRBtnText = ini.IniReadValue("DotEditStrings", "POLR");
                }

                Result = ini.IniReadValue("Settings", "LocalDate");
                if (Result.ToUpper() == "TRUE") // The local date display was enabled.
                {
                    enableLocalDate = true;
                }
            }
            catch (Exception ex)
            {
                 throw new Exception("APT INI file Exception: " + ex.Message);
            }
            finally
            {
                appInf = null;
                dcapp = null;
                sINIFilePath = "";
            }

            return bRes;
        }

        private void PopulateSnippet(XmlNode BoundField, AxDCIMAGELib.AxDcimage ImageCtrl)
        {
            string sPos;
            sPos = BoundField.SelectSingleNode("V[@n='Position']").InnerText.ToString();
            string[] arPos = sPos.Split(',');
            string dispString = arPos[0] + "," + arPos[1] + "," + (Convert.ToInt32(arPos[2]) - Convert.ToInt32(arPos[0])).ToString() + "," + (Convert.ToInt32(arPos[3]) - Convert.ToInt32(arPos[1])).ToString();
            ImageCtrl.DispZoneString = dispString;
  
        }

        private void dcedTax_Value_Enter(object sender, EventArgs e)
        {
            AxDCEDITLib.AxDcedit pEdit = this.ActiveControl as AxDCEDITLib.AxDcedit;

            if (pEdit != null)
            {
                XmlNode BoundField = pEdit.Tag as XmlNode;
                if (BoundField != null)
                {
                    PopulateSnippet(BoundField,dcimTaxDetail);
                }
            }
        }

        public override void AfterTaskProfile(string sProfile)
        {
            string sPageID = xDataPage.DocumentElement.Attributes["id"].Value;
            //MessageBox.Show(sPageID);
            XmlNode pVar = dcTask.BatchXML.SelectSingleNode(".//P[@id='" + sPageID + "']/V[@n='POLRresult']");
            if (pVar != null)
            {
                //lblPOLR.Text = "POLR: " + pVar.InnerText;
                POLRBtn.Text = sPOLRBtnText + " " + pVar.InnerText; // For example "POLR: 2"
            }

            
            base.AfterTaskProfile(sProfile);
        }

        public override bool LoadData(XmlDocument xPage)
        {
            bool bRetn = false;

            try
            {
                bRetn = base.LoadData(xPage);

                string sPageID = xDataPage.DocumentElement.Attributes["id"].Value;
                //MessageBox.Show(sPageID);
                XmlNode pVar = dcTask.BatchXML.SelectSingleNode(".//P[@id='" + sPageID + "']/V[@n='POLRresult']");
                if (pVar != null)
                {
                   // lblPOLR.Text = "POLR: " + pVar.InnerText;
                    POLRBtn.Text = sPOLRBtnText + " " + pVar.InnerText;
                }

                //lblStickyFinger.Visible = false;
                StickyBtn.Visible = false;

                if (dcedVendor.CtlText == "<New>" || dcedVendor.CtlText == "")
                {
                    pVar = dcTask.BatchXML.SelectSingleNode(".//P[@id='" + sPageID + "']/V[@n='TemplateID']");
                    if (pVar != null)
                    {
                        XmlNodeList pInvs = dcTask.BatchXML.SelectNodes(".//P[V[@n='TYPE']='Main_Page']");
                        foreach (XmlNode pInv in pInvs)
                        {
                            if (pInv.Attributes["id"].Value == sPageID)
                                break;
                            XmlNode pTemp = pInv.SelectSingleNode("V[@n='TemplateID']");
                            if (pTemp != null && pTemp.InnerText == pVar.InnerText)
                            {
                                StickyBtn.Visible = true;
                                break;
                            }
                        }
                    }
                }

                if (enableLocalDate)
                {
                    // The page was just loaded, so reset the date to match the default date format for the locale for the user.
                    // This is called when a page is loaded and after a task profile is run.
                    dcedInvoice_Date.CtlText = adjustDateToLocaleOrYMD(dcedInvoice_Date.CtlText, false);
                }
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "APT Panel LoadData Exception: " + ex.Message + "  Details: " + ex.ToString());
            }

            return bRetn;
        }

        private void dcedTax_Value_Change(object sender, EventArgs e)
        {

        }

        private void dcedLineTotal_Change(object sender, EventArgs e)
        {

        }

        private void PopulateLineSnippet(XmlNode BoundField, AxDCIMAGELib.AxDcimage ImageCtrl)
        {
            string sPos;
            string sFilename;
            Int32 nL;
            Int32 nT;
            Int32 nR;
            Int32 nB;            

            XmlNode LineField;
            LineField = BoundField.ParentNode;
            //set sFilename to the page level objects IMAGEFILE variable
            string sPageID = BoundField.OwnerDocument.DocumentElement.Attributes["id"].Value;
            sFilename = dcTask.BatchDir + "\\" + GetDCOVar(BoundField, "IMAGEFILE");
            ImageCtrl.FileName = sFilename;
            //Get the LineField coordinates
            sPos = GetDCOVar(LineField, "Position");
            string[] arPos = sPos.Split(',');
            string dispString = arPos[0] + "," + arPos[1] + "," + (Convert.ToInt32(arPos[2]) - Convert.ToInt32(arPos[0])).ToString() + "," + (Convert.ToInt32(arPos[3]) - Convert.ToInt32(arPos[1])).ToString();
            ImageCtrl.DispZoneString = dispString;
  
            sPos = GetDCOVar(BoundField, "Position");
            arPos = sPos.Split(',');

            if (arPos.GetUpperBound(0) == 3)                
            {
                Int32.TryParse(arPos[0], out nL);
                Int32.TryParse(arPos[1], out nT);
                Int32.TryParse(arPos[2], out nR);
                Int32.TryParse(arPos[3], out nB);
                ImageCtrl.EraseRect(-1);
                ImageCtrl.DrawRect(nL, nT, nR, nB, 2, 200 << 16 | 200 << 8 | 255, 200 << 16 | 200 << 8 | 255, "");
            }
         }

        private void dcedLineTotal_Enter(object sender, EventArgs e)
        {
            AxDCEDITLib.AxDcedit pEdit = this.ActiveControl as AxDCEDITLib.AxDcedit;

            if (pEdit != null)
            {
                XmlNode BoundField = pEdit.Tag as XmlNode;
                if (BoundField != null)
                {
                    PopulateLineSnippet(BoundField, dcimCurrentLine);
                }
            }

        }

        private void dcedItemID_Change(object sender, EventArgs e)
        {

        }

        private void dcedPrice_Change(object sender, EventArgs e)
        {

        }

        private void dcedPrice_Enter(object sender, EventArgs e)
        {
            AxDCEDITLib.AxDcedit pEdit = this.ActiveControl as AxDCEDITLib.AxDcedit;

            if (pEdit != null)
            {
                XmlNode BoundField = pEdit.Tag as XmlNode;
                if (BoundField != null)
                {
                    PopulateLineSnippet(BoundField, dcimCurrentLine);
                }
            }

        }

        private void dcedQty_Change(object sender, EventArgs e)
        {

        }

        private void dcedQty_Enter(object sender, EventArgs e)
        {
            AxDCEDITLib.AxDcedit pEdit = this.ActiveControl as AxDCEDITLib.AxDcedit;

            if (pEdit != null)
            {
                XmlNode BoundField = pEdit.Tag as XmlNode;
                if (BoundField != null)
                {
                    PopulateLineSnippet(BoundField, dcimCurrentLine);
                }
            }

        }

        private void dcedItemDesc_Enter(object sender, EventArgs e)
        {
            AxDCEDITLib.AxDcedit pEdit = this.ActiveControl as AxDCEDITLib.AxDcedit;

            if (pEdit != null)
            {
                XmlNode BoundField = pEdit.Tag as XmlNode;
                if (BoundField != null)
                {
                    PopulateLineSnippet(BoundField, dcimCurrentLine);
                }
            }

        }

        private void dcedItemID_Enter(object sender, EventArgs e)
        {
            AxDCEDITLib.AxDcedit pEdit = this.ActiveControl as AxDCEDITLib.AxDcedit;

            if (pEdit != null)
            {
                XmlNode BoundField = pEdit.Tag as XmlNode;
                if (BoundField != null)
                {
                    PopulateLineSnippet(BoundField, dcimCurrentLine);
                }
            }

        }

        private void dcedPOLineNum_Change(object sender, EventArgs e)
        {

        }

        private void dcedPOLineNum_Enter(object sender, EventArgs e)
        {
            AxDCEDITLib.AxDcedit pEdit = this.ActiveControl as AxDCEDITLib.AxDcedit;

            if (pEdit != null)
            {
                XmlNode BoundField = pEdit.Tag as XmlNode;
                if (BoundField != null)
                {
                    PopulateLineSnippet(BoundField, dcimCurrentLine);
                }
            }
        }

        private void btnOCR_Click(object sender, EventArgs e)
        {
            // dcDTlib.TaskProfileEventArgs n;

            //  n = dcDTlib.TaskProfileEventArgs.Equals(5);
            OnTaskProfile(this,new TaskProfileEventArgs("ReRecog",5));
        }

        // The language selection has changed, put the language selection into the DCO so that language will be used
        // when the re-recognition rules are run.
        private void comboBoxLanguage_SelectedIndexChanged(object sender, EventArgs e)
        {
            String sSelectedLanguage = comboBoxLanguage.Text;
            String sLanguageAndValue = "";            
            String sTestValue = "";
            String[] sLang = null;

            try
            {
                if (dcTask == null) return;
                if (dcTask.BatchXML == null) return;

                for (int i = 0; (sLanguageAndValue == "") && (langChoices.Count > i); i++)
                {
                    sTestValue = langChoices[i];
                    sLang = sTestValue.Split(','); 
                    if (sSelectedLanguage == sLang[0])
                    {
                        sLanguageAndValue = sTestValue;
                    }
                }

                sLang = sLanguageAndValue.Split(',');
                if (sLang == null) return;

                //MessageBox.Show(sLang[1]);
                XmlNode xVar = dcTask.BatchXML.DocumentElement.SelectSingleNode("V[@n='Temp Language Setting']");

                if (xVar == null)
                {
                    XmlElement xEle = (XmlElement)dcTask.BatchXML.CreateElement("V");
                    xEle.SetAttribute("n", "Temp Language Setting");
                    xEle.InnerText = sLang[1];

                    dcTask.BatchXML.DocumentElement.InsertBefore(xEle, dcTask.BatchXML.DocumentElement.FirstChild);
                }

                xVar.InnerText = sLang[1];
                dcTask.WriteLog(0, "'Temp Language Setting' set to: " + sLang[1]);
            }
            catch (Exception ex)
            {
                dcTask.WriteLog(5, "Language selection exception writeing 'Temp Language Setting': " + ex.Message);
            }
        }

        // Run the POLR task profile.
        private void POLRBtn_Click(object sender, EventArgs e)
        {
            OnTaskProfile(this, new TaskProfileEventArgs("POLR", 3)); 
        }

        // Run the Sticky Fingerprint Task Profile.
        private void StickyBtn_Click(object sender, EventArgs e)
        {
            OnTaskProfile(this, new TaskProfileEventArgs("Sticky", 4));
        }

        private void lblStickyFinger_Click(object sender, EventArgs e)
        {

        }

        // Adjust the date to either the locale setting or YMD
        private string adjustDateToLocaleOrYMD(string sDate, bool YMD)
        {
            sDate = sDate.Trim();
            DateTimeFormatInfo dtfi = CultureInfo.CurrentCulture.DateTimeFormat; // The current culture for the thread.
            DateTime dt = new DateTime();

            // check value for valid date
            // The input string should be in either YMD format or in the format that matches the current locale.
            // Note, that if the date is in YMD, it will always parse correctly regardless of the current locale.
            if (DateTime.TryParse(sDate, dtfi, System.Globalization.DateTimeStyles.AllowWhiteSpaces, out dt) == false)
            {
                // result = "Invalid Date format. Unable to Parse " + value + " as a date value using Calendar: '" + dtfi.NativeCalendarName + "'.  Type: " + dtfi.Calendar.ToString() + ".  ShortDatePattern: " + dtfi.ShortDatePattern.ToString();
                dcTask.WriteLog(5, "Invalid Date format. Unable to Parse " + sDate + " as a date value using Calendar: '" + dtfi.NativeCalendarName + "'.  Type: " + dtfi.Calendar.ToString() + ".  ShortDatePattern: " + dtfi.ShortDatePattern.ToString());
            }
            else
            {
                if (dt <= DateTime.MinValue)
                {
                    dcTask.WriteLog(5, "APT Invoice_Date " + sDate + " is less than system minimum valid date value of " + DateTime.MinValue.ToShortDateString());
                }
                else if (dt >= DateTime.MaxValue)
                {                    
                    dcTask.WriteLog(5, "APT Invoice_Date " + sDate + "is greater than system minimum valid date value of " + DateTime.MaxValue.ToShortDateString());
                }
                else if (YMD == true) // If YMD, this is how the date will be saved in the XML.
                {
                    sDate = dt.Year.ToString() + "/" + dt.Month.ToString() + "/" + dt.Day.ToString(); // Convert to YYYY/MM/DD
                }
                else // Convert the date to the format for the machine. This is how the user will view it.
                {
                    sDate = dt.ToShortDateString();
                }
            }
            return sDate;
        }

        // This method is called after the data is saved to the XML.  
        // This occurs when a profile is run and when the panel exits.
        public override bool SaveData(XmlDocument xPage)
        {
            if (enableLocalDate)
            {
                XmlNode pField = dcedInvoice_Date.Tag as XmlNode;
                if (pField != null)
                {
                    string sConverted = adjustDateToLocaleOrYMD(dcedInvoice_Date.CtlText, true);
                    if (ActiveControl == dcedInvoice_Date)
                        dcedInvoice_Date.CtlText = sConverted;
                    SetAltText(pField, 0, sConverted);
                }
            }
            return base.SaveData(xPage);
        }

        private void APT_Main_Load(object sender, EventArgs e)
        {

        }
    }
}
