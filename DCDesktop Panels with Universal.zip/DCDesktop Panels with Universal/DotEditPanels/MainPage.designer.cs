
namespace DotEditPanels
{
    partial class MainPage
    {
        /// 
        /// Required designer variable.
        /// 
        private System.ComponentModel.IContainer components = null;

        /// 
        /// Clean up any resources being used.
        /// 
        /// true if managed resources should be disposed; otherwise, false.
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// 
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainPage));
            this.lblName = new System.Windows.Forms.Label();
            this.dcimName = new AxDCIMAGELib.AxDcimage();
            this.dcedName = new AxDCEDITLib.AxDcedit();
            this.lblAdhar = new System.Windows.Forms.Label();
            this.dcimAdhar = new AxDCIMAGELib.AxDcimage();
            this.dcedAdhar = new AxDCEDITLib.AxDcedit();
            this.lblPan = new System.Windows.Forms.Label();
            this.dcimPan = new AxDCIMAGELib.AxDcimage();
            this.dcedPan = new AxDCEDITLib.AxDcedit();
            this.lblAddress = new System.Windows.Forms.Label();
            this.dcimAddress = new AxDCIMAGELib.AxDcimage();
            this.dcedAddress = new AxDCEDITLib.AxDcedit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimAdhar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedAdhar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimPan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimAddress)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedAddress)).BeginInit();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(17, 16);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(41, 15);
            this.lblName.TabIndex = 0;
            this.lblName.Tag = "Name";
            this.lblName.Text = "Name";
            // 
            // dcimName
            // 
            this.dcimName.Location = new System.Drawing.Point(20, 33);
            this.dcimName.Name = "dcimName";
            this.dcimName.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimName.OcxState")));
            this.dcimName.Size = new System.Drawing.Size(200, 29);
            this.dcimName.TabIndex = 1;
            this.dcimName.TabStop = false;
            this.dcimName.Tag = "Name";
            // 
            // dcedName
            // 
            this.dcedName.Location = new System.Drawing.Point(20, 66);
            this.dcedName.Name = "dcedName";
            this.dcedName.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedName.OcxState")));
            this.dcedName.Size = new System.Drawing.Size(200, 27);
            this.dcedName.TabIndex = 2;
            this.dcedName.Tag = "Name";
            // 
            // lblAdhar
            // 
            this.lblAdhar.AutoSize = true;
            this.lblAdhar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdhar.Location = new System.Drawing.Point(17, 109);
            this.lblAdhar.Name = "lblAdhar";
            this.lblAdhar.Size = new System.Drawing.Size(39, 15);
            this.lblAdhar.TabIndex = 3;
            this.lblAdhar.Tag = "Adhar";
            this.lblAdhar.Text = "Adhar";
            // 
            // dcimAdhar
            // 
            this.dcimAdhar.Location = new System.Drawing.Point(20, 126);
            this.dcimAdhar.Name = "dcimAdhar";
            this.dcimAdhar.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimAdhar.OcxState")));
            this.dcimAdhar.Size = new System.Drawing.Size(200, 29);
            this.dcimAdhar.TabIndex = 4;
            this.dcimAdhar.TabStop = false;
            this.dcimAdhar.Tag = "Adhar";
            // 
            // dcedAdhar
            // 
            this.dcedAdhar.Location = new System.Drawing.Point(20, 159);
            this.dcedAdhar.Name = "dcedAdhar";
            this.dcedAdhar.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedAdhar.OcxState")));
            this.dcedAdhar.Size = new System.Drawing.Size(200, 27);
            this.dcedAdhar.TabIndex = 5;
            this.dcedAdhar.Tag = "Adhar";
            // 
            // lblPan
            // 
            this.lblPan.AutoSize = true;
            this.lblPan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPan.Location = new System.Drawing.Point(17, 202);
            this.lblPan.Name = "lblPan";
            this.lblPan.Size = new System.Drawing.Size(29, 15);
            this.lblPan.TabIndex = 6;
            this.lblPan.Tag = "Pan";
            this.lblPan.Text = "Pan";
            // 
            // dcimPan
            // 
            this.dcimPan.Location = new System.Drawing.Point(20, 219);
            this.dcimPan.Name = "dcimPan";
            this.dcimPan.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimPan.OcxState")));
            this.dcimPan.Size = new System.Drawing.Size(200, 29);
            this.dcimPan.TabIndex = 7;
            this.dcimPan.TabStop = false;
            this.dcimPan.Tag = "Pan";
            // 
            // dcedPan
            // 
            this.dcedPan.Location = new System.Drawing.Point(20, 252);
            this.dcedPan.Name = "dcedPan";
            this.dcedPan.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedPan.OcxState")));
            this.dcedPan.Size = new System.Drawing.Size(200, 27);
            this.dcedPan.TabIndex = 8;
            this.dcedPan.Tag = "Pan";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.Location = new System.Drawing.Point(17, 295);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(51, 15);
            this.lblAddress.TabIndex = 9;
            this.lblAddress.Tag = "Address";
            this.lblAddress.Text = "Address";
            // 
            // dcimAddress
            // 
            this.dcimAddress.Location = new System.Drawing.Point(20, 312);
            this.dcimAddress.Name = "dcimAddress";
            this.dcimAddress.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimAddress.OcxState")));
            this.dcimAddress.Size = new System.Drawing.Size(200, 29);
            this.dcimAddress.TabIndex = 10;
            this.dcimAddress.TabStop = false;
            this.dcimAddress.Tag = "Address";
            // 
            // dcedAddress
            // 
            this.dcedAddress.Location = new System.Drawing.Point(20, 345);
            this.dcedAddress.Name = "dcedAddress";
            this.dcedAddress.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedAddress.OcxState")));
            this.dcedAddress.Size = new System.Drawing.Size(200, 27);
            this.dcedAddress.TabIndex = 11;
            this.dcedAddress.Tag = "Address";
            // 
            // MainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(230, 473);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.dcimName);
            this.Controls.Add(this.dcedName);
            this.Controls.Add(this.lblAdhar);
            this.Controls.Add(this.dcimAdhar);
            this.Controls.Add(this.dcedAdhar);
            this.Controls.Add(this.lblPan);
            this.Controls.Add(this.dcimPan);
            this.Controls.Add(this.dcedPan);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.dcimAddress);
            this.Controls.Add(this.dcedAddress);
            this.Name = "MainPage";
            ((System.ComponentModel.ISupportInitialize)(this.dcimName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimAdhar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedAdhar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimPan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimAddress)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedAddress)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
                        private System.Windows.Forms.Label lblName;
                                private AxDCIMAGELib.AxDcimage dcimName;
                                private AxDCEDITLib.AxDcedit dcedName;
                                private System.Windows.Forms.Label lblAdhar;
                                private AxDCIMAGELib.AxDcimage dcimAdhar;
                                private AxDCEDITLib.AxDcedit dcedAdhar;
                                private System.Windows.Forms.Label lblPan;
                                private AxDCIMAGELib.AxDcimage dcimPan;
                                private AxDCEDITLib.AxDcedit dcedPan;
                                private System.Windows.Forms.Label lblAddress;
                                private AxDCIMAGELib.AxDcimage dcimAddress;
                                private AxDCEDITLib.AxDcedit dcedAddress;
                        
    }
}
                