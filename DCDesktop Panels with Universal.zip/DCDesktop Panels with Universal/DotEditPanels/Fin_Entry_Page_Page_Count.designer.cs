
namespace DotEditPanels
{
    partial class Fin_Entry_Page_Page_Count
    {
        /// 
        /// Required designer variable.
        /// 
        private System.ComponentModel.IContainer components = null;

        /// 
        /// Clean up any resources being used.
        /// 
        /// true if managed resources should be disposed; otherwise, false.
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// 
        //private void InitializeComponent()
        //{
        //    System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Fin_Entry_Page_Page_Count));
        //                    this.lblEntity = new System.Windows.Forms.Label();
        //                                this.dcimEntity = new AxDCIMAGELib.AxDcimage();
        //                                this.dcedEntity = new AxDCEDITLib.AxDcedit();
        //                                this.lblPrimaryUser = new System.Windows.Forms.Label();
        //                                this.dcimPrimaryUser = new AxDCIMAGELib.AxDcimage();
        //                                this.dcedPrimaryUser = new AxDCEDITLib.AxDcedit();
        //                                this.lblFunction = new System.Windows.Forms.Label();
        //                                this.dcimFunction = new AxDCIMAGELib.AxDcimage();
        //                                this.dcedFunction = new AxDCEDITLib.AxDcedit();
        //                                this.lblRegion = new System.Windows.Forms.Label();
        //                                this.dcimRegion = new AxDCIMAGELib.AxDcimage();
        //                                this.dcedRegion = new AxDCEDITLib.AxDcedit();
        //                                this.lblState = new System.Windows.Forms.Label();
        //                                this.dcimState = new AxDCIMAGELib.AxDcimage();
        //                                this.dcedState = new AxDCEDITLib.AxDcedit();
        //                                this.lblCity = new System.Windows.Forms.Label();
        //                                this.dcimCity = new AxDCIMAGELib.AxDcimage();
        //                                this.dcedCity = new AxDCEDITLib.AxDcedit();
        //                                this.lblDocumentType = new System.Windows.Forms.Label();
        //                                this.dcimDocumentType = new AxDCIMAGELib.AxDcimage();
        //                                this.dcedDocumentType = new AxDCEDITLib.AxDcedit();
        //                                this.lblIssueDate = new System.Windows.Forms.Label();
        //                                this.dcimIssueDate = new AxDCIMAGELib.AxDcimage();
        //                                this.dcedIssueDate = new AxDCEDITLib.AxDcedit();
        //                                this.lblTenure = new System.Windows.Forms.Label();
        //                                this.dcimTenure = new AxDCIMAGELib.AxDcimage();
        //                                this.dcedTenure = new AxDCEDITLib.AxDcedit();
        //                                this.lblLicensors = new System.Windows.Forms.Label();
        //                                this.dcimLicensors = new AxDCIMAGELib.AxDcimage();
        //                                this.dcedLicensors = new AxDCEDITLib.AxDcedit();
        //                                this.lblPropertyAddress = new System.Windows.Forms.Label();
        //                                this.dcimPropertyAddress = new AxDCIMAGELib.AxDcimage();
        //                                this.dcedPropertyAddress = new AxDCEDITLib.AxDcedit();
        //                                this.lblUniqueCode = new System.Windows.Forms.Label();
        //                                this.dcimUniqueCode = new AxDCIMAGELib.AxDcimage();
        //                                this.dcedUniqueCode = new AxDCEDITLib.AxDcedit();
        //                                this.lblVendorName = new System.Windows.Forms.Label();
        //                                this.dcimVendorName = new AxDCIMAGELib.AxDcimage();
        //                                this.dcedVendorName = new AxDCEDITLib.AxDcedit();
        //                                ((System.ComponentModel.ISupportInitialize)(this.dcimEntity)).BeginInit();
                            
        //    ((System.ComponentModel.ISupportInitialize)(this.dcedEntity)).BeginInit();
        //                                ((System.ComponentModel.ISupportInitialize)(this.dcimPrimaryUser)).BeginInit();
                            
        //    ((System.ComponentModel.ISupportInitialize)(this.dcedPrimaryUser)).BeginInit();
        //                                ((System.ComponentModel.ISupportInitialize)(this.dcimFunction)).BeginInit();
                            
        //    ((System.ComponentModel.ISupportInitialize)(this.dcedFunction)).BeginInit();
        //                                ((System.ComponentModel.ISupportInitialize)(this.dcimRegion)).BeginInit();
                            
        //    ((System.ComponentModel.ISupportInitialize)(this.dcedRegion)).BeginInit();
        //                                ((System.ComponentModel.ISupportInitialize)(this.dcimState)).BeginInit();
                            
        //    ((System.ComponentModel.ISupportInitialize)(this.dcedState)).BeginInit();
        //                                ((System.ComponentModel.ISupportInitialize)(this.dcimCity)).BeginInit();
                            
        //    ((System.ComponentModel.ISupportInitialize)(this.dcedCity)).BeginInit();
        //                                ((System.ComponentModel.ISupportInitialize)(this.dcimDocumentType)).BeginInit();
                            
        //    ((System.ComponentModel.ISupportInitialize)(this.dcedDocumentType)).BeginInit();
        //                                ((System.ComponentModel.ISupportInitialize)(this.dcimIssueDate)).BeginInit();
                            
        //    ((System.ComponentModel.ISupportInitialize)(this.dcedIssueDate)).BeginInit();
        //                                ((System.ComponentModel.ISupportInitialize)(this.dcimTenure)).BeginInit();
                            
        //    ((System.ComponentModel.ISupportInitialize)(this.dcedTenure)).BeginInit();
        //                                ((System.ComponentModel.ISupportInitialize)(this.dcimLicensors)).BeginInit();
                            
        //    ((System.ComponentModel.ISupportInitialize)(this.dcedLicensors)).BeginInit();
        //                                ((System.ComponentModel.ISupportInitialize)(this.dcimPropertyAddress)).BeginInit();
                            
        //    ((System.ComponentModel.ISupportInitialize)(this.dcedPropertyAddress)).BeginInit();
        //                                ((System.ComponentModel.ISupportInitialize)(this.dcimUniqueCode)).BeginInit();
                            
        //    ((System.ComponentModel.ISupportInitialize)(this.dcedUniqueCode)).BeginInit();
        //                                ((System.ComponentModel.ISupportInitialize)(this.dcimVendorName)).BeginInit();
                            
        //    ((System.ComponentModel.ISupportInitialize)(this.dcedVendorName)).BeginInit();
                            
        //    this.SuspendLayout();
        //                        // 
        //    // lblEntity
        //    // 
        //    this.lblEntity.AutoSize = true;
        //    this.lblEntity.Location = new System.Drawing.Point(17, 16);
        //    this.lblEntity.Name = "lblEntity";
        //    this.lblEntity.Size = new System.Drawing.Size(100,15);
        //    this.lblEntity.TabIndex = 0;
        //    this.lblEntity.Text = "Entity";  //caption
        //    this.lblEntity.Tag = "Entity";
        //                                this.lblEntity.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        //    // 
        //    // dcimEntity
        //    // 
        //    this.dcimEntity.Enabled = true;
        //    this.dcimEntity.Location = new System.Drawing.Point(20, 33);
        //    this.dcimEntity.Name = "dcimEntity";
        //    this.dcimEntity.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
        //    this.dcimEntity.Size = new System.Drawing.Size(200, 29);
        //    this.dcimEntity.TabIndex = 1;
        //    this.dcimEntity.TabStop = false;
        //    this.dcimEntity.Tag = "Entity";
        //                                // 
        //    // dcedEntity
        //    // 
        //    this.dcedEntity.Location = new System.Drawing.Point(20, 66);
        //    this.dcedEntity.Name = "dcedEntity";
        //    this.dcedEntity.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedit.OcxState")));
        //    this.dcedEntity.Size = new System.Drawing.Size(200, 27);
        //    this.dcedEntity.TabIndex = 2;
        //    this.dcedEntity.Tag = "Entity";
        //                                // 
        //    // lblPrimaryUser
        //    // 
        //    this.lblPrimaryUser.AutoSize = true;
        //    this.lblPrimaryUser.Location = new System.Drawing.Point(17, 109);
        //    this.lblPrimaryUser.Name = "lblPrimaryUser";
        //    this.lblPrimaryUser.Size = new System.Drawing.Size(100,15);
        //    this.lblPrimaryUser.TabIndex = 3;
        //    this.lblPrimaryUser.Text = "PrimaryUser";  //caption
        //    this.lblPrimaryUser.Tag = "PrimaryUser";
        //                                this.lblPrimaryUser.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        //    // 
        //    // dcimPrimaryUser
        //    // 
        //    this.dcimPrimaryUser.Enabled = true;
        //    this.dcimPrimaryUser.Location = new System.Drawing.Point(20, 126);
        //    this.dcimPrimaryUser.Name = "dcimPrimaryUser";
        //    this.dcimPrimaryUser.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
        //    this.dcimPrimaryUser.Size = new System.Drawing.Size(200, 29);
        //    this.dcimPrimaryUser.TabIndex = 4;
        //    this.dcimPrimaryUser.TabStop = false;
        //    this.dcimPrimaryUser.Tag = "PrimaryUser";
        //                                // 
        //    // dcedPrimaryUser
        //    // 
        //    this.dcedPrimaryUser.Location = new System.Drawing.Point(20, 159);
        //    this.dcedPrimaryUser.Name = "dcedPrimaryUser";
        //    this.dcedPrimaryUser.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedit.OcxState")));
        //    this.dcedPrimaryUser.Size = new System.Drawing.Size(200, 27);
        //    this.dcedPrimaryUser.TabIndex = 5;
        //    this.dcedPrimaryUser.Tag = "PrimaryUser";
        //                                // 
        //    // lblFunction
        //    // 
        //    this.lblFunction.AutoSize = true;
        //    this.lblFunction.Location = new System.Drawing.Point(17, 202);
        //    this.lblFunction.Name = "lblFunction";
        //    this.lblFunction.Size = new System.Drawing.Size(100,15);
        //    this.lblFunction.TabIndex = 6;
        //    this.lblFunction.Text = "Function";  //caption
        //    this.lblFunction.Tag = "Function";
        //                                this.lblFunction.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        //    // 
        //    // dcimFunction
        //    // 
        //    this.dcimFunction.Enabled = true;
        //    this.dcimFunction.Location = new System.Drawing.Point(20, 219);
        //    this.dcimFunction.Name = "dcimFunction";
        //    this.dcimFunction.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
        //    this.dcimFunction.Size = new System.Drawing.Size(200, 29);
        //    this.dcimFunction.TabIndex = 7;
        //    this.dcimFunction.TabStop = false;
        //    this.dcimFunction.Tag = "Function";
        //                                // 
        //    // dcedFunction
        //    // 
        //    this.dcedFunction.Location = new System.Drawing.Point(20, 252);
        //    this.dcedFunction.Name = "dcedFunction";
        //    this.dcedFunction.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedit.OcxState")));
        //    this.dcedFunction.Size = new System.Drawing.Size(200, 27);
        //    this.dcedFunction.TabIndex = 8;
        //    this.dcedFunction.Tag = "Function";
        //                                // 
        //    // lblRegion
        //    // 
        //    this.lblRegion.AutoSize = true;
        //    this.lblRegion.Location = new System.Drawing.Point(17, 295);
        //    this.lblRegion.Name = "lblRegion";
        //    this.lblRegion.Size = new System.Drawing.Size(100,15);
        //    this.lblRegion.TabIndex = 9;
        //    this.lblRegion.Text = "Region";  //caption
        //    this.lblRegion.Tag = "Region";
        //                                this.lblRegion.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        //    // 
        //    // dcimRegion
        //    // 
        //    this.dcimRegion.Enabled = true;
        //    this.dcimRegion.Location = new System.Drawing.Point(20, 312);
        //    this.dcimRegion.Name = "dcimRegion";
        //    this.dcimRegion.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
        //    this.dcimRegion.Size = new System.Drawing.Size(200, 29);
        //    this.dcimRegion.TabIndex = 10;
        //    this.dcimRegion.TabStop = false;
        //    this.dcimRegion.Tag = "Region";
        //                                // 
        //    // dcedRegion
        //    // 
        //    this.dcedRegion.Location = new System.Drawing.Point(20, 345);
        //    this.dcedRegion.Name = "dcedRegion";
        //    this.dcedRegion.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedit.OcxState")));
        //    this.dcedRegion.Size = new System.Drawing.Size(200, 27);
        //    this.dcedRegion.TabIndex = 11;
        //    this.dcedRegion.Tag = "Region";
        //                                // 
        //    // lblState
        //    // 
        //    this.lblState.AutoSize = true;
        //    this.lblState.Location = new System.Drawing.Point(17, 388);
        //    this.lblState.Name = "lblState";
        //    this.lblState.Size = new System.Drawing.Size(100,15);
        //    this.lblState.TabIndex = 12;
        //    this.lblState.Text = "State";  //caption
        //    this.lblState.Tag = "State";
        //                                this.lblState.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        //    // 
        //    // dcimState
        //    // 
        //    this.dcimState.Enabled = true;
        //    this.dcimState.Location = new System.Drawing.Point(20, 405);
        //    this.dcimState.Name = "dcimState";
        //    this.dcimState.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
        //    this.dcimState.Size = new System.Drawing.Size(200, 29);
        //    this.dcimState.TabIndex = 13;
        //    this.dcimState.TabStop = false;
        //    this.dcimState.Tag = "State";
        //                                // 
        //    // dcedState
        //    // 
        //    this.dcedState.Location = new System.Drawing.Point(20, 438);
        //    this.dcedState.Name = "dcedState";
        //    this.dcedState.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedit.OcxState")));
        //    this.dcedState.Size = new System.Drawing.Size(200, 27);
        //    this.dcedState.TabIndex = 14;
        //    this.dcedState.Tag = "State";
        //                                // 
        //    // lblCity
        //    // 
        //    this.lblCity.AutoSize = true;
        //    this.lblCity.Location = new System.Drawing.Point(17, 481);
        //    this.lblCity.Name = "lblCity";
        //    this.lblCity.Size = new System.Drawing.Size(100,15);
        //    this.lblCity.TabIndex = 15;
        //    this.lblCity.Text = "City";  //caption
        //    this.lblCity.Tag = "City";
        //                                this.lblCity.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        //    // 
        //    // dcimCity
        //    // 
        //    this.dcimCity.Enabled = true;
        //    this.dcimCity.Location = new System.Drawing.Point(20, 498);
        //    this.dcimCity.Name = "dcimCity";
        //    this.dcimCity.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
        //    this.dcimCity.Size = new System.Drawing.Size(200, 29);
        //    this.dcimCity.TabIndex = 16;
        //    this.dcimCity.TabStop = false;
        //    this.dcimCity.Tag = "City";
        //                                // 
        //    // dcedCity
        //    // 
        //    this.dcedCity.Location = new System.Drawing.Point(20, 531);
        //    this.dcedCity.Name = "dcedCity";
        //    this.dcedCity.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedit.OcxState")));
        //    this.dcedCity.Size = new System.Drawing.Size(200, 27);
        //    this.dcedCity.TabIndex = 17;
        //    this.dcedCity.Tag = "City";
        //                                // 
        //    // lblDocumentType
        //    // 
        //    this.lblDocumentType.AutoSize = true;
        //    this.lblDocumentType.Location = new System.Drawing.Point(17, 574);
        //    this.lblDocumentType.Name = "lblDocumentType";
        //    this.lblDocumentType.Size = new System.Drawing.Size(100,15);
        //    this.lblDocumentType.TabIndex = 18;
        //    this.lblDocumentType.Text = "DocumentType";  //caption
        //    this.lblDocumentType.Tag = "DocumentType";
        //                                this.lblDocumentType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        //    // 
        //    // dcimDocumentType
        //    // 
        //    this.dcimDocumentType.Enabled = true;
        //    this.dcimDocumentType.Location = new System.Drawing.Point(20, 591);
        //    this.dcimDocumentType.Name = "dcimDocumentType";
        //    this.dcimDocumentType.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
        //    this.dcimDocumentType.Size = new System.Drawing.Size(200, 29);
        //    this.dcimDocumentType.TabIndex = 19;
        //    this.dcimDocumentType.TabStop = false;
        //    this.dcimDocumentType.Tag = "DocumentType";
        //                                // 
        //    // dcedDocumentType
        //    // 
        //    this.dcedDocumentType.Location = new System.Drawing.Point(20, 624);
        //    this.dcedDocumentType.Name = "dcedDocumentType";
        //    this.dcedDocumentType.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedit.OcxState")));
        //    this.dcedDocumentType.Size = new System.Drawing.Size(200, 27);
        //    this.dcedDocumentType.TabIndex = 20;
        //    this.dcedDocumentType.Tag = "DocumentType";
        //                                // 
        //    // lblIssueDate
        //    // 
        //    this.lblIssueDate.AutoSize = true;
        //    this.lblIssueDate.Location = new System.Drawing.Point(17, 667);
        //    this.lblIssueDate.Name = "lblIssueDate";
        //    this.lblIssueDate.Size = new System.Drawing.Size(100,15);
        //    this.lblIssueDate.TabIndex = 21;
        //    this.lblIssueDate.Text = "IssueDate";  //caption
        //    this.lblIssueDate.Tag = "IssueDate";
        //                                this.lblIssueDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        //    // 
        //    // dcimIssueDate
        //    // 
        //    this.dcimIssueDate.Enabled = true;
        //    this.dcimIssueDate.Location = new System.Drawing.Point(20, 684);
        //    this.dcimIssueDate.Name = "dcimIssueDate";
        //    this.dcimIssueDate.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
        //    this.dcimIssueDate.Size = new System.Drawing.Size(200, 29);
        //    this.dcimIssueDate.TabIndex = 22;
        //    this.dcimIssueDate.TabStop = false;
        //    this.dcimIssueDate.Tag = "IssueDate";
        //                                // 
        //    // dcedIssueDate
        //    // 
        //    this.dcedIssueDate.Location = new System.Drawing.Point(20, 717);
        //    this.dcedIssueDate.Name = "dcedIssueDate";
        //    this.dcedIssueDate.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedit.OcxState")));
        //    this.dcedIssueDate.Size = new System.Drawing.Size(200, 27);
        //    this.dcedIssueDate.TabIndex = 23;
        //    this.dcedIssueDate.Tag = "IssueDate";
        //                                // 
        //    // lblTenure
        //    // 
        //    this.lblTenure.AutoSize = true;
        //    this.lblTenure.Location = new System.Drawing.Point(17, 760);
        //    this.lblTenure.Name = "lblTenure";
        //    this.lblTenure.Size = new System.Drawing.Size(100,15);
        //    this.lblTenure.TabIndex = 24;
        //    this.lblTenure.Text = "Tenure";  //caption
        //    this.lblTenure.Tag = "Tenure";
        //                                this.lblTenure.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        //    // 
        //    // dcimTenure
        //    // 
        //    this.dcimTenure.Enabled = true;
        //    this.dcimTenure.Location = new System.Drawing.Point(20, 777);
        //    this.dcimTenure.Name = "dcimTenure";
        //    this.dcimTenure.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
        //    this.dcimTenure.Size = new System.Drawing.Size(200, 29);
        //    this.dcimTenure.TabIndex = 25;
        //    this.dcimTenure.TabStop = false;
        //    this.dcimTenure.Tag = "Tenure";
        //                                // 
        //    // dcedTenure
        //    // 
        //    this.dcedTenure.Location = new System.Drawing.Point(20, 810);
        //    this.dcedTenure.Name = "dcedTenure";
        //    this.dcedTenure.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedit.OcxState")));
        //    this.dcedTenure.Size = new System.Drawing.Size(200, 27);
        //    this.dcedTenure.TabIndex = 26;
        //    this.dcedTenure.Tag = "Tenure";
        //                                // 
        //    // lblLicensors
        //    // 
        //    this.lblLicensors.AutoSize = true;
        //    this.lblLicensors.Location = new System.Drawing.Point(17, 853);
        //    this.lblLicensors.Name = "lblLicensors";
        //    this.lblLicensors.Size = new System.Drawing.Size(100,15);
        //    this.lblLicensors.TabIndex = 27;
        //    this.lblLicensors.Text = "Licensors";  //caption
        //    this.lblLicensors.Tag = "Licensors";
        //                                this.lblLicensors.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        //    // 
        //    // dcimLicensors
        //    // 
        //    this.dcimLicensors.Enabled = true;
        //    this.dcimLicensors.Location = new System.Drawing.Point(20, 870);
        //    this.dcimLicensors.Name = "dcimLicensors";
        //    this.dcimLicensors.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
        //    this.dcimLicensors.Size = new System.Drawing.Size(200, 29);
        //    this.dcimLicensors.TabIndex = 28;
        //    this.dcimLicensors.TabStop = false;
        //    this.dcimLicensors.Tag = "Licensors";
        //                                // 
        //    // dcedLicensors
        //    // 
        //    this.dcedLicensors.Location = new System.Drawing.Point(20, 903);
        //    this.dcedLicensors.Name = "dcedLicensors";
        //    this.dcedLicensors.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedit.OcxState")));
        //    this.dcedLicensors.Size = new System.Drawing.Size(200, 27);
        //    this.dcedLicensors.TabIndex = 29;
        //    this.dcedLicensors.Tag = "Licensors";
        //                                // 
        //    // lblPropertyAddress
        //    // 
        //    this.lblPropertyAddress.AutoSize = true;
        //    this.lblPropertyAddress.Location = new System.Drawing.Point(17, 946);
        //    this.lblPropertyAddress.Name = "lblPropertyAddress";
        //    this.lblPropertyAddress.Size = new System.Drawing.Size(100,15);
        //    this.lblPropertyAddress.TabIndex = 30;
        //    this.lblPropertyAddress.Text = "PropertyAddress";  //caption
        //    this.lblPropertyAddress.Tag = "PropertyAddress";
        //                                this.lblPropertyAddress.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        //    // 
        //    // dcimPropertyAddress
        //    // 
        //    this.dcimPropertyAddress.Enabled = true;
        //    this.dcimPropertyAddress.Location = new System.Drawing.Point(20, 963);
        //    this.dcimPropertyAddress.Name = "dcimPropertyAddress";
        //    this.dcimPropertyAddress.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
        //    this.dcimPropertyAddress.Size = new System.Drawing.Size(200, 29);
        //    this.dcimPropertyAddress.TabIndex = 31;
        //    this.dcimPropertyAddress.TabStop = false;
        //    this.dcimPropertyAddress.Tag = "PropertyAddress";
        //                                // 
        //    // dcedPropertyAddress
        //    // 
        //    this.dcedPropertyAddress.Location = new System.Drawing.Point(20, 996);
        //    this.dcedPropertyAddress.Name = "dcedPropertyAddress";
        //    this.dcedPropertyAddress.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedit.OcxState")));
        //    this.dcedPropertyAddress.Size = new System.Drawing.Size(200, 27);
        //    this.dcedPropertyAddress.TabIndex = 32;
        //    this.dcedPropertyAddress.Tag = "PropertyAddress";
        //                                // 
        //    // lblUniqueCode
        //    // 
        //    this.lblUniqueCode.AutoSize = true;
        //    this.lblUniqueCode.Location = new System.Drawing.Point(17, 1039);
        //    this.lblUniqueCode.Name = "lblUniqueCode";
        //    this.lblUniqueCode.Size = new System.Drawing.Size(100,15);
        //    this.lblUniqueCode.TabIndex = 33;
        //    this.lblUniqueCode.Text = "UniqueCode";  //caption
        //    this.lblUniqueCode.Tag = "UniqueCode";
        //                                this.lblUniqueCode.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        //    // 
        //    // dcimUniqueCode
        //    // 
        //    this.dcimUniqueCode.Enabled = true;
        //    this.dcimUniqueCode.Location = new System.Drawing.Point(20, 1056);
        //    this.dcimUniqueCode.Name = "dcimUniqueCode";
        //    this.dcimUniqueCode.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
        //    this.dcimUniqueCode.Size = new System.Drawing.Size(200, 29);
        //    this.dcimUniqueCode.TabIndex = 34;
        //    this.dcimUniqueCode.TabStop = false;
        //    this.dcimUniqueCode.Tag = "UniqueCode";
        //                                // 
        //    // dcedUniqueCode
        //    // 
        //    this.dcedUniqueCode.Location = new System.Drawing.Point(20, 1089);
        //    this.dcedUniqueCode.Name = "dcedUniqueCode";
        //    this.dcedUniqueCode.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedit.OcxState")));
        //    this.dcedUniqueCode.Size = new System.Drawing.Size(200, 27);
        //    this.dcedUniqueCode.TabIndex = 35;
        //    this.dcedUniqueCode.Tag = "UniqueCode";
        //                                // 
        //    // lblVendorName
        //    // 
        //    this.lblVendorName.AutoSize = true;
        //    this.lblVendorName.Location = new System.Drawing.Point(17, 1132);
        //    this.lblVendorName.Name = "lblVendorName";
        //    this.lblVendorName.Size = new System.Drawing.Size(100,15);
        //    this.lblVendorName.TabIndex = 36;
        //    this.lblVendorName.Text = "VendorName";  //caption
        //    this.lblVendorName.Tag = "VendorName";
        //                                this.lblVendorName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        //    // 
        //    // dcimVendorName
        //    // 
        //    this.dcimVendorName.Enabled = true;
        //    this.dcimVendorName.Location = new System.Drawing.Point(20, 1149);
        //    this.dcimVendorName.Name = "dcimVendorName";
        //    this.dcimVendorName.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimage.OcxState")));
        //    this.dcimVendorName.Size = new System.Drawing.Size(200, 29);
        //    this.dcimVendorName.TabIndex = 37;
        //    this.dcimVendorName.TabStop = false;
        //    this.dcimVendorName.Tag = "VendorName";
        //                                // 
        //    // dcedVendorName
        //    // 
        //    this.dcedVendorName.Location = new System.Drawing.Point(20, 1182);
        //    this.dcedVendorName.Name = "dcedVendorName";
        //    this.dcedVendorName.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedit.OcxState")));
        //    this.dcedVendorName.Size = new System.Drawing.Size(200, 27);
        //    this.dcedVendorName.TabIndex = 38;
        //    this.dcedVendorName.Tag = "VendorName";
        //                                this.Controls.Add(this.lblEntity);
        //                                this.Controls.Add(this.dcimEntity);
        //                                this.Controls.Add(this.dcedEntity);
        //                                this.Controls.Add(this.lblPrimaryUser);
        //                                this.Controls.Add(this.dcimPrimaryUser);
        //                                this.Controls.Add(this.dcedPrimaryUser);
        //                                this.Controls.Add(this.lblFunction);
        //                                this.Controls.Add(this.dcimFunction);
        //                                this.Controls.Add(this.dcedFunction);
        //                                this.Controls.Add(this.lblRegion);
        //                                this.Controls.Add(this.dcimRegion);
        //                                this.Controls.Add(this.dcedRegion);
        //                                this.Controls.Add(this.lblState);
        //                                this.Controls.Add(this.dcimState);
        //                                this.Controls.Add(this.dcedState);
        //                                this.Controls.Add(this.lblCity);
        //                                this.Controls.Add(this.dcimCity);
        //                                this.Controls.Add(this.dcedCity);
        //                                this.Controls.Add(this.lblDocumentType);
        //                                this.Controls.Add(this.dcimDocumentType);
        //                                this.Controls.Add(this.dcedDocumentType);
        //                                this.Controls.Add(this.lblIssueDate);
        //                                this.Controls.Add(this.dcimIssueDate);
        //                                this.Controls.Add(this.dcedIssueDate);
        //                                this.Controls.Add(this.lblTenure);
        //                                this.Controls.Add(this.dcimTenure);
        //                                this.Controls.Add(this.dcedTenure);
        //                                this.Controls.Add(this.lblLicensors);
        //                                this.Controls.Add(this.dcimLicensors);
        //                                this.Controls.Add(this.dcedLicensors);
        //                                this.Controls.Add(this.lblPropertyAddress);
        //                                this.Controls.Add(this.dcimPropertyAddress);
        //                                this.Controls.Add(this.dcedPropertyAddress);
        //                                this.Controls.Add(this.lblUniqueCode);
        //                                this.Controls.Add(this.dcimUniqueCode);
        //                                this.Controls.Add(this.dcedUniqueCode);
        //                                this.Controls.Add(this.lblVendorName);
        //                                this.Controls.Add(this.dcimVendorName);
        //                                this.Controls.Add(this.dcedVendorName);
                             
        //    this.Name = "Fin_Entry_Page_Page_Count";
        //    this.Size = new System.Drawing.Size(246, 1209);
        //                        ((System.ComponentModel.ISupportInitialize)(this.dcimEntity)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcedEntity)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcimPrimaryUser)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcedPrimaryUser)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcimFunction)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcedFunction)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcimRegion)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcedRegion)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcimState)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcedState)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcimCity)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcedCity)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcimDocumentType)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcedDocumentType)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcimIssueDate)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcedIssueDate)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcimTenure)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcedTenure)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcimLicensors)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcedLicensors)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcimPropertyAddress)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcedPropertyAddress)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcimUniqueCode)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcedUniqueCode)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcimVendorName)).EndInit();
        //                            ((System.ComponentModel.ISupportInitialize)(this.dcedVendorName)).EndInit();
                        
        //    this.ResumeLayout(false);
        //    this.PerformLayout();

        //}
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Fin_Entry_Page_Page_Count));
            this.lblEntity = new System.Windows.Forms.Label();
            this.lblPrimaryUser = new System.Windows.Forms.Label();
            this.lblFunction = new System.Windows.Forms.Label();
            this.lblRegion = new System.Windows.Forms.Label();
            this.lblState = new System.Windows.Forms.Label();
            this.lblCity = new System.Windows.Forms.Label();
            this.lblDocumentType = new System.Windows.Forms.Label();
            this.lblIssueDate = new System.Windows.Forms.Label();
            this.lblTenure = new System.Windows.Forms.Label();
            this.lblLicensors = new System.Windows.Forms.Label();
            this.lblPropertyAddress = new System.Windows.Forms.Label();
            this.lblUniqueCode = new System.Windows.Forms.Label();
            this.lblVendorName = new System.Windows.Forms.Label();
            this.cmb_UniqueCode = new System.Windows.Forms.ComboBox();
            this.cmb_Function = new System.Windows.Forms.ComboBox();
            this.dtp_IssueDate = new System.Windows.Forms.DateTimePicker();
            this.dcedPrimaryUser = new AxDCEDITLib.AxDcedit();
            this.dcedFunction = new AxDCEDITLib.AxDcedit();
            this.dcedRegion = new AxDCEDITLib.AxDcedit();
            this.dcedState = new AxDCEDITLib.AxDcedit();
            this.dcedCity = new AxDCEDITLib.AxDcedit();
            this.dcedDocumentType = new AxDCEDITLib.AxDcedit();
            this.dcedIssueDate = new AxDCEDITLib.AxDcedit();
            this.dcedTenure = new AxDCEDITLib.AxDcedit();
            this.dcedLicensors = new AxDCEDITLib.AxDcedit();
            this.dcedPropertyAddress = new AxDCEDITLib.AxDcedit();
            this.dcedUniqueCode = new AxDCEDITLib.AxDcedit();
            this.dcedVendorName = new AxDCEDITLib.AxDcedit();
            this.dcimFunction = new AxDCIMAGELib.AxDcimage();
            this.dcedEntity = new AxDCEDITLib.AxDcedit();
            this.dcimEntity = new AxDCIMAGELib.AxDcimage();
            this.dcimRegion = new AxDCIMAGELib.AxDcimage();
            this.dcimDocumentType = new AxDCIMAGELib.AxDcimage();
            this.dcimState = new AxDCIMAGELib.AxDcimage();
            this.dcimIssueDate = new AxDCIMAGELib.AxDcimage();
            this.dcimVendorName = new AxDCIMAGELib.AxDcimage();
            this.dcimPropertyAddress = new AxDCIMAGELib.AxDcimage();
            this.dcimTenure = new AxDCIMAGELib.AxDcimage();
            this.dcimLicensors = new AxDCIMAGELib.AxDcimage();
            this.dcimCity = new AxDCIMAGELib.AxDcimage();
            this.dcimPrimaryUser = new AxDCIMAGELib.AxDcimage();
            this.dcimUniqueCode = new AxDCIMAGELib.AxDcimage();
            this.cmb_DocumentType = new System.Windows.Forms.ComboBox();
            this.cmb_VendorName = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPrimaryUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedFunction)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedRegion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedState)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDocumentType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedIssueDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTenure)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedLicensors)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPropertyAddress)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedUniqueCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedVendorName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimFunction)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedEntity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimEntity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimRegion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDocumentType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimState)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimIssueDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimVendorName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimPropertyAddress)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimTenure)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimLicensors)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimPrimaryUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimUniqueCode)).BeginInit();
            this.SuspendLayout();
            // 
            // lblEntity
            // 
            this.lblEntity.AutoSize = true;
            this.lblEntity.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEntity.Location = new System.Drawing.Point(229, 22);
            this.lblEntity.Name = "lblEntity";
            this.lblEntity.Size = new System.Drawing.Size(43, 14);
            this.lblEntity.TabIndex = 0;
            this.lblEntity.Tag = "Entity";
            this.lblEntity.Text = "Entity";
            // 
            // lblPrimaryUser
            // 
            this.lblPrimaryUser.AutoSize = true;
            this.lblPrimaryUser.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrimaryUser.Location = new System.Drawing.Point(526, 49);
            this.lblPrimaryUser.Name = "lblPrimaryUser";
            this.lblPrimaryUser.Size = new System.Drawing.Size(87, 14);
            this.lblPrimaryUser.TabIndex = 3;
            this.lblPrimaryUser.Tag = "PrimaryUser";
            this.lblPrimaryUser.Text = "Primary User";
            // 
            // lblFunction
            // 
            this.lblFunction.AutoSize = true;
            this.lblFunction.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFunction.Location = new System.Drawing.Point(213, 53);
            this.lblFunction.Name = "lblFunction";
            this.lblFunction.Size = new System.Drawing.Size(60, 14);
            this.lblFunction.TabIndex = 6;
            this.lblFunction.Tag = "Function";
            this.lblFunction.Text = "Function";
            // 
            // lblRegion
            // 
            this.lblRegion.AutoSize = true;
            this.lblRegion.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegion.Location = new System.Drawing.Point(552, 82);
            this.lblRegion.Name = "lblRegion";
            this.lblRegion.Size = new System.Drawing.Size(50, 14);
            this.lblRegion.TabIndex = 9;
            this.lblRegion.Tag = "Region";
            this.lblRegion.Text = "Region";
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblState.Location = new System.Drawing.Point(230, 122);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(41, 14);
            this.lblState.TabIndex = 12;
            this.lblState.Tag = "State";
            this.lblState.Text = "State";
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCity.Location = new System.Drawing.Point(561, 128);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(31, 14);
            this.lblCity.TabIndex = 15;
            this.lblCity.Tag = "City";
            this.lblCity.Text = "City";
            // 
            // lblDocumentType
            // 
            this.lblDocumentType.AutoSize = true;
            this.lblDocumentType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDocumentType.Location = new System.Drawing.Point(175, 86);
            this.lblDocumentType.Name = "lblDocumentType";
            this.lblDocumentType.Size = new System.Drawing.Size(103, 14);
            this.lblDocumentType.TabIndex = 18;
            this.lblDocumentType.Tag = "DocumentType";
            this.lblDocumentType.Text = "Document Type";
            // 
            // lblIssueDate
            // 
            this.lblIssueDate.AutoSize = true;
            this.lblIssueDate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIssueDate.Location = new System.Drawing.Point(203, 163);
            this.lblIssueDate.Name = "lblIssueDate";
            this.lblIssueDate.Size = new System.Drawing.Size(76, 14);
            this.lblIssueDate.TabIndex = 21;
            this.lblIssueDate.Tag = "IssueDate";
            this.lblIssueDate.Text = "Issue Date";
            // 
            // lblTenure
            // 
            this.lblTenure.AutoSize = true;
            this.lblTenure.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenure.Location = new System.Drawing.Point(547, 199);
            this.lblTenure.Name = "lblTenure";
            this.lblTenure.Size = new System.Drawing.Size(50, 14);
            this.lblTenure.TabIndex = 24;
            this.lblTenure.Tag = "Tenure";
            this.lblTenure.Text = "Tenure";
            // 
            // lblLicensors
            // 
            this.lblLicensors.AutoSize = true;
            this.lblLicensors.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLicensors.Location = new System.Drawing.Point(536, 166);
            this.lblLicensors.Name = "lblLicensors";
            this.lblLicensors.Size = new System.Drawing.Size(66, 14);
            this.lblLicensors.TabIndex = 27;
            this.lblLicensors.Tag = "Licensors";
            this.lblLicensors.Text = "Licensors";
            // 
            // lblPropertyAddress
            // 
            this.lblPropertyAddress.AutoSize = true;
            this.lblPropertyAddress.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPropertyAddress.Location = new System.Drawing.Point(165, 202);
            this.lblPropertyAddress.Name = "lblPropertyAddress";
            this.lblPropertyAddress.Size = new System.Drawing.Size(116, 14);
            this.lblPropertyAddress.TabIndex = 30;
            this.lblPropertyAddress.Tag = "PropertyAddress";
            this.lblPropertyAddress.Text = "Property Address";
            // 
            // lblUniqueCode
            // 
            this.lblUniqueCode.AutoSize = true;
            this.lblUniqueCode.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUniqueCode.Location = new System.Drawing.Point(515, 16);
            this.lblUniqueCode.Name = "lblUniqueCode";
            this.lblUniqueCode.Size = new System.Drawing.Size(88, 14);
            this.lblUniqueCode.TabIndex = 33;
            this.lblUniqueCode.Tag = "UniqueCode";
            this.lblUniqueCode.Text = "Unique Code";
            // 
            // lblVendorName
            // 
            this.lblVendorName.AutoSize = true;
            this.lblVendorName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendorName.Location = new System.Drawing.Point(190, 165);
            this.lblVendorName.Name = "lblVendorName";
            this.lblVendorName.Size = new System.Drawing.Size(87, 14);
            this.lblVendorName.TabIndex = 36;
            this.lblVendorName.Tag = "VendorName";
            this.lblVendorName.Text = "VendorName";
            // 
            // cmb_UniqueCode
            // 
            this.cmb_UniqueCode.FormattingEnabled = true;
            this.cmb_UniqueCode.Location = new System.Drawing.Point(620, 12);
            this.cmb_UniqueCode.Name = "cmb_UniqueCode";
            this.cmb_UniqueCode.Size = new System.Drawing.Size(201, 21);
            this.cmb_UniqueCode.TabIndex = 39;
            this.cmb_UniqueCode.SelectedIndexChanged += new System.EventHandler(this.cmb_UniqueCode_SelectedIndexChanged);
            // 
            // cmb_Function
            // 
            this.cmb_Function.FormattingEnabled = true;
            this.cmb_Function.Location = new System.Drawing.Point(282, 51);
            this.cmb_Function.Name = "cmb_Function";
            this.cmb_Function.Size = new System.Drawing.Size(199, 21);
            this.cmb_Function.TabIndex = 40;
            this.cmb_Function.SelectedIndexChanged += new System.EventHandler(this.cmb_Function_SelectedIndexChanged);
            // 
            // dtp_IssueDate
            // 
            this.dtp_IssueDate.Location = new System.Drawing.Point(488, 157);
            this.dtp_IssueDate.Name = "dtp_IssueDate";
            this.dtp_IssueDate.Size = new System.Drawing.Size(26, 20);
            this.dtp_IssueDate.TabIndex = 42;
            this.dtp_IssueDate.Tag = "IssueDate";
            this.dtp_IssueDate.Value = new System.DateTime(2018, 8, 30, 11, 30, 47, 0);
            this.dtp_IssueDate.ValueChanged += new System.EventHandler(this.dtp_IssueDate_ValueChanged);
            // 
            // dcedPrimaryUser
            // 
            this.dcedPrimaryUser.Location = new System.Drawing.Point(621, 49);
            this.dcedPrimaryUser.Name = "dcedPrimaryUser";
            this.dcedPrimaryUser.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedPrimaryUser.OcxState")));
            this.dcedPrimaryUser.Size = new System.Drawing.Size(200, 27);
            this.dcedPrimaryUser.TabIndex = 5;
            this.dcedPrimaryUser.Tag = "PrimaryUser";
            // 
            // dcedFunction
            // 
            this.dcedFunction.Location = new System.Drawing.Point(282, 47);
            this.dcedFunction.Name = "dcedFunction";
            this.dcedFunction.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedFunction.OcxState")));
            this.dcedFunction.Size = new System.Drawing.Size(200, 27);
            this.dcedFunction.TabIndex = 8;
            this.dcedFunction.Tag = "Function";
            // 
            // dcedRegion
            // 
            this.dcedRegion.Location = new System.Drawing.Point(621, 82);
            this.dcedRegion.Name = "dcedRegion";
            this.dcedRegion.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedRegion.OcxState")));
            this.dcedRegion.Size = new System.Drawing.Size(200, 27);
            this.dcedRegion.TabIndex = 11;
            this.dcedRegion.Tag = "Region";
            // 
            // dcedState
            // 
            this.dcedState.Location = new System.Drawing.Point(282, 118);
            this.dcedState.Name = "dcedState";
            this.dcedState.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedState.OcxState")));
            this.dcedState.Size = new System.Drawing.Size(200, 27);
            this.dcedState.TabIndex = 14;
            this.dcedState.Tag = "State";
            // 
            // dcedCity
            // 
            this.dcedCity.Location = new System.Drawing.Point(621, 115);
            this.dcedCity.Name = "dcedCity";
            this.dcedCity.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedCity.OcxState")));
            this.dcedCity.Size = new System.Drawing.Size(200, 27);
            this.dcedCity.TabIndex = 17;
            this.dcedCity.Tag = "City";
            // 
            // dcedDocumentType
            // 
            this.dcedDocumentType.Location = new System.Drawing.Point(281, 82);
            this.dcedDocumentType.Name = "dcedDocumentType";
            this.dcedDocumentType.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedDocumentType.OcxState")));
            this.dcedDocumentType.Size = new System.Drawing.Size(200, 27);
            this.dcedDocumentType.TabIndex = 20;
            this.dcedDocumentType.Tag = "DocumentType";
            // 
            // dcedIssueDate
            // 
            this.dcedIssueDate.Location = new System.Drawing.Point(282, 155);
            this.dcedIssueDate.Name = "dcedIssueDate";
            this.dcedIssueDate.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedIssueDate.OcxState")));
            this.dcedIssueDate.Size = new System.Drawing.Size(200, 27);
            this.dcedIssueDate.TabIndex = 23;
            this.dcedIssueDate.Tag = "IssueDate";
            // 
            // dcedTenure
            // 
            this.dcedTenure.Location = new System.Drawing.Point(621, 191);
            this.dcedTenure.Name = "dcedTenure";
            this.dcedTenure.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedTenure.OcxState")));
            this.dcedTenure.Size = new System.Drawing.Size(200, 27);
            this.dcedTenure.TabIndex = 26;
            this.dcedTenure.Tag = "Tenure";
            // 
            // dcedLicensors
            // 
            this.dcedLicensors.Location = new System.Drawing.Point(621, 150);
            this.dcedLicensors.Name = "dcedLicensors";
            this.dcedLicensors.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedLicensors.OcxState")));
            this.dcedLicensors.Size = new System.Drawing.Size(200, 27);
            this.dcedLicensors.TabIndex = 29;
            this.dcedLicensors.Tag = "Licensors";
            // 
            // dcedPropertyAddress
            // 
            this.dcedPropertyAddress.Location = new System.Drawing.Point(284, 194);
            this.dcedPropertyAddress.Name = "dcedPropertyAddress";
            this.dcedPropertyAddress.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedPropertyAddress.OcxState")));
            this.dcedPropertyAddress.Size = new System.Drawing.Size(200, 27);
            this.dcedPropertyAddress.TabIndex = 32;
            this.dcedPropertyAddress.Tag = "PropertyAddress";
            // 
            // dcedUniqueCode
            // 
            this.dcedUniqueCode.Location = new System.Drawing.Point(621, 14);
            this.dcedUniqueCode.Name = "dcedUniqueCode";
            this.dcedUniqueCode.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedUniqueCode.OcxState")));
            this.dcedUniqueCode.Size = new System.Drawing.Size(200, 27);
            this.dcedUniqueCode.TabIndex = 35;
            this.dcedUniqueCode.Tag = "UniqueCode";
            this.dcedUniqueCode.Visible = false;
            // 
            // dcedVendorName
            // 
            this.dcedVendorName.Location = new System.Drawing.Point(284, 158);
            this.dcedVendorName.Name = "dcedVendorName";
            this.dcedVendorName.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedVendorName.OcxState")));
            this.dcedVendorName.Size = new System.Drawing.Size(200, 27);
            this.dcedVendorName.TabIndex = 38;
            this.dcedVendorName.Tag = "VendorName";
            // 
            // dcimFunction
            // 
            this.dcimFunction.Location = new System.Drawing.Point(282, 45);
            this.dcimFunction.Name = "dcimFunction";
            this.dcimFunction.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimFunction.OcxState")));
            this.dcimFunction.Size = new System.Drawing.Size(100, 50);
            this.dcimFunction.TabIndex = 7;
            this.dcimFunction.TabStop = false;
            this.dcimFunction.Tag = "Function";
            this.dcimFunction.Visible = false;
            // 
            // dcedEntity
            // 
            this.dcedEntity.Location = new System.Drawing.Point(282, 16);
            this.dcedEntity.Name = "dcedEntity";
            this.dcedEntity.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcedEntity.OcxState")));
            this.dcedEntity.Size = new System.Drawing.Size(200, 27);
            this.dcedEntity.TabIndex = 2;
            this.dcedEntity.Tag = "Entity";
            this.dcedEntity.Change += new System.EventHandler(this.dcedEntity_Change);
            // 
            // dcimEntity
            // 
            this.dcimEntity.Location = new System.Drawing.Point(282, 14);
            this.dcimEntity.Name = "dcimEntity";
            this.dcimEntity.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimEntity.OcxState")));
            this.dcimEntity.Size = new System.Drawing.Size(100, 50);
            this.dcimEntity.TabIndex = 1;
            this.dcimEntity.TabStop = false;
            this.dcimEntity.Tag = "Entity";
            this.dcimEntity.Visible = false;
            // 
            // dcimRegion
            // 
            this.dcimRegion.Location = new System.Drawing.Point(621, 79);
            this.dcimRegion.Name = "dcimRegion";
            this.dcimRegion.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimRegion.OcxState")));
            this.dcimRegion.Size = new System.Drawing.Size(100, 50);
            this.dcimRegion.TabIndex = 10;
            this.dcimRegion.TabStop = false;
            this.dcimRegion.Tag = "Region";
            this.dcimRegion.Visible = false;
            // 
            // dcimDocumentType
            // 
            this.dcimDocumentType.Location = new System.Drawing.Point(281, 80);
            this.dcimDocumentType.Name = "dcimDocumentType";
            this.dcimDocumentType.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimDocumentType.OcxState")));
            this.dcimDocumentType.Size = new System.Drawing.Size(100, 50);
            this.dcimDocumentType.TabIndex = 19;
            this.dcimDocumentType.TabStop = false;
            this.dcimDocumentType.Tag = "DocumentType";
            this.dcimDocumentType.Visible = false;
            // 
            // dcimState
            // 
            this.dcimState.Location = new System.Drawing.Point(282, 116);
            this.dcimState.Name = "dcimState";
            this.dcimState.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimState.OcxState")));
            this.dcimState.Size = new System.Drawing.Size(100, 50);
            this.dcimState.TabIndex = 13;
            this.dcimState.TabStop = false;
            this.dcimState.Tag = "State";
            this.dcimState.Visible = false;
            // 
            // dcimIssueDate
            // 
            this.dcimIssueDate.Location = new System.Drawing.Point(284, 151);
            this.dcimIssueDate.Name = "dcimIssueDate";
            this.dcimIssueDate.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimIssueDate.OcxState")));
            this.dcimIssueDate.Size = new System.Drawing.Size(100, 50);
            this.dcimIssueDate.TabIndex = 22;
            this.dcimIssueDate.TabStop = false;
            this.dcimIssueDate.Tag = "IssueDate";
            this.dcimIssueDate.Visible = false;
            // 
            // dcimVendorName
            // 
            this.dcimVendorName.Location = new System.Drawing.Point(284, 160);
            this.dcimVendorName.Name = "dcimVendorName";
            this.dcimVendorName.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimVendorName.OcxState")));
            this.dcimVendorName.Size = new System.Drawing.Size(100, 50);
            this.dcimVendorName.TabIndex = 37;
            this.dcimVendorName.TabStop = false;
            this.dcimVendorName.Tag = "VendorName";
            this.dcimVendorName.Visible = false;
            // 
            // dcimPropertyAddress
            // 
            this.dcimPropertyAddress.Location = new System.Drawing.Point(285, 193);
            this.dcimPropertyAddress.Name = "dcimPropertyAddress";
            this.dcimPropertyAddress.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimPropertyAddress.OcxState")));
            this.dcimPropertyAddress.Size = new System.Drawing.Size(100, 50);
            this.dcimPropertyAddress.TabIndex = 31;
            this.dcimPropertyAddress.TabStop = false;
            this.dcimPropertyAddress.Tag = "PropertyAddress";
            this.dcimPropertyAddress.Visible = false;
            // 
            // dcimTenure
            // 
            this.dcimTenure.Location = new System.Drawing.Point(620, 191);
            this.dcimTenure.Name = "dcimTenure";
            this.dcimTenure.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimTenure.OcxState")));
            this.dcimTenure.Size = new System.Drawing.Size(100, 50);
            this.dcimTenure.TabIndex = 25;
            this.dcimTenure.TabStop = false;
            this.dcimTenure.Tag = "Tenure";
            this.dcimTenure.Visible = false;
            // 
            // dcimLicensors
            // 
            this.dcimLicensors.Location = new System.Drawing.Point(621, 150);
            this.dcimLicensors.Name = "dcimLicensors";
            this.dcimLicensors.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimLicensors.OcxState")));
            this.dcimLicensors.Size = new System.Drawing.Size(100, 50);
            this.dcimLicensors.TabIndex = 28;
            this.dcimLicensors.TabStop = false;
            this.dcimLicensors.Tag = "Licensors";
            this.dcimLicensors.Visible = false;
            // 
            // dcimCity
            // 
            this.dcimCity.Location = new System.Drawing.Point(621, 113);
            this.dcimCity.Name = "dcimCity";
            this.dcimCity.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimCity.OcxState")));
            this.dcimCity.Size = new System.Drawing.Size(100, 50);
            this.dcimCity.TabIndex = 16;
            this.dcimCity.TabStop = false;
            this.dcimCity.Tag = "City";
            this.dcimCity.Visible = false;
            // 
            // dcimPrimaryUser
            // 
            this.dcimPrimaryUser.Location = new System.Drawing.Point(621, 47);
            this.dcimPrimaryUser.Name = "dcimPrimaryUser";
            this.dcimPrimaryUser.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimPrimaryUser.OcxState")));
            this.dcimPrimaryUser.Size = new System.Drawing.Size(100, 50);
            this.dcimPrimaryUser.TabIndex = 4;
            this.dcimPrimaryUser.TabStop = false;
            this.dcimPrimaryUser.Tag = "PrimaryUser";
            this.dcimPrimaryUser.Visible = false;
            // 
            // dcimUniqueCode
            // 
            this.dcimUniqueCode.Location = new System.Drawing.Point(621, 12);
            this.dcimUniqueCode.Name = "dcimUniqueCode";
            this.dcimUniqueCode.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dcimUniqueCode.OcxState")));
            this.dcimUniqueCode.Size = new System.Drawing.Size(100, 50);
            this.dcimUniqueCode.TabIndex = 34;
            this.dcimUniqueCode.TabStop = false;
            this.dcimUniqueCode.Tag = "UniqueCode";
            this.dcimUniqueCode.Visible = false;
            // 
            // cmb_DocumentType
            // 
            this.cmb_DocumentType.FormattingEnabled = true;
            this.cmb_DocumentType.Location = new System.Drawing.Point(282, 82);
            this.cmb_DocumentType.Name = "cmb_DocumentType";
            this.cmb_DocumentType.Size = new System.Drawing.Size(199, 21);
            this.cmb_DocumentType.TabIndex = 43;
            this.cmb_DocumentType.Tag = "DocumentType";
            this.cmb_DocumentType.SelectedIndexChanged += new System.EventHandler(this.cmb_DocumentType_SelectedIndexChanged);
            // 
            // cmb_VendorName
            // 
            this.cmb_VendorName.FormattingEnabled = true;
            this.cmb_VendorName.Location = new System.Drawing.Point(283, 159);
            this.cmb_VendorName.Name = "cmb_VendorName";
            this.cmb_VendorName.Size = new System.Drawing.Size(199, 21);
            this.cmb_VendorName.TabIndex = 44;
            this.cmb_VendorName.Tag = "VendorName";
            this.cmb_VendorName.SelectedIndexChanged += new System.EventHandler(this.cmb_VendorName_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(642, 271);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 45;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Fin_Entry_Page_Page_Count
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(796, 511);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cmb_VendorName);
            this.Controls.Add(this.cmb_DocumentType);
            this.Controls.Add(this.dtp_IssueDate);
            this.Controls.Add(this.cmb_Function);
            this.Controls.Add(this.cmb_UniqueCode);
            this.Controls.Add(this.lblEntity);
            this.Controls.Add(this.lblPrimaryUser);
            this.Controls.Add(this.dcedPrimaryUser);
            this.Controls.Add(this.lblFunction);
            this.Controls.Add(this.dcedFunction);
            this.Controls.Add(this.lblRegion);
            this.Controls.Add(this.dcedRegion);
            this.Controls.Add(this.lblState);
            this.Controls.Add(this.dcedState);
            this.Controls.Add(this.lblCity);
            this.Controls.Add(this.dcedCity);
            this.Controls.Add(this.lblDocumentType);
            this.Controls.Add(this.dcedDocumentType);
            this.Controls.Add(this.lblIssueDate);
            this.Controls.Add(this.dcedIssueDate);
            this.Controls.Add(this.lblTenure);
            this.Controls.Add(this.dcedTenure);
            this.Controls.Add(this.lblLicensors);
            this.Controls.Add(this.dcedLicensors);
            this.Controls.Add(this.lblPropertyAddress);
            this.Controls.Add(this.dcedPropertyAddress);
            this.Controls.Add(this.lblUniqueCode);
            this.Controls.Add(this.dcedUniqueCode);
            this.Controls.Add(this.lblVendorName);
            this.Controls.Add(this.dcedVendorName);
            this.Controls.Add(this.dcimFunction);
            this.Controls.Add(this.dcedEntity);
            this.Controls.Add(this.dcimEntity);
            this.Controls.Add(this.dcimRegion);
            this.Controls.Add(this.dcimDocumentType);
            this.Controls.Add(this.dcimState);
            this.Controls.Add(this.dcimIssueDate);
            this.Controls.Add(this.dcimVendorName);
            this.Controls.Add(this.dcimPropertyAddress);
            this.Controls.Add(this.dcimTenure);
            this.Controls.Add(this.dcimLicensors);
            this.Controls.Add(this.dcimCity);
            this.Controls.Add(this.dcimPrimaryUser);
            this.Controls.Add(this.dcimUniqueCode);
            this.Name = "Fin_Entry_Page_Page_Count";
            this.Load += new System.EventHandler(this.Fin_Entry_Page_Page_Count_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dcedPrimaryUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedFunction)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedRegion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedState)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedCity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedDocumentType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedIssueDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedTenure)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedLicensors)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedPropertyAddress)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedUniqueCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedVendorName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimFunction)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcedEntity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimEntity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimRegion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimDocumentType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimState)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimIssueDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimVendorName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimPropertyAddress)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimTenure)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimLicensors)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimCity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimPrimaryUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dcimUniqueCode)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
                        private System.Windows.Forms.Label lblEntity;
                                private AxDCIMAGELib.AxDcimage dcimEntity;
                                private AxDCEDITLib.AxDcedit dcedEntity;
                                private System.Windows.Forms.Label lblPrimaryUser;
                                private AxDCIMAGELib.AxDcimage dcimPrimaryUser;
                                private AxDCEDITLib.AxDcedit dcedPrimaryUser;
                                private System.Windows.Forms.Label lblFunction;
                                private AxDCIMAGELib.AxDcimage dcimFunction;
                                private AxDCEDITLib.AxDcedit dcedFunction;
                                private System.Windows.Forms.Label lblRegion;
                                private AxDCIMAGELib.AxDcimage dcimRegion;
                                private AxDCEDITLib.AxDcedit dcedRegion;
                                private System.Windows.Forms.Label lblState;
                                private AxDCIMAGELib.AxDcimage dcimState;
                                private AxDCEDITLib.AxDcedit dcedState;
                                private System.Windows.Forms.Label lblCity;
                                private AxDCIMAGELib.AxDcimage dcimCity;
                                private AxDCEDITLib.AxDcedit dcedCity;
                                private System.Windows.Forms.Label lblDocumentType;
                                private AxDCIMAGELib.AxDcimage dcimDocumentType;
                                private AxDCEDITLib.AxDcedit dcedDocumentType;
                                private System.Windows.Forms.Label lblIssueDate;
                                private AxDCIMAGELib.AxDcimage dcimIssueDate;
                                private AxDCEDITLib.AxDcedit dcedIssueDate;
                                private System.Windows.Forms.Label lblTenure;
                                private AxDCIMAGELib.AxDcimage dcimTenure;
                                private AxDCEDITLib.AxDcedit dcedTenure;
                                private System.Windows.Forms.Label lblLicensors;
                                private AxDCIMAGELib.AxDcimage dcimLicensors;
                                private AxDCEDITLib.AxDcedit dcedLicensors;
                                private System.Windows.Forms.Label lblPropertyAddress;
                                private AxDCIMAGELib.AxDcimage dcimPropertyAddress;
                                private AxDCEDITLib.AxDcedit dcedPropertyAddress;
                                private System.Windows.Forms.Label lblUniqueCode;
                                private AxDCIMAGELib.AxDcimage dcimUniqueCode;
                                private AxDCEDITLib.AxDcedit dcedUniqueCode;
                                private System.Windows.Forms.Label lblVendorName;
                                private AxDCIMAGELib.AxDcimage dcimVendorName;
                                private AxDCEDITLib.AxDcedit dcedVendorName;
                                private System.Windows.Forms.ComboBox cmb_UniqueCode;
                                private System.Windows.Forms.ComboBox cmb_Function;
                                private System.Windows.Forms.DateTimePicker dtp_IssueDate;
                                private System.Windows.Forms.ComboBox cmb_DocumentType;
                                private System.Windows.Forms.ComboBox cmb_VendorName;
                                private System.Windows.Forms.Button button1;
                        
    }
}
                